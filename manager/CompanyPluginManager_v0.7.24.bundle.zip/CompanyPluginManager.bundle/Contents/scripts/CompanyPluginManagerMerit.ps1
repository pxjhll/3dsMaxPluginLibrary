param(
    [Parameter(Mandatory)]
    [ValidateSet('status', 'add')]
    [string]$Mode,

    [Parameter(Mandatory)]
    [string]$Endpoint,

    [Parameter(Mandatory)]
    [string]$AnonymousId,

    [Parameter(Mandatory)]
    [string]$CachePath,

    [string]$PluginId = ''
)

$ErrorActionPreference = 'Stop'

function Read-IniData([string]$Path) {
    $data = [ordered]@{}
    $section = ''
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
        return $data
    }
    foreach ($line in Get-Content -LiteralPath $Path) {
        $text = [string]$line
        if ($text -match '^\s*\[([^\]]+)\]\s*$') {
            $section = $Matches[1]
            if (-not $data.Contains($section)) {
                $data[$section] = [ordered]@{}
            }
        }
        elseif ($section -and $text -match '^\s*([^=]+?)\s*=(.*)$') {
            $data[$section][$Matches[1].Trim()] = $Matches[2].Trim()
        }
    }
    return $data
}

function Write-IniData([System.Collections.IDictionary]$Data, [string]$Path) {
    $directory = Split-Path -Parent $Path
    New-Item -ItemType Directory -Path $directory -Force | Out-Null
    $temporaryPath = "$Path.new"
    $lines = [System.Collections.Generic.List[string]]::new()
    foreach ($section in $Data.Keys) {
        $lines.Add("[$section]")
        foreach ($key in $Data[$section].Keys) {
            $lines.Add("$key=$($Data[$section][$key])")
        }
        $lines.Add('')
    }
    [IO.File]::WriteAllLines($temporaryPath, $lines, [Text.Encoding]::ASCII)
    Move-Item -LiteralPath $temporaryPath -Destination $Path -Force
}

try {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $headers = @{
        'User-Agent' = 'CompanyPluginManager-Merit'
    }
    $payload = [ordered]@{
        action = $Mode
        anonymousId = $AnonymousId
    }
    if ($Mode -eq 'add') {
        if ([string]::IsNullOrWhiteSpace($PluginId)) {
            exit 3
        }
        $payload.pluginId = $PluginId
    }

    $response = Invoke-RestMethod `
        -UseBasicParsing `
        -Method Post `
        -Uri $Endpoint `
        -Headers $headers `
        -ContentType 'application/json; charset=utf-8' `
        -Body ($payload | ConvertTo-Json -Compress) `
        -TimeoutSec 10
    if (-not $response.ok) {
        exit 4
    }

    if ($Mode -eq 'status') {
        $cache = [ordered]@{
            Meta = [ordered]@{
                Success = '1'
                ServerDate = [string]$response.serverDate
                Added = ''
            }
        }
        foreach ($property in $response.merits.PSObject.Properties) {
            $cache["Plugin.$($property.Name)"] = [ordered]@{
                Total = [string][Math]::Max(0, [int64]$property.Value.total)
                TodayAdded = if ($property.Value.todayAdded) { '1' } else { '0' }
            }
        }
        Write-IniData -Data $cache -Path $CachePath
    }
    else {
        $cache = Read-IniData -Path $CachePath
        if (-not $cache.Contains('Meta')) {
            $cache['Meta'] = [ordered]@{}
        }
        $cache['Meta']['Success'] = '1'
        $cache['Meta']['ServerDate'] = [string]$response.serverDate
        $cache['Meta']['Added'] = if ($response.added) { '1' } else { '0' }
        $section = "Plugin.$PluginId"
        if (-not $cache.Contains($section)) {
            $cache[$section] = [ordered]@{}
        }
        $cache[$section]['Total'] = [string][Math]::Max(0, [int64]$response.total)
        $cache[$section]['TodayAdded'] = if ($response.todayAdded) { '1' } else { '0' }
        Write-IniData -Data $cache -Path $CachePath
    }
    exit 0
}
catch {
    exit 2
}
