param(
    [Parameter(Mandatory)]
    [ValidateSet('folder', 'http')]
    [string]$SourceType,

    [Parameter(Mandatory)]
    [string]$Location,

    [Parameter(Mandatory)]
    [string]$OutputDirectory,

    [string]$TokenEnvironment = ''
)

$ErrorActionPreference = 'Stop'
$catalogOutput = Join-Path $OutputDirectory 'catalog.ini'
$managerOutput = Join-Path $OutputDirectory 'manager.ini'
$catalogStaging = Join-Path $OutputDirectory 'catalog.ini.new'
$managerStaging = Join-Path $OutputDirectory 'manager.ini.new'

New-Item -ItemType Directory -Path $OutputDirectory -Force | Out-Null
Remove-Item -LiteralPath $catalogStaging -Force -ErrorAction SilentlyContinue
Remove-Item -LiteralPath $managerStaging -Force -ErrorAction SilentlyContinue

try {
    if ($SourceType -eq 'folder') {
        $sourceCatalog = Join-Path $Location 'catalog.ini'
        $sourceManager = Join-Path $Location 'manager.ini'
        if (-not (Test-Path -LiteralPath $sourceCatalog -PathType Leaf)) {
            exit 2
        }
        Copy-Item -LiteralPath $sourceCatalog -Destination $catalogStaging
        if (Test-Path -LiteralPath $sourceManager -PathType Leaf) {
            Copy-Item -LiteralPath $sourceManager -Destination $managerStaging
        }
    }
    else {
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        $headers = @{
            'User-Agent' = 'CompanyPluginManager-RepositoryRefresh'
        }
        if (-not [string]::IsNullOrWhiteSpace($TokenEnvironment)) {
            $token = [Environment]::GetEnvironmentVariable($TokenEnvironment)
            if (-not [string]::IsNullOrWhiteSpace($token)) {
                $headers.Authorization = "Bearer $token"
            }
        }
        Invoke-WebRequest `
            -UseBasicParsing `
            -Uri $Location `
            -Headers $headers `
            -TimeoutSec 20 `
            -OutFile $catalogStaging

        $managerUri = [Uri]::new([Uri]$Location, 'manager.ini').AbsoluteUri
        try {
            Invoke-WebRequest `
                -UseBasicParsing `
                -Uri $managerUri `
                -Headers $headers `
                -TimeoutSec 20 `
                -OutFile $managerStaging
        }
        catch {
            Remove-Item -LiteralPath $managerStaging -Force -ErrorAction SilentlyContinue
        }
    }

    if (-not (Test-Path -LiteralPath $catalogStaging -PathType Leaf)) {
        exit 2
    }
    Move-Item -LiteralPath $catalogStaging -Destination $catalogOutput -Force
    if (Test-Path -LiteralPath $managerStaging -PathType Leaf) {
        Move-Item -LiteralPath $managerStaging -Destination $managerOutput -Force
    }
    exit 0
}
finally {
    Remove-Item -LiteralPath $catalogStaging -Force -ErrorAction SilentlyContinue
    Remove-Item -LiteralPath $managerStaging -Force -ErrorAction SilentlyContinue
}
