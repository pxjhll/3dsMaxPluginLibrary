﻿/* Lightweight MacroScript actions. The full runtime is loaded separately. */
global CPM_ManagerMacroRoot
global CPM_GetManagerRuntimePath

(
    local sourcePath = getSourceFileName()
    if sourcePath != undefined do CPM_ManagerMacroRoot = getFilenamePath sourcePath
)

fn CPM_GetManagerRuntimePath =
(
    local bundleRuntime = ""
    if CPM_ManagerMacroRoot != undefined do bundleRuntime = CPM_ManagerMacroRoot + "CompanyPluginManager.ms"
    if bundleRuntime != "" and doesFileExist bundleRuntime then
        bundleRuntime
    else
        (getDir #plugcfg) + "\\CompanyPluginManager\\CompanyPluginManager.ms"
)

macroScript CompanyPluginManager
category:"Company Tools"
toolTip:"公司插件管理器"
buttonText:"打开插件管理器"
(
    global CPM_ShowManager
    global CPM_ManagerRollout

    fn loadCompanyPluginManagerRuntime =
    (
        local runtimePath = CPM_GetManagerRuntimePath()
        if not doesFileExist runtimePath then return false
        if classOf CPM_ShowManager != MAXScriptFunction or classOf CPM_ManagerRollout != RolloutClass do
            try (fileIn runtimePath quiet:true) catch ()
        classOf CPM_ShowManager == MAXScriptFunction and classOf CPM_ManagerRollout == RolloutClass
    )

    on execute do
    (
        if loadCompanyPluginManagerRuntime() then
        (
            try (CPM_ShowManager())
            catch (messageBox ("打开插件管理器失败：\n" + (getCurrentException())) title:"公司插件管理器")
        )
        else messageBox "无法加载公司插件管理器运行库，请重新安装。" title:"公司插件管理器"
    )
)

macroScript CompanyPluginManagerUpdate
category:"Company Tools"
toolTip:"检查插件管理器更新"
buttonText:"检查管理器更新"
(
    global CPM_CheckManagerUpdate

    fn loadCompanyPluginManagerRuntime =
    (
        local runtimePath = CPM_GetManagerRuntimePath()
        if classOf CPM_CheckManagerUpdate != MAXScriptFunction and doesFileExist runtimePath do
            try (fileIn runtimePath quiet:true) catch ()
        classOf CPM_CheckManagerUpdate == MAXScriptFunction
    )

    on execute do
    (
        if loadCompanyPluginManagerRuntime() then CPM_CheckManagerUpdate()
        else messageBox "无法加载插件管理器运行库，请重新安装。" title:"插件管理器"
    )
)

macroScript CompanyPluginManagerOpenSource
category:"Company Tools"
toolTip:"打开所选插件来源"
buttonText:"打开所选插件来源"
(
    global CPM_OpenSelectedPluginSource

    fn loadCompanyPluginManagerRuntime =
    (
        local runtimePath = CPM_GetManagerRuntimePath()
        if classOf CPM_OpenSelectedPluginSource != MAXScriptFunction and doesFileExist runtimePath do
            try (fileIn runtimePath quiet:true) catch ()
        classOf CPM_OpenSelectedPluginSource == MAXScriptFunction
    )

    on execute do
    (
        if loadCompanyPluginManagerRuntime() then CPM_OpenSelectedPluginSource()
        else messageBox "无法加载插件管理器运行库，请重新安装。" title:"插件管理器"
    )
)

macroScript CompanyPluginManagerSources
category:"Company Tools"
toolTip:"打开插件仓库配置"
buttonText:"仓库配置"
(
    global CPM_OpenSourcesConfig

    fn loadCompanyPluginManagerRuntime =
    (
        local runtimePath = CPM_GetManagerRuntimePath()
        if classOf CPM_OpenSourcesConfig != MAXScriptFunction and doesFileExist runtimePath do
            try (fileIn runtimePath quiet:true) catch ()
        classOf CPM_OpenSourcesConfig == MAXScriptFunction
    )

    on execute do
    (
        if loadCompanyPluginManagerRuntime() then CPM_OpenSourcesConfig()
        else messageBox "无法加载插件管理器运行库，请重新安装。" title:"插件管理器"
    )
)

macroScript CompanyPluginManagerLog
category:"Company Tools"
toolTip:"查看插件管理器日志"
buttonText:"查看日志"
(
    global CPM_OpenManagerLog

    fn loadCompanyPluginManagerRuntime =
    (
        local runtimePath = CPM_GetManagerRuntimePath()
        if classOf CPM_OpenManagerLog != MAXScriptFunction and doesFileExist runtimePath do
            try (fileIn runtimePath quiet:true) catch ()
        classOf CPM_OpenManagerLog == MAXScriptFunction
    )

    on execute do
    (
        if loadCompanyPluginManagerRuntime() then CPM_OpenManagerLog()
        else messageBox "无法加载插件管理器运行库，请重新安装。" title:"插件管理器"
    )
)

macroScript CompanyPluginManagerClearLog
category:"Company Tools"
toolTip:"清理插件管理器日志"
buttonText:"清理日志"
(
    global CPM_ClearManagerLog

    fn loadCompanyPluginManagerRuntime =
    (
        local runtimePath = CPM_GetManagerRuntimePath()
        if classOf CPM_ClearManagerLog != MAXScriptFunction and doesFileExist runtimePath do
            try (fileIn runtimePath quiet:true) catch ()
        classOf CPM_ClearManagerLog == MAXScriptFunction
    )

    on execute do
    (
        if loadCompanyPluginManagerRuntime() then CPM_ClearManagerLog()
        else messageBox "无法加载插件管理器运行库，请重新安装。" title:"插件管理器"
    )
)

macroScript CompanyPluginManagerRestart
category:"Company Tools"
toolTip:"重启插件管理器"
buttonText:"重启插件管理器"
(
    global CPM_RestartManager
    global CPM_ManagerRollout

    fn reloadCompanyPluginManagerRuntime =
    (
        local runtimePath = CPM_GetManagerRuntimePath()
        if not doesFileExist runtimePath then return false
        try
        (
            try (destroyDialog CPM_ManagerRollout) catch ()
            fileIn runtimePath quiet:true
            local macroPath = (getFilenamePath runtimePath) + "CompanyPluginManager.mcr"
            if doesFileExist macroPath do try (fileIn macroPath quiet:true) catch ()
            true
        )
        catch (false)
    )

    on execute do
    (
        if reloadCompanyPluginManagerRuntime() and classOf CPM_RestartManager == MAXScriptFunction then
            CPM_RestartManager()
        else
            messageBox "无法重启插件管理器，请重新安装。" title:"插件管理器"
    )
)

macroScript CompanyPluginManagerUninstall
category:"Company Tools"
toolTip:"卸载公司插件管理器"
buttonText:"卸载插件管理器"
(
    global CPM_UninstallManager

    fn loadCompanyPluginManagerRuntime =
    (
        local runtimePath = CPM_GetManagerRuntimePath()
        if classOf CPM_UninstallManager != MAXScriptFunction and doesFileExist runtimePath do
            try (fileIn runtimePath quiet:true) catch ()
        classOf CPM_UninstallManager == MAXScriptFunction
    )

    on execute do
    (
        if loadCompanyPluginManagerRuntime() then CPM_UninstallManager()
        else messageBox "无法加载公司插件管理器运行库，请重新安装后再卸载。" title:"公司插件管理器"
    )
)
