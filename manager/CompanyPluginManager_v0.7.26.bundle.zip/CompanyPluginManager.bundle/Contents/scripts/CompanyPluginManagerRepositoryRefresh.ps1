param(
    [Parameter(Mandatory)]
    [ValidateSet('folder', 'http')]
    [string]$SourceType,

    [Parameter(Mandatory)]
    [string]$Location,

    [Parameter(Mandatory)]
    [string]$OutputDirectory,

    [string]$TokenEnvironment = '',

    [ValidateRange(1, 5)]
    [int]$MaxAttempts = 3,

    [ValidateRange(0, 5000)]
    [int]$RetryDelayMilliseconds = 600,

    [ValidateRange(1, 60)]
    [int]$TimeoutSeconds = 20
)

$ErrorActionPreference = 'Stop'
$catalogOutput = Join-Path $OutputDirectory 'catalog.ini'
$managerOutput = Join-Path $OutputDirectory 'manager.ini'
$catalogStaging = Join-Path $OutputDirectory 'catalog.ini.new'
$managerStaging = Join-Path $OutputDirectory 'manager.ini.new'
$errorOutput = Join-Path $OutputDirectory 'refresh-error.log'
$lastDownloadError = ''
$refreshId = [DateTime]::UtcNow.Ticks.ToString() + '-' + [Guid]::NewGuid().ToString('N')

function Add-CacheBustParameter {
    param(
        [Parameter(Mandatory)]
        [string]$Uri,

        [Parameter(Mandatory)]
        [int]$Attempt
    )

    $builder = [UriBuilder]::new($Uri)
    $existingQuery = $builder.Query.TrimStart('?')
    $cacheBustValue = [Uri]::EscapeDataString("$refreshId-$Attempt")
    $builder.Query = if ([string]::IsNullOrWhiteSpace($existingQuery)) {
        "cpm=$cacheBustValue"
    }
    else {
        "$existingQuery&cpm=$cacheBustValue"
    }
    return $builder.Uri.AbsoluteUri
}

function Get-DownloadFailureText {
    param(
        [Parameter(Mandatory)]
        [System.Management.Automation.ErrorRecord]$ErrorRecord
    )

    $parts = [System.Collections.Generic.List[string]]::new()
    $parts.Add($ErrorRecord.Exception.Message)
    if ($null -ne $ErrorRecord.Exception.Response) {
        try {
            $parts.Add("HTTP $([int]$ErrorRecord.Exception.Response.StatusCode)")
        }
        catch {}
    }
    if (-not [string]::IsNullOrWhiteSpace($ErrorRecord.ErrorDetails.Message)) {
        $parts.Add($ErrorRecord.ErrorDetails.Message.Trim())
    }
    return ($parts | Select-Object -Unique) -join '; '
}

function Invoke-DownloadWithRetry {
    param(
        [Parameter(Mandatory)]
        [string]$Uri,

        [Parameter(Mandatory)]
        [string]$Destination,

        [Parameter(Mandatory)]
        [string]$Label,

        [Parameter(Mandatory)]
        [hashtable]$Headers,

        [switch]$Optional
    )

    $attemptErrors = [System.Collections.Generic.List[string]]::new()
    for ($attempt = 1; $attempt -le $MaxAttempts; $attempt++) {
        Remove-Item -LiteralPath $Destination -Force -ErrorAction SilentlyContinue
        try {
            $requestUri = Add-CacheBustParameter -Uri $Uri -Attempt $attempt
            Invoke-WebRequest `
                -UseBasicParsing `
                -Uri $requestUri `
                -Headers $Headers `
                -TimeoutSec $TimeoutSeconds `
                -OutFile $Destination
            return $true
        }
        catch {
            $attemptErrors.Add(
                "attempt $attempt/${MaxAttempts}: $(Get-DownloadFailureText -ErrorRecord $_)"
            )
            if ($attempt -lt $MaxAttempts -and $RetryDelayMilliseconds -gt 0) {
                Start-Sleep -Milliseconds ($RetryDelayMilliseconds * $attempt)
            }
        }
    }

    $script:lastDownloadError = "$Label download failed after $MaxAttempts attempts | " +
        ($attemptErrors -join ' | ')
    if ($Optional) {
        return $false
    }
    throw $script:lastDownloadError
}

New-Item -ItemType Directory -Path $OutputDirectory -Force | Out-Null
Remove-Item -LiteralPath $catalogStaging -Force -ErrorAction SilentlyContinue
Remove-Item -LiteralPath $managerStaging -Force -ErrorAction SilentlyContinue

try {
    if ($SourceType -eq 'folder') {
        $sourceCatalog = Join-Path $Location 'catalog.ini'
        $sourceManager = Join-Path $Location 'manager.ini'
        if (-not (Test-Path -LiteralPath $sourceCatalog -PathType Leaf)) {
            throw "Repository catalog was not found: $sourceCatalog"
        }
        Copy-Item -LiteralPath $sourceCatalog -Destination $catalogStaging
        if (Test-Path -LiteralPath $sourceManager -PathType Leaf) {
            Copy-Item -LiteralPath $sourceManager -Destination $managerStaging
        }
    }
    else {
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        $headers = @{
            'User-Agent' = 'CompanyPluginManager-RepositoryRefresh'
            'Cache-Control' = 'no-cache'
            'Pragma' = 'no-cache'
        }
        if (-not [string]::IsNullOrWhiteSpace($TokenEnvironment)) {
            $token = [Environment]::GetEnvironmentVariable($TokenEnvironment)
            if (-not [string]::IsNullOrWhiteSpace($token)) {
                $headers.Authorization = "Bearer $token"
            }
        }
        Invoke-DownloadWithRetry `
            -Uri $Location `
            -Destination $catalogStaging `
            -Label 'catalog.ini' `
            -Headers $headers | Out-Null

        $managerUri = [Uri]::new([Uri]$Location, 'manager.ini').AbsoluteUri
        if (-not (Invoke-DownloadWithRetry `
            -Uri $managerUri `
            -Destination $managerStaging `
            -Label 'manager.ini' `
            -Headers $headers `
            -Optional)) {
            Remove-Item -LiteralPath $managerStaging -Force -ErrorAction SilentlyContinue
        }
    }

    if (-not (Test-Path -LiteralPath $catalogStaging -PathType Leaf)) {
        throw 'Repository refresh completed without a staged catalog.ini'
    }
    Move-Item -LiteralPath $catalogStaging -Destination $catalogOutput -Force
    if (Test-Path -LiteralPath $managerStaging -PathType Leaf) {
        Move-Item -LiteralPath $managerStaging -Destination $managerOutput -Force
    }
    Remove-Item -LiteralPath $errorOutput -Force -ErrorAction SilentlyContinue
    exit 0
}
catch {
    $failureText = if (-not [string]::IsNullOrWhiteSpace($lastDownloadError)) {
        $lastDownloadError
    }
    else {
        Get-DownloadFailureText -ErrorRecord $_
    }
    $failureRecord = "$(Get-Date -Format o) | source=$Location | $failureText"
    [IO.File]::WriteAllText(
        $errorOutput,
        $failureRecord,
        [Text.UTF8Encoding]::new($false)
    )
    exit 1
}
finally {
    Remove-Item -LiteralPath $catalogStaging -Force -ErrorAction SilentlyContinue
    Remove-Item -LiteralPath $managerStaging -Force -ErrorAction SilentlyContinue
}
