param(
    [Parameter(Mandatory)]
    [string]$RepositoryPath
)

$ErrorActionPreference = 'Stop'

if ($RepositoryPath -notmatch '^(\\\\[^\\]+\\[^\\]+)') {
    exit 87
}
$shareRoot = $Matches[1]

Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
using System.Text;

public static class CompanyPluginManagerNetworkLogin
{
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    public struct NETRESOURCE
    {
        public int dwScope;
        public int dwType;
        public int dwDisplayType;
        public int dwUsage;
        public string lpLocalName;
        public string lpRemoteName;
        public string lpComment;
        public string lpProvider;
    }

    [DllImport("mpr.dll", CharSet = CharSet.Unicode)]
    public static extern int WNetUseConnection(
        IntPtr hwndOwner,
        ref NETRESOURCE netResource,
        string password,
        string userId,
        int flags,
        StringBuilder accessName,
        ref int bufferSize,
        out int result);

    [DllImport("user32.dll")]
    public static extern IntPtr GetForegroundWindow();
}
'@

if (Test-Path -LiteralPath $RepositoryPath -PathType Container) {
    exit 0
}

$resource = New-Object CompanyPluginManagerNetworkLogin+NETRESOURCE
$resource.dwType = 1
$resource.lpRemoteName = $shareRoot
$accessName = New-Object Text.StringBuilder 1024
$bufferSize = 1024
$connectionResult = 0
$connectInteractive = 0x00000008
$connectPrompt = 0x00000010
$ownerWindow = [CompanyPluginManagerNetworkLogin]::GetForegroundWindow()

$result = [CompanyPluginManagerNetworkLogin]::WNetUseConnection(
    $ownerWindow,
    [ref]$resource,
    $null,
    $null,
    ($connectInteractive -bor $connectPrompt),
    $accessName,
    [ref]$bufferSize,
    [ref]$connectionResult
)

if ($result -ne 0) {
    exit $result
}
if (-not (Test-Path -LiteralPath $RepositoryPath -PathType Container)) {
    exit 5
}
exit 0
