﻿/* Lightweight MacroScript actions. The full runtime is loaded separately. */
global CPM_ManagerMacroRoot
global CPM_GetManagerRuntimePath

(
    local sourcePath = getSourceFileName()
    if sourcePath != undefined do CPM_ManagerMacroRoot = getFilenamePath sourcePath
)

fn CPM_GetManagerRuntimePath =
(
    local bundleRuntime = ""
    if CPM_ManagerMacroRoot != undefined do bundleRuntime = CPM_ManagerMacroRoot + "CompanyPluginManager.ms"
    if bundleRuntime != "" and doesFileExist bundleRuntime then
        bundleRuntime
    else
        (getDir #plugcfg) + "\\CompanyPluginManager\\CompanyPluginManager.ms"
)

macroScript CompanyPluginManager
category:"Company Tools"
toolTip:"公司插件管理器"
buttonText:"打开插件管理器"
(
    global CPM_ShowManager

    fn loadCompanyPluginManagerRuntime =
    (
        local runtimePath = CPM_GetManagerRuntimePath()
        if classOf CPM_ShowManager != MAXScriptFunction and doesFileExist runtimePath do
            try (fileIn runtimePath quiet:true) catch ()
        classOf CPM_ShowManager == MAXScriptFunction
    )

    on execute do
    (
        if loadCompanyPluginManagerRuntime() then CPM_ShowManager()
        else messageBox "无法加载公司插件管理器运行库，请重新安装。" title:"公司插件管理器"
    )
)

macroScript CompanyPluginManagerUpdate
category:"Company Tools"
toolTip:"检查插件管理器更新"
buttonText:"检查管理器更新"
(
    global CPM_CheckManagerUpdate

    fn loadCompanyPluginManagerRuntime =
    (
        local runtimePath = CPM_GetManagerRuntimePath()
        if classOf CPM_CheckManagerUpdate != MAXScriptFunction and doesFileExist runtimePath do
            try (fileIn runtimePath quiet:true) catch ()
        classOf CPM_CheckManagerUpdate == MAXScriptFunction
    )

    on execute do
    (
        if loadCompanyPluginManagerRuntime() then CPM_CheckManagerUpdate()
        else messageBox "无法加载插件管理器运行库，请重新安装。" title:"插件管理器"
    )
)

macroScript CompanyPluginManagerOpenSource
category:"Company Tools"
toolTip:"打开所选插件来源"
buttonText:"打开所选插件来源"
(
    global CPM_OpenSelectedPluginSource

    fn loadCompanyPluginManagerRuntime =
    (
        local runtimePath = CPM_GetManagerRuntimePath()
        if classOf CPM_OpenSelectedPluginSource != MAXScriptFunction and doesFileExist runtimePath do
            try (fileIn runtimePath quiet:true) catch ()
        classOf CPM_OpenSelectedPluginSource == MAXScriptFunction
    )

    on execute do
    (
        if loadCompanyPluginManagerRuntime() then CPM_OpenSelectedPluginSource()
        else messageBox "无法加载插件管理器运行库，请重新安装。" title:"插件管理器"
    )
)

macroScript CompanyPluginManagerSources
category:"Company Tools"
toolTip:"打开插件仓库配置"
buttonText:"仓库配置"
(
    global CPM_OpenSourcesConfig

    fn loadCompanyPluginManagerRuntime =
    (
        local runtimePath = CPM_GetManagerRuntimePath()
        if classOf CPM_OpenSourcesConfig != MAXScriptFunction and doesFileExist runtimePath do
            try (fileIn runtimePath quiet:true) catch ()
        classOf CPM_OpenSourcesConfig == MAXScriptFunction
    )

    on execute do
    (
        if loadCompanyPluginManagerRuntime() then CPM_OpenSourcesConfig()
        else messageBox "无法加载插件管理器运行库，请重新安装。" title:"插件管理器"
    )
)

macroScript CompanyPluginManagerLog
category:"Company Tools"
toolTip:"查看插件管理器日志"
buttonText:"查看日志"
(
    global CPM_OpenManagerLog

    fn loadCompanyPluginManagerRuntime =
    (
        local runtimePath = CPM_GetManagerRuntimePath()
        if classOf CPM_OpenManagerLog != MAXScriptFunction and doesFileExist runtimePath do
            try (fileIn runtimePath quiet:true) catch ()
        classOf CPM_OpenManagerLog == MAXScriptFunction
    )

    on execute do
    (
        if loadCompanyPluginManagerRuntime() then CPM_OpenManagerLog()
        else messageBox "无法加载插件管理器运行库，请重新安装。" title:"插件管理器"
    )
)

macroScript CompanyPluginManagerUninstall
category:"Company Tools"
toolTip:"卸载公司插件管理器"
buttonText:"卸载插件管理器"
(
    global CPM_UninstallManager

    fn loadCompanyPluginManagerRuntime =
    (
        local runtimePath = CPM_GetManagerRuntimePath()
        if classOf CPM_UninstallManager != MAXScriptFunction and doesFileExist runtimePath do
            try (fileIn runtimePath quiet:true) catch ()
        classOf CPM_UninstallManager == MAXScriptFunction
    )

    on execute do
    (
        if loadCompanyPluginManagerRuntime() then CPM_UninstallManager()
        else messageBox "无法加载公司插件管理器运行库，请重新安装后再卸载。" title:"公司插件管理器"
    )
)
