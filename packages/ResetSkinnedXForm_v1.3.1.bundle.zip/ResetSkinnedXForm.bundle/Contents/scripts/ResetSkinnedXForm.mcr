﻿/*
    Reset Skinned XForm
    Version 1.3.1

    Safely normalizes the transform of a skinned geometry node, repairs flipped
    faces when required, and transfers Skin to an identical unskinned mesh.

    Designed for 3ds Max 2020+.
*/

global RSXF_Core
global RSXF_Rollout

struct RSXF_CoreStruct
(
    version = "1.3.1",
    positionTolerance = 0.001,
    transformTolerance = 0.00001,
    transferTolerance = 0.001,
    weightTolerance = 0.00001,
    weightZeroTolerance = 0.0000001,

    fn appendLine text value =
    (
        text + value + "\r\n"
    ),

    fn matrixDifference a b =
    (
        local d = 0.0
        d = amax d (distance a.row1 b.row1)
        d = amax d (distance a.row2 b.row2)
        d = amax d (distance a.row3 b.row3)
        d = amax d (distance a.row4 b.row4)
        d
    ),

    fn getLocalTM node =
    (
        if node.parent == undefined then node.transform
        else node.transform * (inverse node.parent.transform)
    ),

    fn getParity tm =
    (
        try (tm.determinantsign) catch (0)
    ),

    fn getRotationAngle rotationValue =
    (
        local angleValue = try (abs ((rotationValue as angleaxis).angle)) catch (360.0)
        if angleValue > 180.0 do angleValue = 360.0 - angleValue
        abs angleValue
    ),

    fn scaleNeedsNormalization node =
    (
        distance node.scale [1,1,1] > transformTolerance
    ),

    fn pivotNeedsNormalization node =
    (
        distance node.pivot [0,0,0] > positionTolerance
    ),

    fn rotationNeedsNormalization node =
    (
        getRotationAngle node.rotation > transformTolerance
    ),

    fn transformNeedsNormalization node =
    (
        scaleNeedsNormalization node or pivotNeedsNormalization node or rotationNeedsNormalization node
    ),

    fn shouldFlipFaces node forceFlip:false =
    (
        forceFlip or (getParity node.transform < 0)
    ),

    fn getSystemUnitName =
    (
        case units.SystemType of
        (
            #kilometers: "千米"
            #meters: "米"
            #centimeters: "厘米"
            #millimeters: "毫米"
            #inches: "英寸"
            #feet: "英尺"
            default: (units.SystemType as string)
        )
    ),

    fn unitsAreCentimeters =
    (
        units.SystemType == #centimeters and units.DisplayType == #Metric
    ),

    fn setUnitsToCentimeters =
    (
        units.SystemScale = 1.0
        units.SystemType = #centimeters
        units.DisplayType = #Metric
        try (units.MetricType = #centimeters) catch ()
        unitsAreCentimeters()
    ),

    fn getSkinModifiers node =
    (
        for modifierItem in node.modifiers where (classof modifierItem == Skin) collect modifierItem
    ),

    fn hasEditNormals node =
    (
        for modifierItem in node.modifiers do
        (
            if classof modifierItem == Edit_Normals do return true
        )
        false
    ),

    fn transformIsAnimated node referenceFrame =
    (
        local originalTime = currentTime
        local sampleTimes = #(animationRange.start, referenceFrame, animationRange.end)
        local firstTM = undefined
        local animatedTransform = false

        for sampleTime in sampleTimes while not animatedTransform do
        (
            at time sampleTime
            (
                local sampledTM = getLocalTM node
                if firstTM == undefined then firstTM = sampledTM
                else if matrixDifference firstTM sampledTM > 0.00001 do animatedTransform = true
            )
        )
        sliderTime = originalTime
        animatedTransform
    ),

    fn getInstanceCount node =
    (
        local instanceNodes = #()
        try
        (
            InstanceMgr.GetInstances node &instanceNodes
            instanceNodes.count
        )
        catch
        (
            1
        )
    ),

    fn getDirectChildrenWorldTMs node =
    (
        local childData = #()
        for childNode in node.children do append childData #(childNode, childNode.transform)
        childData
    ),

    fn restoreDirectChildrenWorldTMs childData =
    (
        for item in childData do
        (
            if isValidNode item[1] do
            (
                try (item[1].transform = item[2]) catch ()
            )
        )
    ),

    fn getEvaluatedMeshInfo node sampleLimit:64 =
    (
        local meshValue = snapshotAsMesh node
        local vertexCount = meshValue.numverts
        local faceCount = meshValue.numfaces
        local points = #()
        local stepSize = 1

        if vertexCount > sampleLimit do stepSize = amax 1 (floor (vertexCount as float / sampleLimit))
        for vertexIndex = 1 to vertexCount by stepSize do
        (
            -- snapshotAsMesh returns the evaluated world-state geometry.
            append points (getVert meshValue vertexIndex)
            if points.count >= sampleLimit do exit
        )
        meshValue = undefined
        #(vertexCount, faceCount, points)
    ),

    fn maxPointDifference firstPoints secondPoints =
    (
        if firstPoints.count != secondPoints.count then return 1e9
        local maximumDifference = 0.0
        for pointIndex = 1 to firstPoints.count do
        (
            maximumDifference = amax maximumDifference (distance firstPoints[pointIndex] secondPoints[pointIndex])
        )
        maximumDifference
    ),

    fn capturePoseSamples node referenceFrame extraFrame =
    (
        local originalTime = currentTime
        local sampleTimes = #()
        local result = #()
        local middleFrame = (animationRange.start + animationRange.end) / 2

        for sampleTime in #(referenceFrame, extraFrame, animationRange.start, middleFrame, animationRange.end) do
        (
            if findItem sampleTimes sampleTime == 0 do append sampleTimes sampleTime
        )

        for sampleTime in sampleTimes do
        (
            sliderTime = sampleTime
            append result #(sampleTime, getEvaluatedMeshInfo node)
        )
        sliderTime = originalTime
        result
    ),

    fn validatePoseSamples node savedSamples =
    (
        local originalTime = currentTime
        local maximumError = 0.0
        local countsMatch = true

        for sampleItem in savedSamples while countsMatch do
        (
            sliderTime = sampleItem[1]
            local currentInfo = getEvaluatedMeshInfo node
            local savedInfo = sampleItem[2]
            if currentInfo[1] != savedInfo[1] or currentInfo[2] != savedInfo[2] then
                countsMatch = false
            else
                maximumError = amax maximumError (maxPointDifference savedInfo[3] currentInfo[3])
        )
        sliderTime = originalTime
        #(countsMatch, maximumError)
    ),

    fn activateSkinContext node skinModifier =
    (
        if node == undefined or not isValidNode node do throw "无法激活无效的 Skin 节点。"
        select node
        max modify mode
        modPanel.setCurrentObject skinModifier node:node ui:true
        try (windows.processPostedMessages()) catch ()
        true
    ),

    fn normalizeSkinBooleanState value =
    (
        if value == undefined then undefined
        else if value == true then true
        else if value == false then false
        else value != 0
    ),

    fn captureSkinWeights skinModifier node:undefined =
    (
        if node != undefined do activateSkinContext node skinModifier
        local vertexCount = skinOps.GetNumberVertices skinModifier
        local result = #()
        progressStart "蒙皮模型检查与修复：正在记录 Skin 权重……"
        for vertexIndex = 1 to vertexCount do
        (
            local influenceCount = skinOps.GetVertexWeightCount skinModifier vertexIndex
            local boneIDs = #()
            local weights = #()
            local dqWeight = undefined
            local isUnnormalized = undefined
            local isRigid = undefined

            for influenceIndex = 1 to influenceCount do
            (
                append boneIDs (skinOps.GetVertexWeightBoneID skinModifier vertexIndex influenceIndex)
                append weights (skinOps.GetVertexWeight skinModifier vertexIndex influenceIndex)
            )
            dqWeight = try (skinOps.getVertexDQWeight skinModifier vertexIndex) catch (undefined)
            isUnnormalized = try
            (
                if node != undefined then
                    skinOps.isUnNormalizeVertex skinModifier vertexIndex node:node
                else
                    skinOps.isUnNormalizeVertex skinModifier vertexIndex
            )
            catch (undefined)
            isUnnormalized = normalizeSkinBooleanState isUnnormalized
            isRigid = try
            (
                if node != undefined then
                    skinOps.isRigidVertex skinModifier vertexIndex node:node
                else
                    skinOps.isRigidVertex skinModifier vertexIndex
            )
            catch (undefined)
            isRigid = normalizeSkinBooleanState isRigid
            append result #(boneIDs, weights, dqWeight, isUnnormalized, isRigid)

            if mod vertexIndex 250 == 0 do progressUpdate (100.0 * vertexIndex / vertexCount)
        )
        progressEnd()
        result
    ),

    fn validateSkinWeights skinModifier savedWeights node:undefined =
    (
        if node != undefined do activateSkinContext node skinModifier
        local vertexCount = skinOps.GetNumberVertices skinModifier
        if vertexCount != savedWeights.count then
            return #(false, ("顶点数不一致：源 " + savedWeights.count as string + "，目标 " + vertexCount as string + "。"), 1e9, 1e9)

        local maximumWeightDifference = 0.0
        local maximumDQDifference = 0.0
        for vertexIndex = 1 to vertexCount do
        (
            local savedVertex = savedWeights[vertexIndex]
            local influenceCount = skinOps.GetVertexWeightCount skinModifier vertexIndex
            local savedNonZeroCount = 0
            local currentNonZeroCount = 0
            for savedInfluenceIndex = 1 to savedVertex[1].count do
            (
                if abs savedVertex[2][savedInfluenceIndex] > weightZeroTolerance do savedNonZeroCount += 1
            )
            for influenceIndex = 1 to influenceCount do
            (
                if abs (skinOps.GetVertexWeight skinModifier vertexIndex influenceIndex) > weightZeroTolerance do currentNonZeroCount += 1
            )

            if currentNonZeroCount != savedNonZeroCount then
            (
                return #(false,
                    ("顶点 " + vertexIndex as string + " 的非零骨骼影响数量不一致：源 " +
                    savedNonZeroCount as string + "，目标 " + currentNonZeroCount as string + "。"), maximumWeightDifference, maximumDQDifference)
            )
            else
            (
                for savedInfluenceIndex = 1 to savedVertex[1].count do
                (
                    local savedWeight = savedVertex[2][savedInfluenceIndex]
                    if abs savedWeight > weightZeroTolerance do
                    (
                        local savedBoneID = savedVertex[1][savedInfluenceIndex]
                        local matchedInfluenceIndex = 0
                        for influenceIndex = 1 to influenceCount while matchedInfluenceIndex == 0 do
                        (
                            if skinOps.GetVertexWeightBoneID skinModifier vertexIndex influenceIndex == savedBoneID do
                                matchedInfluenceIndex = influenceIndex
                        )
                        if matchedInfluenceIndex == 0 then
                        (
                            return #(false,
                                ("顶点 " + vertexIndex as string + " 缺少骨骼 ID " +
                                savedBoneID as string + " 的权重。"), maximumWeightDifference, maximumDQDifference)
                        )
                        else
                        (
                            local currentWeight = skinOps.GetVertexWeight skinModifier vertexIndex matchedInfluenceIndex
                            local weightDifference = abs (currentWeight - savedWeight)
                            maximumWeightDifference = amax maximumWeightDifference weightDifference
                            if weightDifference > weightTolerance do
                                return #(false,
                                    ("顶点 " + vertexIndex as string + "、骨骼 ID " + savedBoneID as string +
                                    " 的权重不一致：源 " + savedWeight as string + "，目标 " +
                                    currentWeight as string + "，差值 " + weightDifference as string + "。"),
                                    maximumWeightDifference, maximumDQDifference)
                        )
                    )
                )

                if savedVertex[3] != undefined do
                (
                    local currentDQ = try (skinOps.getVertexDQWeight skinModifier vertexIndex) catch (undefined)
                    if currentDQ == undefined then
                        return #(false, ("顶点 " + vertexIndex as string + " 无法读取目标 DQ 权重。"), maximumWeightDifference, maximumDQDifference)
                    local dqDifference = abs (currentDQ - savedVertex[3])
                    maximumDQDifference = amax maximumDQDifference dqDifference
                    if dqDifference > weightTolerance do
                        return #(false,
                            ("顶点 " + vertexIndex as string + " 的 DQ 权重不一致：源 " +
                            savedVertex[3] as string + "，目标 " + currentDQ as string +
                            "，差值 " + dqDifference as string + "。"),
                            maximumWeightDifference, maximumDQDifference)
                )

                if savedVertex.count >= 4 and savedVertex[4] != undefined do
                (
                    local currentUnnormalized = try
                    (
                        if node != undefined then
                            skinOps.isUnNormalizeVertex skinModifier vertexIndex node:node
                        else
                            skinOps.isUnNormalizeVertex skinModifier vertexIndex
                    )
                    catch (undefined)
                    currentUnnormalized = normalizeSkinBooleanState currentUnnormalized
                    if currentUnnormalized == undefined then
                        return #(false, ("顶点 " + vertexIndex as string + " 无法读取归一化状态。"), maximumWeightDifference, maximumDQDifference)
                    if currentUnnormalized != savedVertex[4] then
                        return #(false, ("顶点 " + vertexIndex as string + " 的归一化状态不一致。"), maximumWeightDifference, maximumDQDifference)
                )

                if savedVertex.count >= 5 and savedVertex[5] != undefined do
                (
                    local currentRigid = try
                    (
                        if node != undefined then
                            skinOps.isRigidVertex skinModifier vertexIndex node:node
                        else
                            skinOps.isRigidVertex skinModifier vertexIndex
                    )
                    catch (undefined)
                    currentRigid = normalizeSkinBooleanState currentRigid
                    if currentRigid == undefined then
                        return #(false, ("顶点 " + vertexIndex as string + " 无法读取刚性状态。"), maximumWeightDifference, maximumDQDifference)
                    if currentRigid != savedVertex[5] then
                        return #(false, ("顶点 " + vertexIndex as string + " 的刚性状态不一致。"), maximumWeightDifference, maximumDQDifference)
                )
            )
        )
        #(true, "", maximumWeightDifference, maximumDQDifference)
    ),

    fn skinWeightsMatch skinModifier savedWeights node:undefined =
    (
        (validateSkinWeights skinModifier savedWeights node:node)[1]
    ),

    fn applySkinWeights skinModifier savedWeights node:undefined =
    (
        if node != undefined do activateSkinContext node skinModifier
        local vertexCount = skinOps.GetNumberVertices skinModifier
        if vertexCount != savedWeights.count do throw "目标 Skin 顶点数与源权重记录不一致。"

        local failureText = ""
        progressStart "蒙皮模型检查与修复：正在写入 Skin 权重……"
        try
        (
            for vertexIndex = 1 to vertexCount do
            (
                local savedVertex = savedWeights[vertexIndex]
                if savedVertex.count >= 4 and savedVertex[4] != undefined do
                (
                    if node != undefined then
                        skinOps.unNormalizeVertex skinModifier vertexIndex savedVertex[4] node:node
                    else
                        skinOps.unNormalizeVertex skinModifier vertexIndex savedVertex[4]
                )
                if savedVertex[1].count > 0 do
                (
                    if node != undefined then
                        skinOps.ReplaceVertexWeights skinModifier vertexIndex savedVertex[1] savedVertex[2] node:node
                    else
                        skinOps.ReplaceVertexWeights skinModifier vertexIndex savedVertex[1] savedVertex[2]
                    for influenceIndex = 1 to savedVertex[1].count do
                    (
                        if abs savedVertex[2][influenceIndex] <= weightZeroTolerance do
                        (
                            if node != undefined then
                                skinOps.SetVertexWeights skinModifier vertexIndex savedVertex[1][influenceIndex] 0.0 node:node
                            else
                                skinOps.SetVertexWeights skinModifier vertexIndex savedVertex[1][influenceIndex] 0.0
                        )
                    )
                )
                if savedVertex[3] != undefined do
                    skinOps.setVertexDQWeight skinModifier vertexIndex savedVertex[3]
                if savedVertex.count >= 5 and savedVertex[5] != undefined do
                (
                    -- Max 2020 exposes the third argument as the desired Boolean
                    -- state, despite newer help pages documenting node:/name:.
                    skinOps.rigidVertex skinModifier vertexIndex savedVertex[5]
                )
                if mod vertexIndex 250 == 0 do progressUpdate (100.0 * vertexIndex / vertexCount)
            )
        )
        catch
        (
            failureText = getCurrentException()
        )
        progressEnd()
        if failureText != "" do throw failureText
        true
    ),

    fn captureBindSummary node skinModifier =
    (
        local meshBindTM = try (skinUtils.GetMeshBindTM node) catch (undefined)
        local boneCount = try (skinOps.GetNumberBones skinModifier) catch (0)
        local boneData = #()
        for boneIndex = 1 to boneCount do
        (
            local boneNode = try (skinOps.GetBoneNode skinModifier boneIndex) catch (undefined)
            local bindTM = if boneNode != undefined then (try (skinUtils.GetBoneBindTM node boneNode) catch (undefined)) else undefined
            append boneData #(boneNode, bindTM)
        )
        #(meshBindTM, boneData)
    ),

    fn captureComparableBaseMesh node removeSkin:false =
    (
        local clonedNodes = #()
        local cloneNode = undefined
        local result = undefined
        local failureText = ""

        try
        (
            maxOps.cloneNodes #(node) cloneType:#copy newNodes:&clonedNodes
            if clonedNodes.count != 1 do throw "无法创建用于模型匹配检查的临时副本。"
            cloneNode = clonedNodes[1]
            cloneNode.renderable = false

            if removeSkin do
            (
                local cloneSkins = getSkinModifiers cloneNode
                if cloneSkins.count != 1 do throw "源模型临时副本中没有找到唯一 Skin。"
                deleteModifier cloneNode (modPanel.getModifierIndex cloneNode cloneSkins[1])
            )

            local meshValue = snapshotAsMesh cloneNode
            local points = for vertexIndex = 1 to meshValue.numverts collect (getVert meshValue vertexIndex)
            local faces = for faceIndex = 1 to meshValue.numfaces collect (getFace meshValue faceIndex)
            result = #(meshValue.numverts, meshValue.numfaces, points, faces)
            meshValue = undefined
        )
        catch
        (
            failureText = getCurrentException()
        )

        if cloneNode != undefined and isValidNode cloneNode do delete cloneNode
        if failureText != "" do throw failureText
        result
    ),

    fn compareStrictBaseMeshes sourceNode targetNode =
    (
        local sourceInfo = captureComparableBaseMesh sourceNode removeSkin:true
        local targetInfo = captureComparableBaseMesh targetNode removeSkin:false
        local countsMatch = sourceInfo[1] == targetInfo[1] and sourceInfo[2] == targetInfo[2]
        local topologyMatch = countsMatch
        local maximumError = if countsMatch then 0.0 else 1e9

        if countsMatch do
        (
            for faceIndex = 1 to sourceInfo[2] while topologyMatch do
            (
                if sourceInfo[4][faceIndex] != targetInfo[4][faceIndex] do topologyMatch = false
            )
            for vertexIndex = 1 to sourceInfo[1] do
            (
                maximumError = amax maximumError (distance sourceInfo[3][vertexIndex] targetInfo[3][vertexIndex])
            )
        )

        #(countsMatch and topologyMatch and maximumError <= transferTolerance, sourceInfo[1], sourceInfo[2], topologyMatch, maximumError)
    ),

    fn skinBonesMatch sourceSkin targetSkin =
    (
        local sourceBoneCount = try (skinOps.GetNumberBones sourceSkin) catch (0)
        local targetBoneCount = try (skinOps.GetNumberBones targetSkin) catch (0)
        if sourceBoneCount != targetBoneCount do return false

        for boneIndex = 1 to sourceBoneCount do
        (
            local sourceBone = try (skinOps.GetBoneNode sourceSkin boneIndex) catch (undefined)
            local targetBone = try (skinOps.GetBoneNode targetSkin boneIndex) catch (undefined)
            if sourceBone == undefined or targetBone == undefined or sourceBone != targetBone do return false
        )
        true
    ),

    fn copySkinBindData sourceNode targetNode sourceSkin targetSkin =
    (
        local sourceMeshBindTM = skinUtils.GetMeshBindTM sourceNode
        skinUtils.SetMeshBindTM targetNode sourceMeshBindTM

        local boneCount = skinOps.GetNumberBones sourceSkin
        if skinOps.GetNumberBones targetSkin != boneCount do throw "复制绑定矩阵时源、目标骨骼数量不一致。"
        for boneIndex = 1 to boneCount do
        (
            local boneNode = skinOps.GetBoneNode sourceSkin boneIndex
            if boneNode == undefined do throw ("源 Skin 的骨骼引用无效，索引：" + boneIndex as string)
            skinUtils.SetBoneBindTM targetNode boneNode (skinUtils.GetBoneBindTM sourceNode boneNode)
            local stretchTM = try (skinUtils.GetBoneStretchTM sourceNode boneNode) catch (undefined)
            if stretchTM != undefined do skinUtils.SetBoneStretchTM targetNode boneNode stretchTM
        )
        true
    ),

    fn skinBindDataMatch sourceNode targetNode sourceSkin targetSkin =
    (
        local sourceMeshBindTM = try (skinUtils.GetMeshBindTM sourceNode) catch (undefined)
        local targetMeshBindTM = try (skinUtils.GetMeshBindTM targetNode) catch (undefined)
        if sourceMeshBindTM == undefined or targetMeshBindTM == undefined do return false
        if matrixDifference sourceMeshBindTM targetMeshBindTM > transformTolerance do return false

        local boneCount = try (skinOps.GetNumberBones sourceSkin) catch (0)
        if (try (skinOps.GetNumberBones targetSkin) catch (-1)) != boneCount do return false
        for boneIndex = 1 to boneCount do
        (
            local boneNode = try (skinOps.GetBoneNode sourceSkin boneIndex) catch (undefined)
            if boneNode == undefined do return false
            local sourceBoneBindTM = try (skinUtils.GetBoneBindTM sourceNode boneNode) catch (undefined)
            local targetBoneBindTM = try (skinUtils.GetBoneBindTM targetNode boneNode) catch (undefined)
            if sourceBoneBindTM == undefined or targetBoneBindTM == undefined do return false
            if matrixDifference sourceBoneBindTM targetBoneBindTM > transformTolerance do return false
        )
        true
    ),

    fn getNamedModifier node modifierName modifierClass =
    (
        for modifierItem in node.modifiers do
        (
            if modifierItem.name == modifierName and classof modifierItem == modifierClass do return modifierItem
        )
        undefined
    ),

    fn hasExistingRepairStack node =
    (
        if node == undefined or not isValidNode node then return false
        local skins = getSkinModifiers node
        if skins.count != 1 or node.modifiers.count != 3 then return false
        local faceFlip = getNamedModifier node "RSXF - Flip Faces" Normalmodifier
        local resetTransform = getNamedModifier node "RSXF - Reset XForm" XForm
        if faceFlip == undefined or resetTransform == undefined then return false
        local flipIndex = modPanel.getModifierIndex node faceFlip
        local skinIndex = modPanel.getModifierIndex node skins[1]
        local resetIndex = modPanel.getModifierIndex node resetTransform
        flipIndex < skinIndex and skinIndex < resetIndex
    ),

    fn captureRenderedNormalSamples node sampleLimit:64 =
    (
        local meshValue = snapshotAsMesh node
        local faceCount = meshValue.numfaces
        local stepSize = 1
        local samples = #()
        if faceCount > sampleLimit do stepSize = amax 1 (floor (faceCount as float / sampleLimit))

        for faceIndex = 1 to faceCount by stepSize do
        (
            local renderNormals = meshop.getFaceRNormals meshValue faceIndex
            local averageNormal = normalize (renderNormals[1] + renderNormals[2] + renderNormals[3])
            append samples #(faceIndex, meshop.getFaceCenter meshValue faceIndex, averageNormal)
            if samples.count >= sampleLimit do exit
        )
        meshValue = undefined
        #(faceCount, samples)
    ),

    fn validateRenderedNormalSamples node savedInfo =
    (
        local meshValue = snapshotAsMesh node
        if meshValue.numfaces != savedInfo[1] then
        (
            meshValue = undefined
            return #(false, -1.0, 1e9)
        )

        local minimumDot = 1.0
        local maximumCenterError = 0.0
        for sampleItem in savedInfo[2] do
        (
            local faceIndex = sampleItem[1]
            local renderNormals = meshop.getFaceRNormals meshValue faceIndex
            local averageNormal = normalize (renderNormals[1] + renderNormals[2] + renderNormals[3])
            local currentCenter = meshop.getFaceCenter meshValue faceIndex
            minimumDot = amin minimumDot (dot sampleItem[3] averageNormal)
            maximumCenterError = amax maximumCenterError (distance sampleItem[2] currentCenter)
        )
        meshValue = undefined
        #(minimumDot > 0.999 and maximumCenterError <= positionTolerance, minimumDot, maximumCenterError)
    ),

    fn bakeRepairStack node =
    (
        local skins = getSkinModifiers node
        if skins.count != 1 do throw "烘焙时必须且只能有一个 Skin 修改器。"
        local skinModifier = skins[1]
        local faceFlip = getNamedModifier node "RSXF - Flip Faces" Normalmodifier
        local resetTransform = getNamedModifier node "RSXF - Reset XForm" XForm
        if resetTransform == undefined do throw "没有找到预期的 RSXF 重置变换修改器。"

        if faceFlip != undefined do
        (
            local bakedFlip = copy faceFlip
            deleteModifier node (modPanel.getModifierIndex node faceFlip)
            skinModifier = (getSkinModifiers node)[1]
            local flipSkinIndex = modPanel.getModifierIndex node skinModifier
            addModifier node bakedFlip before:flipSkinIndex
        )

        skinModifier = (getSkinModifiers node)[1]
        local skinIndex = modPanel.getModifierIndex node skinModifier
        local editablePolyOutput = Edit_Poly()
        editablePolyOutput.name = "RSXF - Bake To Editable Poly"
        addModifier node editablePolyOutput before:skinIndex
        local bakeIndex = modPanel.getModifierIndex node editablePolyOutput
        if not maxOps.CollapseNodeTo node bakeIndex true do throw "无法将修复修改器烘焙到基础对象。"

        if classof node.baseObject != Editable_Poly do throw "烘焙后的基础对象不是可编辑多边形。"
        skins = getSkinModifiers node
        if skins.count != 1 or node.modifiers.count != 1 do throw "最终堆栈不是仅包含 Skin 和可编辑多边形。"
        if classof node.modifiers[1] != Skin do throw "Skin 不是唯一保留的修改器。"
        skins[1]
    ),

    fn createBackupCopy node =
    (
        local clonedNodes = #()
        maxOps.cloneNodes #(node) cloneType:#copy newNodes:&clonedNodes
        if clonedNodes.count != 1 then throw "无法创建安全备份副本。"

        local backupNode = clonedNodes[1]
        backupNode.name = uniqueName (node.name + "_RSXF_BACKUP")
        backupNode.renderable = false
        hide backupNode
        freeze backupNode
        backupNode
    ),

    fn addPivotCompensation node =
    (
        local skins = getSkinModifiers node
        if skins.count != 1 do throw "轴心归零时必须且只能有一个 Skin 修改器。"

        local pivotOffset = node.position
        local skinIndex = modPanel.getModifierIndex node skins[1]
        local pivotModifier = XForm()
        pivotModifier.name = "RSXF - Zero Pivot"
        addModifier node pivotModifier before:skinIndex
        pivotModifier.gizmo.position = pivotOffset
        node.position = [0,0,0]

        if distance node.pivot [0,0,0] > positionTolerance do throw "补偿平移后轴心坐标仍未归零。"
        pivotModifier
    ),

    fn analyze node forceFlip:false =
    (
        local report = ""
        local blockers = #()
        local warnings = #()

        if node == undefined or not isValidNode node then
        (
            append blockers "请选择一个有效的场景节点。"
            return #(false, blockers, warnings, "未选择有效节点。\r\n")
        )

        report = appendLine report ("对象：" + node.name)
        report = appendLine report ("工具版本：" + version)

        if superclassof node != GeometryClass do append blockers "所选节点不是几何体。"
        if isGroupHead node do append blockers "不支持组头节点，请打开组并选择网格节点。"

        local skins = getSkinModifiers node
        local existingRepair = hasExistingRepairStack node
        report = appendLine report ("Skin 修改器数量：" + skins.count as string)
        report = appendLine report ("已有 RSXF 修复堆栈：" + existingRepair as string)
        if skins.count != 1 do append blockers "必须且只能有一个 Skin 修改器。"
        if skins.count == 1 and not existingRepair and node.modifiers.count != 1 do append blockers "为保持最终堆栈干净，修复前除 Skin 外不能有其他修改器。"

        local worldParity = getParity node.transform
        local localParity = getParity (getLocalTM node)
        local parentParity = if node.parent == undefined then 1 else getParity node.parent.transform
        local needsScale = scaleNeedsNormalization node
        local needsPivot = pivotNeedsNormalization node
        local needsRotation = rotationNeedsNormalization node
        local needsFlip = shouldFlipFaces node forceFlip:forceFlip
        report = appendLine report ("世界变换奇偶性：" + worldParity as string)
        report = appendLine report ("本地变换奇偶性：" + localParity as string)
        report = appendLine report ("父级变换奇偶性：" + parentParity as string)
        report = appendLine report ("节点缩放：" + node.scale as string + "；需要归一：" + needsScale as string)
        report = appendLine report ("轴心坐标：" + node.pivot as string + "；需要归零：" + needsPivot as string)
        report = appendLine report ("节点旋转：" + (node.rotation as eulerAngles) as string + "；需要归零：" + needsRotation as string)
        report = appendLine report ("场景系统单位：" + getSystemUnitName() + "；厘米规范：" + unitsAreCentimeters() as string)
        report = appendLine report ("处理时翻面：" + needsFlip as string)

        if parentParity < 0 do append blockers "负奇偶性继承自父级；当前版本不会修改层级变换。"
        if localParity == 0 or worldParity == 0 do append blockers "变换矩阵为奇异矩阵，无法安全重置。"
        if not needsScale and not needsPivot and not needsRotation and not needsFlip and not existingRepair do
            append blockers "缩放、轴心、旋转和面朝向均未检测到需要修复的问题。"
        if not unitsAreCentimeters() do append warnings "场景系统单位不是厘米；请先使用“场景单位设为厘米”。该操作只修复场景单位设置，不会猜测或改变资产实际大小。"

        local referenceFrame = if skins.count == 1 then (try (skins[1].ref_frame) catch (0)) else 0
        report = appendLine report ("Skin 参考帧：" + referenceFrame as string)
        if transformIsAnimated node referenceFrame do append blockers "网格节点变换带有动画，或继承自动画父级。"
        if skins.count == 1 and not existingRepair do
        (
            local originalTime = currentTime
            local meshBindTM = undefined
            sliderTime = referenceFrame
            meshBindTM = try (skinUtils.GetMeshBindTM node) catch (undefined)
            local bindTransformError = if meshBindTM != undefined then matrixDifference node.transform meshBindTM else 0.0
            sliderTime = originalTime
            report = appendLine report ("节点与 Skin 绑定变换误差：" + bindTransformError as string)
            if meshBindTM != undefined and bindTransformError > transformTolerance do
                append blockers "节点变换是在绑定 Skin 后修改的；当前安全流程不会重写绑定矩阵，请先回到绑定时的节点变换或使用未蒙皮副本重新传递 Skin。"
        )

        local instanceCount = getInstanceCount node
        report = appendLine report ("共享该对象的实例数量：" + instanceCount as string)
        if instanceCount > 1 do append blockers "该对象存在实例，请转为唯一对象后再修复。"

        if hasEditNormals node do append blockers "检测到“编辑法线”修改器；当前版本不支持保留显式法线。"

        if node.children.count > 0 and not existingRepair do append warnings ((node.children.count as string) + " 个直接子节点将在重置变换后恢复世界变换。")
        if skins.count == 1 do
        (
            local vertexCount = try (skinOps.GetNumberVertices skins[1]) catch (0)
            local boneCount = try (skinOps.GetNumberBones skins[1]) catch (0)
            report = appendLine report ("Skin 顶点数：" + vertexCount as string)
            report = appendLine report ("Skin 骨骼数：" + boneCount as string)
            if vertexCount < 1 do append blockers "Skin 中没有顶点。"
            if boneCount < 1 do append blockers "Skin 中没有骨骼。"
            local gizmoCount = try (skinOps.getNumberOfGizmos skins[1]) catch (0)
            report = appendLine report ("Skin Gizmo 数量：" + gizmoCount as string)
            if gizmoCount > 0 do append warnings "Skin 中存在 Gizmo；它们会被保留，但修复后必须测试全部驱动姿势。"
        )

        if blockers.count == 0 then report = appendLine report "状态：可以安全处理"
        else report = appendLine report "状态：已阻止"

        if warnings.count > 0 do
        (
            report = appendLine report ""
            report = appendLine report "警告："
            for warningText in warnings do report = appendLine report ("- " + warningText)
        )

        if blockers.count > 0 do
        (
            report = appendLine report ""
            report = appendLine report "阻止原因："
            for blockerText in blockers do report = appendLine report ("- " + blockerText)
        )

        #(blockers.count == 0, blockers, warnings, report)
    ),

    fn analyzeSkinTransfer sourceNode targetNode =
    (
        local report = ""
        local blockers = #()
        local warnings = #()

        if sourceNode == undefined or not isValidNode sourceNode then append blockers "请选择有效的 Skin 源模型。"
        if targetNode == undefined or not isValidNode targetNode then append blockers "请选择有效的无 Skin 目标模型。"
        if sourceNode != undefined and targetNode != undefined and sourceNode == targetNode do append blockers "源模型和目标模型不能是同一个对象。"

        if blockers.count == 0 do
        (
            report = appendLine report ("Skin 源模型：" + sourceNode.name)
            report = appendLine report ("目标模型：" + targetNode.name)
            report = appendLine report ("工具版本：" + version)

            if superclassof sourceNode != GeometryClass do append blockers "Skin 源模型不是几何体。"
            if superclassof targetNode != GeometryClass do append blockers "目标模型不是几何体。"
            if isGroupHead sourceNode or isGroupHead targetNode do append blockers "不支持组头节点。"

            local sourceSkins = getSkinModifiers sourceNode
            local targetSkins = getSkinModifiers targetNode
            report = appendLine report ("源 Skin 数量：" + sourceSkins.count as string)
            report = appendLine report ("目标 Skin 数量：" + targetSkins.count as string)
            if sourceSkins.count != 1 do append blockers "源模型必须且只能有一个 Skin 修改器。"
            if targetSkins.count != 0 do append blockers "目标模型必须没有 Skin 修改器。"
            if sourceSkins.count == 1 and sourceNode.modifiers.count != 1 do append blockers "严格传递模式要求源模型除 Skin 外没有其他修改器。"
            if targetNode.modifiers.count != 0 do append blockers "严格传递模式要求目标模型没有任何修改器。"

            if getInstanceCount sourceNode > 1 do append blockers "Skin 源模型存在实例。"
            if getInstanceCount targetNode > 1 do append blockers "目标模型存在实例。"
            if hasEditNormals sourceNode or hasEditNormals targetNode do append blockers "严格传递模式不支持显式编辑法线。"

            local referenceFrame = if sourceSkins.count == 1 then (try (sourceSkins[1].ref_frame) catch (0)) else 0
            report = appendLine report ("Skin 参考帧：" + referenceFrame as string)
            if transformIsAnimated sourceNode referenceFrame do append blockers "Skin 源模型的节点变换带动画或继承自动画父级。"
            if transformIsAnimated targetNode referenceFrame do append blockers "目标模型的节点变换带动画或继承自动画父级。"

            if sourceSkins.count == 1 do
            (
                local sourceBoneCount = try (skinOps.GetNumberBones sourceSkins[1]) catch (0)
                local sourceVertexCount = try (skinOps.GetNumberVertices sourceSkins[1]) catch (0)
                report = appendLine report ("源 Skin 顶点数：" + sourceVertexCount as string)
                report = appendLine report ("源 Skin 骨骼数：" + sourceBoneCount as string)
                if sourceVertexCount < 1 do append blockers "源 Skin 中没有顶点。"
                if sourceBoneCount < 1 do append blockers "源 Skin 中没有骨骼。"
            )

            if not unitsAreCentimeters() do append warnings "当前场景系统单位不是厘米；传递仍可执行，但源和目标必须处于同一场景和同一空间尺度。"

            if blockers.count == 0 do
            (
                local originalTime = currentTime
                local meshMatch = undefined
                local matchFailure = ""
                sliderTime = referenceFrame
                try (meshMatch = compareStrictBaseMeshes sourceNode targetNode) catch (matchFailure = getCurrentException())
                sliderTime = originalTime

                if matchFailure != "" then
                (
                    append blockers ("无法比较基础模型：" + matchFailure)
                )
                else
                (
                    report = appendLine report ("严格匹配顶点数：" + meshMatch[2] as string)
                    report = appendLine report ("严格匹配面数：" + meshMatch[3] as string)
                    report = appendLine report ("拓扑索引一致：" + meshMatch[4] as string)
                    report = appendLine report ("最大顶点位置误差：" + meshMatch[5] as string)
                    if not meshMatch[1] do append blockers "源模型 Skin 下方的基础网格与目标模型不是严格一致的顶点顺序、拓扑和位置。"
                )
            )
        )

        if blockers.count == 0 then report = appendLine report "状态：可以无损传递 Skin"
        else report = appendLine report "状态：已阻止 Skin 传递"

        if warnings.count > 0 do
        (
            report = appendLine report ""
            report = appendLine report "警告："
            for warningText in warnings do report = appendLine report ("- " + warningText)
        )

        if blockers.count > 0 do
        (
            report = appendLine report ""
            report = appendLine report "阻止原因："
            for blockerText in blockers do report = appendLine report ("- " + blockerText)
        )

        #(blockers.count == 0, blockers, warnings, report)
    ),

    fn transferSkin sourceNode targetNode createBackup:true =
    (
        local analysisResult = analyzeSkinTransfer sourceNode targetNode
        if not analysisResult[1] do return #(false, analysisResult[4])

        local sourceSkin = (getSkinModifiers sourceNode)[1]
        local referenceFrame = try (sourceSkin.ref_frame) catch (0)
        local originalTime = currentTime
        local sourceAlwaysDeform = try (sourceSkin.always_deform) catch (true)
        local savedWeights = undefined
        local sourcePoseSamples = undefined
        local sourceNormalSamples = undefined
        local transferredSkin = undefined
        local backupNode = undefined
        local resultReport = analysisResult[4]
        local currentStage = "准备 Skin 传递"
        local positionError = 0.0
        local normalDot = -1.0
        local normalCenterError = 1e9
        local weightValidation = undefined
        local succeeded = false

        sliderTime = referenceFrame
        savedWeights = captureSkinWeights sourceSkin node:sourceNode
        sourcePoseSamples = capturePoseSamples sourceNode referenceFrame originalTime
        sliderTime = referenceFrame
        sourceNormalSamples = captureRenderedNormalSamples sourceNode

        try
        (
            undo "Transfer Skin To Identical Mesh" on
            (
                currentStage = "创建目标模型安全备份"
                if createBackup do backupNode = createBackupCopy targetNode

                currentStage = "复制完整 Skin 修改器"
                transferredSkin = copy sourceSkin
                addModifier targetNode transferredSkin
                completeRedraw()

                local targetSkins = getSkinModifiers targetNode
                if targetSkins.count != 1 or targetNode.modifiers.count != 1 do throw "目标模型没有得到唯一的 Skin 修改器。"
                transferredSkin = targetSkins[1]

                currentStage = "复制网格和骨骼绑定矩阵"
                copySkinBindData sourceNode targetNode sourceSkin transferredSkin

                currentStage = "激活目标 Skin 并写入逐顶点权重"
                select targetNode
                max modify mode
                modPanel.setCurrentObject transferredSkin node:targetNode ui:true
                try (windows.processPostedMessages()) catch ()
                applySkinWeights transferredSkin savedWeights node:targetNode
            )

            currentStage = "激活目标 Skin 进行验证"
            select targetNode
            max modify mode
            modPanel.setCurrentObject transferredSkin node:targetNode ui:true
            try (windows.processPostedMessages()) catch ()

            currentStage = "验证骨骼列表"
            if not skinBonesMatch sourceSkin transferredSkin do throw "目标 Skin 的骨骼数量、顺序或引用节点与源 Skin 不一致。"

            currentStage = "验证网格和骨骼绑定矩阵"
            if not skinBindDataMatch sourceNode targetNode sourceSkin transferredSkin do throw "目标 Skin 的网格或骨骼绑定矩阵与源 Skin 不一致。"

            currentStage = "验证逐顶点 Skin 与 DQ 权重"
            weightValidation = validateSkinWeights transferredSkin savedWeights node:targetNode
            if not weightValidation[1] do throw weightValidation[2]

            currentStage = "验证 Skin 设置"
            if (try (transferredSkin.ref_frame) catch (-999999)) != referenceFrame do throw "目标 Skin 的参考帧与源 Skin 不一致。"
            if (try (transferredSkin.always_deform) catch (not sourceAlwaysDeform)) != sourceAlwaysDeform do throw "目标 Skin 的 Always Deform 设置与源 Skin 不一致。"

            currentStage = "验证参考和动画姿势"
            local poseValidation = validatePoseSamples targetNode sourcePoseSamples
            positionError = poseValidation[2]
            if not poseValidation[1] do throw "传递后目标模型的顶点数或面数发生变化。"
            if positionError > positionTolerance do throw ("传递后源、目标姿势不一致，最大误差：" + positionError as string)

            sliderTime = referenceFrame
            currentStage = "验证渲染法线"
            local normalValidation = validateRenderedNormalSamples targetNode sourceNormalSamples
            normalDot = normalValidation[2]
            normalCenterError = normalValidation[3]
            if not normalValidation[1] do throw "传递后目标模型的渲染法线或面位置与源模型不一致。"

            resultReport = appendLine resultReport ""
            resultReport = appendLine resultReport "Skin 传递结果：成功"
            resultReport = appendLine resultReport ("已传递骨骼数：" + (skinOps.GetNumberBones transferredSkin) as string)
            resultReport = appendLine resultReport ("已验证顶点数：" + savedWeights.count as string)
            resultReport = appendLine resultReport ("已验证姿势数：" + sourcePoseSamples.count as string)
            resultReport = appendLine resultReport ("最大姿势位置误差：" + positionError as string)
            resultReport = appendLine resultReport ("最小渲染法线点积：" + normalDot as string)
            resultReport = appendLine resultReport ("最大面中心误差：" + normalCenterError as string)
            resultReport = appendLine resultReport ("最大逐顶点骨骼权重差值：" + weightValidation[3] as string)
            resultReport = appendLine resultReport ("最大 DQ 权重差值：" + weightValidation[4] as string)
            if backupNode != undefined do resultReport = appendLine resultReport ("目标隐藏备份：" + backupNode.name)
            resultReport = appendLine resultReport "源模型：未修改"
            succeeded = true
        )
        catch
        (
            local failureMessage = getCurrentException()
            try (max undo) catch ()
            resultReport = appendLine resultReport ""
            resultReport = appendLine resultReport "Skin 传递结果：失败，已回滚目标模型"
            resultReport = appendLine resultReport ("阶段：" + currentStage)
            resultReport = appendLine resultReport ("原因：" + failureMessage)
        )

        sliderTime = originalTime
        completeRedraw()
        #(succeeded, resultReport)
    ),

    fn bakeExistingRepair node =
    (
        local analysisResult = analyze node
        if not analysisResult[1] do return #(false, analysisResult[4])
        if not hasExistingRepairStack node do return #(false, analysisResult[4] + "\r\n未检测到完整的 RSXF v1.1 修复堆栈。\r\n")

        local skinModifier = (getSkinModifiers node)[1]
        local referenceFrame = try (skinModifier.ref_frame) catch (0)
        local originalTime = currentTime
        local originalAlwaysDeform = try (skinModifier.always_deform) catch (true)
        local poseSamples = capturePoseSamples node referenceFrame originalTime
        sliderTime = referenceFrame
        local preMeshInfo = getEvaluatedMeshInfo node
        local savedWeights = captureSkinWeights skinModifier node:node
        local renderedNormalSamples = captureRenderedNormalSamples node
        local resultReport = analysisResult[4]
        local currentStage = "准备已有修复堆栈"
        local succeeded = false
        local positionError = 0.0
        local normalDot = -1.0
        local normalCenterError = 1e9

        try
        (
            undo "Bake Reset Skinned XForm" on
            (
                currentStage = "补偿平移并将轴心坐标归零"
                addPivotCompensation node
                skinModifier = (getSkinModifiers node)[1]
                skinModifier.always_deform = false
                skinModifier.always_deform = true
                if not originalAlwaysDeform do skinModifier.always_deform = false

                currentStage = "将 RSXF 修改器烘焙为可编辑多边形"
                skinModifier = bakeRepairStack node
                completeRedraw()

                currentStage = "验证烘焙后的参考姿势和动画姿势"
                local poseValidation = validatePoseSamples node poseSamples
                positionError = poseValidation[2]
                if not poseValidation[1] do throw "验证烘焙姿势时顶点数或面数发生变化。"
                if positionError > positionTolerance do throw ("烘焙后的世界空间顶点验证失败，最大误差：" + positionError as string)

                sliderTime = referenceFrame
                currentStage = "验证烘焙后的面朝向"
                local normalValidation = validateRenderedNormalSamples node renderedNormalSamples
                normalDot = normalValidation[2]
                normalCenterError = normalValidation[3]
                if not normalValidation[1] do throw "烘焙修复堆栈时渲染面朝向发生变化。"
                if getParity node.transform < 0 do throw "烘焙后节点的世界变换仍为负奇偶性。"
                if scaleNeedsNormalization node do throw "烘焙后缩放仍未归一。"
                if rotationNeedsNormalization node do throw "烘焙后旋转仍未归零。"
                if pivotNeedsNormalization node do throw "烘焙后轴心坐标仍未归零。"
                if classof node.baseObject != Editable_Poly do throw "最终基础对象不是可编辑多边形。"
            )

            currentStage = "验证烘焙后的 Skin 权重"
            skinModifier = (getSkinModifiers node)[1]
            select node
            max modify mode
            modPanel.setCurrentObject skinModifier node:node ui:true
            try (windows.processPostedMessages()) catch ()
            local weightValidation = validateSkinWeights skinModifier savedWeights node:node
            if not weightValidation[1] do throw ("烘焙时 Skin 数据发生变化：" + weightValidation[2])

            resultReport = appendLine resultReport ""
            resultReport = appendLine resultReport "烘焙结果：成功"
            resultReport = appendLine resultReport ("已验证顶点数：" + preMeshInfo[1] as string)
            resultReport = appendLine resultReport ("已验证面数：" + preMeshInfo[2] as string)
            resultReport = appendLine resultReport ("已验证姿势数：" + poseSamples.count as string)
            resultReport = appendLine resultReport ("最大采样位置误差：" + positionError as string)
            resultReport = appendLine resultReport ("最小采样渲染法线点积：" + normalDot as string)
            resultReport = appendLine resultReport ("最大采样面中心误差：" + normalCenterError as string)
            resultReport = appendLine resultReport "Skin 权重：未改变"
            resultReport = appendLine resultReport "最终堆栈：Skin + 可编辑多边形"
            resultReport = appendLine resultReport "已有隐藏备份：已保留"
            succeeded = true
        )
        catch
        (
            local failureMessage = getCurrentException()
            try (max undo) catch ()
            resultReport = appendLine resultReport ""
            resultReport = appendLine resultReport "烘焙结果：失败，已回滚更改"
            resultReport = appendLine resultReport ("阶段：" + currentStage)
            resultReport = appendLine resultReport ("原因：" + failureMessage)
        )

        sliderTime = originalTime
        try (((getSkinModifiers node)[1]).always_deform = originalAlwaysDeform) catch ()
        completeRedraw()
        #(succeeded, resultReport)
    ),

    fn repair node createBackup:true forceFlip:false =
    (
        local analysisResult = analyze node forceFlip:forceFlip
        if not analysisResult[1] do return #(false, analysisResult[4])
        if hasExistingRepairStack node do return bakeExistingRepair node

        local skins = getSkinModifiers node
        local skinModifier = skins[1]
        local referenceFrame = try (skinModifier.ref_frame) catch (0)
        local originalTime = currentTime
        local originalAlwaysDeform = try (skinModifier.always_deform) catch (true)
        local childWorldTMs = getDirectChildrenWorldTMs node
        local preMeshInfo = undefined
        local poseSamples = undefined
        local savedWeights = undefined
        local bindSummary = undefined
        local backupNode = undefined
        local resetModifier = undefined
        local flipModifier = undefined
        local renderedNormalSamples = undefined
        local resultReport = analysisResult[4]
        local succeeded = false
        local failureMessage = ""
        local currentStage = "准备处理"
        local positionError = 0.0
        local normalDot = -1.0
        local normalCenterError = 1e9
        local needsFlip = shouldFlipFaces node forceFlip:forceFlip

        sliderTime = referenceFrame
        preMeshInfo = getEvaluatedMeshInfo node
        poseSamples = capturePoseSamples node referenceFrame originalTime
        sliderTime = referenceFrame
        savedWeights = captureSkinWeights skinModifier node:node
        bindSummary = captureBindSummary node skinModifier
        renderedNormalSamples = captureRenderedNormalSamples node

        try
        (
            undo "Reset Skinned XForm" on
            (
                currentStage = "创建安全备份"
                if createBackup do backupNode = createBackupCopy node

                currentStage = "记录修改器堆栈"
                local oldModifiers = for modifierItem in node.modifiers collect modifierItem
                currentStage = "执行重置变换"
                resetXForm node
                currentStage = "定位重置变换修改器"
                for modifierItem in node.modifiers do
                (
                    if findItem oldModifiers modifierItem == 0 and resetModifier == undefined do resetModifier = modifierItem
                )
                if resetModifier == undefined do throw "重置变换没有创建 XForm 修改器。"

                currentStage = "将重置变换移动到 Skin 下方"
                local movedResetModifier = copy resetModifier
                deleteModifier node resetModifier
                skinModifier = (getSkinModifiers node)[1]
                local skinIndex = modPanel.getModifierIndex node skinModifier
                addModifier node movedResetModifier before:skinIndex
                resetModifier = movedResetModifier
                resetModifier.name = "RSXF - Reset XForm"
                skinModifier = (getSkinModifiers node)[1]
                skinIndex = modPanel.getModifierIndex node skinModifier
                local resetIndex = modPanel.getModifierIndex node resetModifier
                if resetIndex == undefined or resetIndex <= skinIndex do throw "无法将重置变换放到 Skin 下方。"

                currentStage = "补偿平移并将轴心坐标归零"
                addPivotCompensation node

                currentStage = "将 Skin 重新绑定到归一后的网格"
                skinModifier = (getSkinModifiers node)[1]
                skinModifier.always_deform = false
                skinModifier.always_deform = true
                if not originalAlwaysDeform do skinModifier.always_deform = false

                currentStage = "恢复子节点变换"
                restoreDirectChildrenWorldTMs childWorldTMs

                currentStage = "验证参考姿势和动画姿势"
                completeRedraw()
                local poseValidation = validatePoseSamples node poseSamples
                positionError = poseValidation[2]
                if not poseValidation[1] do throw "验证姿势时顶点数或面数发生变化。"
                if positionError > positionTolerance do throw ("世界空间顶点验证失败，最大误差：" + positionError as string)

                sliderTime = referenceFrame
                if needsFlip do
                (
                    currentStage = "添加翻面修改器"
                    flipModifier = normalModifier flip:true unify:false
                    flipModifier.name = "RSXF - Flip Faces"
                    addModifier node flipModifier
                    completeRedraw()
                    renderedNormalSamples = captureRenderedNormalSamples node
                )

                currentStage = "验证修复后的拓扑与节点变换"
                local postMeshInfo = getEvaluatedMeshInfo node
                if preMeshInfo[1] != postMeshInfo[1] do throw "修复后顶点数发生变化。"
                if preMeshInfo[2] != postMeshInfo[2] do throw "修复后面数发生变化。"
                if getParity node.transform < 0 do throw "重置变换后节点的世界变换仍为负奇偶性。"
                if scaleNeedsNormalization node do throw ("重置变换后缩放仍未归一：" + node.scale as string)
                if rotationNeedsNormalization node do throw ("重置变换后旋转仍未归零：" + (node.rotation as eulerAngles) as string)
                if pivotNeedsNormalization node do throw ("修复后轴心坐标仍未归零：" + node.pivot as string)

                sliderTime = referenceFrame
                currentStage = "将修复结果烘焙为可编辑多边形"
                skinModifier = bakeRepairStack node
                completeRedraw()

                currentStage = "验证烘焙后的参考姿势和动画姿势"
                local bakedPoseValidation = validatePoseSamples node poseSamples
                positionError = amax positionError bakedPoseValidation[2]
                if not bakedPoseValidation[1] do throw "烘焙后顶点数或面数发生变化。"
                if positionError > positionTolerance do throw ("烘焙后的世界空间顶点验证失败，最大误差：" + positionError as string)

                sliderTime = referenceFrame
                currentStage = "验证烘焙后的面朝向"
                local normalValidation = validateRenderedNormalSamples node renderedNormalSamples
                normalDot = normalValidation[2]
                normalCenterError = normalValidation[3]
                if not normalValidation[1] do throw "烘焙时渲染面朝向发生变化。"
            )

            -- Run SkinOps validation after the undo transaction has closed. In Max 2020,
            -- SkinOps requires Skin to be the active Modify-panel item at this point.
            currentStage = "激活 Skin 修改器以进行验证"
            skinModifier = (getSkinModifiers node)[1]
            select node
            max modify mode
            modPanel.setCurrentObject skinModifier node:node ui:true
            try (windows.processPostedMessages()) catch ()
            currentStage = "验证 Skin 权重"
            local weightValidation = validateSkinWeights skinModifier savedWeights node:node
            if not weightValidation[1] do throw ("修复过程中 Skin 数据发生变化：" + weightValidation[2])

            resultReport = appendLine resultReport ""
            resultReport = appendLine resultReport "修复结果：成功"
            resultReport = appendLine resultReport ("已验证顶点数：" + preMeshInfo[1] as string)
            resultReport = appendLine resultReport ("已验证面数：" + preMeshInfo[2] as string)
            resultReport = appendLine resultReport ("已验证姿势数：" + poseSamples.count as string)
            resultReport = appendLine resultReport ("最大采样位置误差：" + positionError as string)
            resultReport = appendLine resultReport ("最小采样渲染法线点积：" + normalDot as string)
            resultReport = appendLine resultReport ("最大采样面中心误差：" + normalCenterError as string)
            resultReport = appendLine resultReport "Skin 权重：未改变"
            resultReport = appendLine resultReport "DQ 权重：在支持的情况下未改变"
            resultReport = appendLine resultReport ("缩放已归一：" + (not scaleNeedsNormalization node) as string)
            resultReport = appendLine resultReport ("旋转已归零：" + (not rotationNeedsNormalization node) as string)
            resultReport = appendLine resultReport ("轴心坐标已归零：" + (not pivotNeedsNormalization node) as string)
            resultReport = appendLine resultReport ("已执行翻面：" + needsFlip as string)
            resultReport = appendLine resultReport ("已捕获网格绑定数据：" + (bindSummary[1] != undefined) as string)
            if backupNode != undefined do resultReport = appendLine resultReport ("隐藏备份：" + backupNode.name)
            resultReport = appendLine resultReport "最终堆栈：Skin + 可编辑多边形"
            resultReport = appendLine resultReport "临时 RSXF 修改器：已烘焙并移除"
            succeeded = true
        )
        catch
        (
            failureMessage = getCurrentException()
            try (max undo) catch ()
            resultReport = appendLine resultReport ""
            resultReport = appendLine resultReport "修复结果：失败，已回滚更改"
            resultReport = appendLine resultReport ("阶段：" + currentStage)
            resultReport = appendLine resultReport ("原因：" + failureMessage)
        )

        sliderTime = originalTime
        try (((getSkinModifiers node)[1]).always_deform = originalAlwaysDeform) catch ()
        completeRedraw()
        #(succeeded, resultReport)
    )
)

RSXF_Core = RSXF_CoreStruct()

try (destroyDialog RSXF_Rollout) catch ()

rollout RSXF_Rollout "蒙皮模型检查与修复 1.3.1" width:540 height:760
(
    local transferSource = undefined
    local transferTarget = undefined
    local reportNormalColor = undefined
    local reportProblemColor = undefined
    local reportBackgroundColor = undefined

    label lbl_title "蒙皮模型变换检查、修复与 Skin 传递" pos:[16,12] width:508 height:20
    label lbl_hint "安全归一缩放、旋转和轴心坐标；仅在负变换或手动强制时翻面。" pos:[16,35] width:508 height:34

    checkbox chk_backup "创建隐藏的安全备份" checked:true pos:[16,72] width:230
    checkbox chk_force "正变换时仍强制翻面" checked:false pos:[270,72] width:250

    label lbl_units "场景系统单位：" pos:[16,103] width:330 height:20
    button btn_fix_units "场景单位设为厘米" pos:[360,96] width:164 height:27

    button btn_analyze "分析选中蒙皮模型" pos:[16,134] width:246 height:34
    button btn_repair "安全修复 / 烘焙" pos:[278,134] width:246 height:34

    dotNetControl txt_report "System.Windows.Forms.RichTextBox" pos:[16,180] width:508 height:306

    label lbl_transfer_title "Skin 无损传递（严格顶点顺序、拓扑和位置匹配）" pos:[16,500] width:508 height:20
    button btn_set_source "记录源模型（有 Skin）" pos:[16,526] width:246 height:30
    button btn_set_target "记录目标模型（无 Skin）" pos:[278,526] width:246 height:30
    label lbl_source "源模型：未设置" pos:[16,564] width:508 height:18
    label lbl_target "目标模型：未设置" pos:[16,586] width:508 height:18
    button btn_analyze_transfer "验证严格匹配" pos:[16,614] width:246 height:32
    button btn_transfer "传递 Skin" pos:[278,614] width:246 height:32

    label lbl_usage "变换修复：选中一个带单个 Skin 的模型。Skin 传递：分别记录源与目标，验证通过后执行。" pos:[16,660] width:508 height:38
    button btn_help "使用说明 / 限制" pos:[16,714] width:246 height:28
    button btn_close "关闭" pos:[278,714] width:246 height:28

    fn selectedNode =
    (
        if selection.count == 1 then selection[1] else undefined
    )

    fn updateUnitLabel =
    (
        lbl_units.text = "场景系统单位：" + RSXF_Core.getSystemUnitName() + "；厘米规范：" + RSXF_Core.unitsAreCentimeters() as string
    )

    fn updateTransferLabels =
    (
        lbl_source.text = "源模型：" + (if transferSource != undefined and isValidNode transferSource then transferSource.name else "未设置")
        lbl_target.text = "目标模型：" + (if transferTarget != undefined and isValidNode transferTarget then transferTarget.name else "未设置")
    )

    fn reportLineHasProblem lineText =
    (
        findString lineText "；需要归一：true" != undefined or
        findString lineText "；需要归零：true" != undefined or
        findString lineText "；厘米规范：false" != undefined or
        findString lineText "处理时翻面：true" != undefined or
        findString lineText "奇偶性：-1" != undefined or
        findString lineText "奇偶性：0" != undefined or
        findString lineText "拓扑索引一致：false" != undefined or
        findString lineText "状态：已阻止" != undefined or
        findString lineText "结果：失败" != undefined or
        findString lineText "未选择有效节点" != undefined or
        findString lineText "原因：" == 1
    )

    fn setReportText reportText =
    (
        local safeText = if reportText == undefined then "" else reportText
        txt_report.Text = safeText
        txt_report.SelectAll()
        txt_report.SelectionColor = reportNormalColor

        local reportLines = txt_report.Lines
        local problemSection = false
        if reportLines != undefined do
        (
            for lineIndex = 1 to reportLines.count do
            (
                local lineText = reportLines[lineIndex]
                if lineText == "警告：" or lineText == "阻止原因：" then
                    problemSection = true
                else if lineText == "" then
                    problemSection = false

                if problemSection or reportLineHasProblem lineText do
                (
                    local lineStart = txt_report.GetFirstCharIndexFromLine (lineIndex - 1)
                    if lineStart >= 0 do
                    (
                        txt_report.Select lineStart lineText.count
                        txt_report.SelectionColor = reportProblemColor
                    )
                )
            )
        )

        txt_report.Select 0 0
        txt_report.ScrollToCaret()
    )

    on RSXF_Rollout open do
    (
        local colorClass = dotNetClass "System.Drawing.Color"
        local borderStyleClass = dotNetClass "System.Windows.Forms.BorderStyle"
        local scrollBarsClass = dotNetClass "System.Windows.Forms.RichTextBoxScrollBars"
        reportNormalColor = colorClass.Gainsboro
        reportProblemColor = colorClass.FromArgb 255 96 96
        reportBackgroundColor = colorClass.FromArgb 64 64 64
        txt_report.ReadOnly = true
        txt_report.BackColor = reportBackgroundColor
        txt_report.ForeColor = reportNormalColor
        txt_report.BorderStyle = borderStyleClass.FixedSingle
        txt_report.ScrollBars = scrollBarsClass.Both
        txt_report.WordWrap = false
        txt_report.DetectUrls = false
        updateUnitLabel()
        updateTransferLabels()
        setReportText ""
    )

    on btn_fix_units pressed do
    (
        if queryBox "把当前场景的 System Unit 和显示单位设置为厘米？\n\n此操作只修复场景单位设置，不会自动猜测或改变模型实际大小。" title:"场景单位设置" do
        (
            local fixed = RSXF_Core.setUnitsToCentimeters()
            updateUnitLabel()
            setReportText (if fixed then "场景单位设置结果：成功，当前为厘米。\r\n模型实际尺寸未改变。" else "场景单位设置结果：失败。")
        )
    )

    on btn_analyze pressed do
    (
        local result = RSXF_Core.analyze (selectedNode()) forceFlip:chk_force.checked
        setReportText result[4]
    )

    on btn_repair pressed do
    (
        local node = selectedNode()
        local preflight = RSXF_Core.analyze node forceFlip:chk_force.checked
        setReportText preflight[4]
        if not preflight[1] then
        (
            messageBox "当前对象不能安全修复，请查看分析报告中的阻止原因。" title:"蒙皮模型检查与修复"
        )
        else
        (
            local actionText = if RSXF_Core.hasExistingRepairStack node then "烘焙已有 RSXF 修复结果" else "归一变换并烘焙干净堆栈"
            local confirmation = queryBox (actionText + "：" + node.name + "？\n\n将验证参考/动画姿势和全部 Skin 权重；失败会自动回滚。") title:"蒙皮模型检查与修复"
            if confirmation do
            (
                local result = RSXF_Core.repair node createBackup:chk_backup.checked forceFlip:chk_force.checked
                setReportText result[2]
                if result[1] then
                    messageBox "处理完成。缩放、旋转和轴心已规范化；最终堆栈为 Skin + 可编辑多边形。" title:"蒙皮模型检查与修复"
                else
                    messageBox "修复失败，所有更改已回滚，请查看报告。" title:"蒙皮模型检查与修复"
            )
        )
    )

    on btn_set_source pressed do
    (
        transferSource = selectedNode()
        updateTransferLabels()
    )

    on btn_set_target pressed do
    (
        transferTarget = selectedNode()
        updateTransferLabels()
    )

    on btn_analyze_transfer pressed do
    (
        local result = RSXF_Core.analyzeSkinTransfer transferSource transferTarget
        setReportText result[4]
    )

    on btn_transfer pressed do
    (
        local preflight = RSXF_Core.analyzeSkinTransfer transferSource transferTarget
        setReportText preflight[4]
        if not preflight[1] then
        (
            messageBox "源、目标模型没有通过严格匹配检查，请查看报告。" title:"Skin 无损传递"
        )
        else if queryBox ("把 " + transferSource.name + " 的 Skin 完整传递给 " + transferTarget.name + "？\n\n源模型不会修改；失败会自动回滚目标模型。") title:"Skin 无损传递" do
        (
            local result = RSXF_Core.transferSkin transferSource transferTarget createBackup:chk_backup.checked
            setReportText result[2]
            if result[1] then
                messageBox "Skin 传递完成，骨骼、逐顶点权重、DQ 权重和动画姿势验证通过。" title:"Skin 无损传递"
            else
                messageBox "Skin 传递失败，目标模型已回滚，请查看报告。" title:"Skin 无损传递"
        )
    )

    on btn_help pressed do
    (
        messageBox "变换修复范围：\n- 只处理一个几何体，且必须只有一个 Skin\n- 安全归一缩放和旋转，并把轴心坐标归零\n- 负变换时自动翻面；正变换只有勾选后才翻面\n- 不支持动画节点变换、父级负变换、实例和显式编辑法线\n- 节点变换如果是在绑定 Skin 后才修改，会被安全阻止\n- 场景单位按钮只设置厘米，不会自动改变资产实际大小\n\nSkin 传递范围：\n- 源模型只有一个 Skin 且没有其他修改器\n- 目标模型没有任何修改器\n- 顶点顺序、三角拓扑和参考帧世界位置严格一致\n- 传递后验证骨骼、权重、DQ、绑定矩阵、法线及动画姿势\n\n所有关键失败都会执行 Undo。" title:"蒙皮模型检查与修复"
    )

    on btn_close pressed do destroyDialog RSXF_Rollout
)

macroScript ResetSkinnedXForm
category:"Rigging Tools"
toolTip:"蒙皮模型检查、修复与 Skin 传递"
buttonText:"蒙皮检查修复"
(
    on execute do
    (
        try (destroyDialog RSXF_Rollout) catch ()
        createDialog RSXF_Rollout style:#(#style_titlebar, #style_sysmenu, #style_toolwindow)
    )
)
