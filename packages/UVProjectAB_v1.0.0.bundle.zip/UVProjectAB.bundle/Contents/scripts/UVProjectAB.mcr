﻿/*
    UV Project A to B - 3ds Max 2022
    Author: 敲有钱
    Bundle version: 1.0.0
    A: UV source
    B: deformed target from Wrap (different topology is supported)
*/

global UVProjectAB_Rollout

try (destroyDialog UVProjectAB_Rollout) catch ()

rollout UVProjectAB_Rollout "UV Project A -> B v1.0.0" width:300
(
    local sourceNode = undefined
    local targetNode = undefined

    label lblInfo "A = UV source    B = deformed Wrap mesh" align:#center

    pickButton btnSource "1. Pick A (UV Source)" width:270 autoDisplay:true
    pickButton btnTarget "2. Pick deformed B (Target)" width:270 autoDisplay:true

    group "Map Channels"
    (
        spinner spnSource "A source channel:" range:[1,99,1] type:#integer fieldWidth:45
        spinner spnTarget "B target channel:" range:[1,99,1] type:#integer fieldWidth:45
    )

    button btnProject "3. Project UV" width:270 height:34
    label lblStatus "Ready" align:#center

    on btnSource picked obj do
    (
        sourceNode = obj
        btnSource.text = "A: " + obj.name
    )

    on btnTarget picked obj do
    (
        targetNode = obj
        btnTarget.text = "B: " + obj.name
    )

    on btnProject pressed do
    (
        if not isValidNode sourceNode then
        (
            messageBox "Please pick A (the UV source)." title:"UV Project A -> B"
            return false
        )

        if not isValidNode targetNode then
        (
            messageBox "Please pick the deformed B (the target)." title:"UV Project A -> B"
            return false
        )

        if sourceNode == targetNode then
        (
            messageBox "A and B must be different objects." title:"UV Project A -> B"
            return false
        )

        try
        (
            undo "Project UV A to B" on
            (
                -- Max 2022 only creates the Project Mapping plug-in while the
                -- source object is active in the Modify command panel.
                select sourceNode
                max modify mode
                completeRedraw()
                windows.processPostedMessages()

                -- Autodesk's ProjectionMod.ms helper creates a Projection
                -- modifier on A and registers B as the mapping target.
                local mods = AddPModObjects #(sourceNode) true true objList:#(targetNode)
                if mods == undefined or mods.count == 0 do throw "Could not create Projection modifier."

                local pmod = mods[1]
                pmod.mapChannel = spnSource.value

                -- Force the newly-created modifier to become the current panel
                -- object. Without this, addRegisteredProjectionType silently
                -- fails when the script is run a second time in Max 2022.
                modPanel.setCurrentObject pmod
                completeRedraw()
                windows.processPostedMessages()

                -- Make repeated runs safe. AddPModObjects can return a Projection
                -- modifier that already contains projector entries.
                while pmod.numProjectionTypes() > 0 do
                    pmod.removeProjectionType 1

                pmod.addRegisteredProjectionType 1
                windows.processPostedMessages()

                local projectorIndex = 1
                local mappingProjector = pmod.getProjectionType projectorIndex
                if mappingProjector == undefined do
                    throw "3ds Max did not create Project Mapping. Delete old Projection modifiers and try again."

                -- Do not set Project_Mapping.name: in some Max 2022 states that
                -- property is not exposed correctly after a previous projection.
                local uniqueHolderName = "UV_A_to_B_" + targetNode.name + "_" + (timestamp() as string)
                mappingProjector.holderName = uniqueHolderName
                mappingProjector.createNewHolder = true
                mappingProjector.sameTopology = false
                mappingProjector.alwaysUpdate = false
                mappingProjector.sourceMapChannel = spnSource.value
                mappingProjector.targetMapChannel = spnTarget.value

                pmod.projectProjectionType projectorIndex
            )

            lblStatus.text = "Done - inspect B's Projection Holder"
            select targetNode
            redrawViews()
            messageBox "UV projection finished.\n\nInspect B with an Unwrap UVW modifier and A's texture.\nUse Undo if the result is incorrect." title:"UV Project A -> B"
        )
        catch
        (
            lblStatus.text = "Failed"
            messageBox ("Projection failed:\n" + (getCurrentException())) title:"UV Project A -> B"
        )
    )
)

macroScript UVProjectAB
category:"JXTools"
toolTip:"UV Project A to B"
buttonText:"UV Project A to B"
(
    on execute do
    (
        try (destroyDialog UVProjectAB_Rollout) catch ()
        createDialog UVProjectAB_Rollout style:#(#style_titlebar, #style_sysmenu, #style_toolwindow)
    )
)
