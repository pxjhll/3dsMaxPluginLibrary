﻿/*
	珍珠导出插件测试
	Version 1.0.2

	3ds Max 2020+ MacroScript tool for per-object Billboard Material ID mapping,
	UV offset encoding, export preparation and FBX export.
*/

global JXTools_MultiBillboardTestVersion = "1.0.2"


function JXMBT_getSkinModifierIndex obj =
(
	local skinIndex = 0
	for i = 1 to obj.modifiers.count do
	(
		if classOf obj.modifiers[i] == Skin do
		(
			skinIndex = i
			exit
		)
	)
	skinIndex
)


function JXMBT_addTempEditPolyModifier obj skinIndex =
(
	local editPolyMod = Edit_Poly()
	if (skinIndex == 0) then
	(
		addModifier obj editPolyMod
	)
	else
	(
		addModifier obj editPolyMod before:skinIndex
	)
	editPolyMod
)


function JXMBT_cleanupTempEditPolyModifier obj editPolyMod skinIndex =
(
	if skinIndex > 0 then
	(
		maxOps.CollapseNodeTo obj (skinIndex + 1) true
	)
	else
	(
		deleteModifier obj editPolyMod
	)
)


function JXMBT_parseMaterialIDList rawText =
(
	local matIDs = #()
	local tokens = filterString rawText ",;| \t\r\n"
	for token in tokens do
	(
		local id = try (token as integer) catch (undefined)
		if (id != undefined) and (id > 0) then
		(
			if (findItem matIDs id) == 0 do append matIDs id
		)
	)
	matIDs
)


function JXMBT_integerArrayToText values separator:"," =
(
	local result = ""
	if values == undefined do return result

	for value in values do
	(
		if result != "" then result += separator
		result += (value as string)
	)
	result
)


function JXMBT_stringArrayToText values separator:"," =
(
	local result = ""
	if values == undefined do return result

	for value in values do
	(
		if result != "" then result += separator
		result += value
	)
	result
)


function JXMBT_getUniqueFaceMaterialIDs obj =
(
	local result = #()
	local faceCount = try (polyop.getNumFaces obj) catch (0)
	for faceIndex = 1 to faceCount do
	(
		local matID = try (polyop.getFaceMatID obj faceIndex) catch (undefined)
		if (matID != undefined) and ((findItem result matID) == 0) do append result matID
	)
	result
)


function JXMBT_getMaterialNamesBySuffix mat suffix:"_MBB" =
(
	local result = #()
	if mat == undefined do return result

	local matName = try (mat.name) catch ("")
	if (matName != "") and (matchPattern matName pattern:("*" + suffix) ignoreCase:true) do
	(
		append result matName
	)

	if (isProperty mat #materialList) do
	(
		local subMaterials = try (mat.materialList) catch (#())
		for subMat in subMaterials do
		(
			if subMat != undefined do
			(
				local childNames = JXMBT_getMaterialNamesBySuffix subMat suffix:suffix
				for childName in childNames do
				(
					if (findItem result childName) == 0 do append result childName
				)
			)
		)
	)

	result
)


function JXMBT_getMaterialIDsBySuffix obj suffix:"_MBB" =
(
	local resultIDs = #()
	local matchedNames = #()
	local objMat = try (obj.material) catch (undefined)
	if objMat == undefined do return #(resultIDs, matchedNames)

	-- Multi/Sub-Object 的槽位序号不一定等于面 Material ID，必须读取 materialIDList。
	local isMultiMaterial = (isProperty objMat #materialList) and (isProperty objMat #materialIDList)
	if isMultiMaterial then
	(
		local subMaterials = try (objMat.materialList) catch (#())
		local materialIDs = try (objMat.materialIDList) catch (#())

		for slotIndex = 1 to subMaterials.count do
		(
			local subMat = subMaterials[slotIndex]
			if subMat != undefined do
			(
				local slotMatchedNames = JXMBT_getMaterialNamesBySuffix subMat suffix:suffix
				if slotMatchedNames.count > 0 do
				(
					local matID = if slotIndex <= materialIDs.count then materialIDs[slotIndex] else slotIndex
					matID = try (matID as integer) catch (undefined)
					if (matID != undefined) and (matID > 0) and ((findItem resultIDs matID) == 0) do append resultIDs matID

					for matchedName in slotMatchedNames do
					(
						if (findItem matchedNames matchedName) == 0 do append matchedNames matchedName
					)
				)
			)
		)
	)
	else
	(
		local singleMatchedNames = JXMBT_getMaterialNamesBySuffix objMat suffix:suffix
		if singleMatchedNames.count > 0 do
		(
			-- 单材质作用于整个对象，保留对象实际用到的所有面 ID。
			resultIDs = JXMBT_getUniqueFaceMaterialIDs obj
			if resultIDs.count == 0 do append resultIDs 1
			matchedNames = singleMatchedNames
		)
	)

	#(resultIDs, matchedNames)
)


function JXMBT_getRuleIDsForObject obj ruleObjs ruleIDs =
(
	if (ruleObjs == undefined) or (ruleIDs == undefined) do return #()
	local ruleIndex = findItem ruleObjs obj
	if (ruleIndex <= 0) or (ruleIndex > ruleIDs.count) do return #()
	ruleIDs[ruleIndex]
)


function JXMBT_hasAnyObjectRule ruleIDs =
(
	if ruleIDs == undefined do return false
	for ids in ruleIDs do
	(
		if (ids != undefined) and (ids.count > 0) do return true
	)
	false
)


function JXMBT_getFacesToProcessByMatID obj matIDs:#() =
(
	local faceCount = try (polyop.getNumFaces obj) catch (undefined)
	if (faceCount == undefined) or (faceCount <= 0) do return #{}

	if (matIDs == undefined) or (matIDs.count == 0) do
	(
		return #{1..faceCount}
	)

	local faces = #{}
	for i = 1 to faceCount do
	(
		local faceMatID = try (polyop.getFaceMatID obj i) catch (undefined)
		if (faceMatID != undefined) and ((findItem matIDs faceMatID) > 0) do faces[i] = true
	)
	faces
)


function JXMBT_isPolyOpProcessable obj =
(
	local faceCount = try (polyop.getNumFaces obj) catch (undefined)
	(faceCount != undefined) and (faceCount > 0)
)


function JXMBT_splitSelectedFacesBoundaryVerts obj facesToProcess =
(
	local vertsSel = polyop.getVertsUsingFace obj facesToProcess
	if vertsSel.numberSet == 0 do return false

	local facesUsingSelVerts = polyop.getFacesUsingVert obj vertsSel
	local touchingUnselected = facesUsingSelVerts - facesToProcess
	if touchingUnselected.numberSet > 0 then
	(
		-- 分离共享顶点，避免处理目标面时影响未处理面
		polyop.breakVerts obj vertsSel
		return true
	)

	false
)


function JXMBT_getFaceElementsFromBitarray obj facesToProcess =
(
	local elements = #()
	local remaining = copy facesToProcess

	while remaining.numberSet > 0 do
	(
		local remainingArr = remaining as array
		local seedFace = remainingArr[1]

		local elementFaces = #{}
		local frontier = #{seedFace}

		while frontier.numberSet > 0 do
		(
			elementFaces += frontier
			local frontierVerts = polyop.getVertsUsingFace obj frontier
			local neighborFaces = (polyop.getFacesUsingVert obj frontierVerts) * facesToProcess
			frontier = neighborFaces - elementFaces
		)

		append elements elementFaces
		remaining -= elementFaces
	)

	elements
)


function JXMBT_getVertsCenterPos obj vertsBits =
(
	local centerPos = [0,0,0]
	local vCount = 0
	for v in vertsBits do
	(
		centerPos += polyop.getVert obj v
		vCount += 1
	)

	if vCount > 0 then
	(
		centerPos / vCount
	)
	else
	(
		[0,0,0]
	)
)


function JXMBT_safeNormalizeDir v fallback:[1,0,0] =
(
	local len = length v
	if len > 1e-6 then
	(
		v / len
	)
	else
	(
		fallback
	)
)


function JXMBT_encodeMultiBillboardElements obj uvset elements collapseEpsilon =
(
	for elementFaces in elements do
	(
		local verts = polyop.getVertsUsingFace obj elementFaces
		local originPositions = polyop.getVerts obj verts
		local centerPos = [0,0,0]

		for originPos in originPositions do centerPos += originPos
		if originPositions.count > 0 do centerPos /= originPositions.count

		local collapsedPositions = #()
		local positionIndex = 1
		for index in verts do
		(
			local originPos = originPositions[positionIndex]
			local offsetDir = originPos - centerPos
			offsetDir *= 0.01

			polyop.setMapVert obj uvset index [-offsetDir.x, offsetDir.z, offsetDir.y]
			local shrinkDir = JXMBT_safeNormalizeDir offsetDir
			append collapsedPositions (centerPos + shrinkDir * collapseEpsilon)
			positionIndex += 1
		)

		if collapsedPositions.count > 0 do polyop.setVert obj verts collapsedPositions
	)
	true
)


function JXMBT_shouldProcessObjBySuffix obj =
(
	matchPattern obj.name pattern:"*_MBB"
)


function JXMBT_mergeGeometryCopiesToSingle objs mergedName:"Merged_Export" =
(
	if objs.count == 0 do return undefined

	local mergedObj = objs[1]
	convertToPoly mergedObj
	mergedObj.name = mergedName

	if objs.count > 1 then
	(
		for i = 2 to objs.count do
		(
			local srcObj = objs[i]
			if isValidNode srcObj do
			(
				convertToPoly srcObj
				polyop.attach mergedObj srcObj
			)
		)
	)

	mergedObj
)


function JXMBT_execPolyMultiBillBoard Objs uvset matIDs:#() facesToProcess:undefined fastMode:false \
	isolateBoundaryVerts:false refreshViews:true =
(
	if (Objs == undefined) do return false
	local collapseEpsilon = 0.001
	local canUseSuppliedFaces = (facesToProcess != undefined) and (Objs.count == 1)

	if fastMode then
	(
		with undo off
		(
			with redraw off
			(
				for obj in Objs do
				(
					local skinIndex = JXMBT_getSkinModifierIndex obj
					local editPolyMod = JXMBT_addTempEditPolyModifier obj skinIndex
					local processFaces = if canUseSuppliedFaces then (copy facesToProcess) \
						else (JXMBT_getFacesToProcessByMatID obj matIDs:matIDs)

					if processFaces.numberSet == 0 then
					(
						JXMBT_cleanupTempEditPolyModifier obj editPolyMod skinIndex
						continue
					)

					if isolateBoundaryVerts then
					(
						JXMBT_splitSelectedFacesBoundaryVerts obj processFaces
					)

					-- 强制重建目标UV通道，避免旧UV拓扑(缝合/拆分)导致MapVert索引错乱
					if (polyop.getMapSupport obj uvset) then polyop.setMapSupport obj uvset false
					polyop.setMapSupport obj uvset true

					local elements = JXMBT_getFaceElementsFromBitarray obj processFaces
					JXMBT_encodeMultiBillboardElements obj uvset elements collapseEpsilon

					JXMBT_cleanupTempEditPolyModifier obj editPolyMod skinIndex
				)
			)
		)
	)
	else
	(
		undo on
		(
			for obj in Objs do
			(
				local skinIndex = JXMBT_getSkinModifierIndex obj
				local editPolyMod = JXMBT_addTempEditPolyModifier obj skinIndex
				local processFaces = if canUseSuppliedFaces then (copy facesToProcess) \
					else (JXMBT_getFacesToProcessByMatID obj matIDs:matIDs)

				if processFaces.numberSet == 0 then
				(
					JXMBT_cleanupTempEditPolyModifier obj editPolyMod skinIndex
					continue
				)

				if isolateBoundaryVerts then
				(
					JXMBT_splitSelectedFacesBoundaryVerts obj processFaces
				)

				-- 强制重建目标UV通道，避免旧UV拓扑(缝合/拆分)导致MapVert索引错乱
				if (polyop.getMapSupport obj uvset) then polyop.setMapSupport obj uvset false
				polyop.setMapSupport obj uvset true

				local elements = JXMBT_getFaceElementsFromBitarray obj processFaces
				JXMBT_encodeMultiBillboardElements obj uvset elements collapseEpsilon

				JXMBT_cleanupTempEditPolyModifier obj editPolyMod skinIndex
			)
		)
	)

	if refreshViews do redrawViews()
	true
)


function JXMBT_backPolyMultiBillBoard Objs uvset matIDs:#() facesToProcess:undefined fastMode:false \
	isolateBoundaryVerts:false refreshViews:true =
(
	if (Objs == undefined) do return false
	local canUseSuppliedFaces = (facesToProcess != undefined) and (Objs.count == 1)

	if fastMode then
	(
		with undo off
		(
			with redraw off
			(
				for obj in Objs do
				(
					local skinIndex = JXMBT_getSkinModifierIndex obj
					local editPolyMod = JXMBT_addTempEditPolyModifier obj skinIndex

					if ((polyop.getMapSupport obj uvset) == false) then
					(
						JXMBT_cleanupTempEditPolyModifier obj editPolyMod skinIndex
						continue
					)

					local processFaces = if canUseSuppliedFaces then (copy facesToProcess) \
						else (JXMBT_getFacesToProcessByMatID obj matIDs:matIDs)
					if processFaces.numberSet == 0 then
					(
						JXMBT_cleanupTempEditPolyModifier obj editPolyMod skinIndex
						continue
					)

					if isolateBoundaryVerts then
					(
						JXMBT_splitSelectedFacesBoundaryVerts obj processFaces
					)

					local elements = JXMBT_getFaceElementsFromBitarray obj processFaces
					for elementFaces in elements do
					(
						local verts = polyop.getVertsUsingFace obj elementFaces
						local centerPos = JXMBT_getVertsCenterPos obj verts

						for index in verts do
						(
							local offsetDir = polyop.getMapVert obj uvset index
							offsetDir = [-offsetDir.x, offsetDir.z, offsetDir.y] * 100.0
							polyop.setVert obj index (centerPos + offsetDir)
						)
					)

					-- 按Material ID回退时不直接关闭整条UV通道，避免影响同通道的其他面数据
					if (matIDs == undefined) or (matIDs.count == 0) then
					(
						polyop.setMapSupport obj uvset false
					)

					JXMBT_cleanupTempEditPolyModifier obj editPolyMod skinIndex
				)
			)
		)
	)
	else
	(
		undo on
		(
			for obj in Objs do
			(
				local skinIndex = JXMBT_getSkinModifierIndex obj
				local editPolyMod = JXMBT_addTempEditPolyModifier obj skinIndex

				if ((polyop.getMapSupport obj uvset) == false) then
				(
					JXMBT_cleanupTempEditPolyModifier obj editPolyMod skinIndex
					continue
				)

				local processFaces = if canUseSuppliedFaces then (copy facesToProcess) \
					else (JXMBT_getFacesToProcessByMatID obj matIDs:matIDs)
				if processFaces.numberSet == 0 then
				(
					JXMBT_cleanupTempEditPolyModifier obj editPolyMod skinIndex
					continue
				)

				if isolateBoundaryVerts then
				(
					JXMBT_splitSelectedFacesBoundaryVerts obj processFaces
				)

				local elements = JXMBT_getFaceElementsFromBitarray obj processFaces
				for elementFaces in elements do
				(
					local verts = polyop.getVertsUsingFace obj elementFaces
					local centerPos = JXMBT_getVertsCenterPos obj verts

					for index in verts do
					(
						local offsetDir = polyop.getMapVert obj uvset index
						offsetDir = [-offsetDir.x, offsetDir.z, offsetDir.y] * 100.0
						polyop.setVert obj index (centerPos + offsetDir)
					)
				)

				-- 按Material ID回退时不直接关闭整条UV通道，避免影响同通道的其他面数据
				if (matIDs == undefined) or (matIDs.count == 0) then
				(
					polyop.setMapSupport obj uvset false
				)

				JXMBT_cleanupTempEditPolyModifier obj editPolyMod skinIndex
			)
		)
	)

	if refreshViews do redrawViews()
	true
)


function JXMBT_processMultiBillboardByRules Objs uvset ruleObjs ruleIDs restoreMode:false =
(
	if (Objs == undefined) or (ruleObjs == undefined) or (ruleIDs == undefined) do return 0
	local processedCount = 0

	for obj in Objs do
	(
		if isValidNode obj do
		(
			local objMatIDs = JXMBT_getRuleIDsForObject obj ruleObjs ruleIDs
			if (objMatIDs != undefined) and (objMatIDs.count > 0) do
			(
				local faces = JXMBT_getFacesToProcessByMatID obj matIDs:objMatIDs
				if faces.numberSet > 0 do
				(
					if restoreMode then
					(
						JXMBT_backPolyMultiBillBoard #(obj) uvset matIDs:objMatIDs facesToProcess:faces \
							isolateBoundaryVerts:true refreshViews:false
					)
					else
					(
						JXMBT_execPolyMultiBillBoard #(obj) uvset matIDs:objMatIDs facesToProcess:faces \
							isolateBoundaryVerts:true refreshViews:false
					)
					processedCount += 1
				)
			)
		)
	)

	if processedCount > 0 do redrawViews()
	processedCount
)


function JXMBT_getMultiBillboardIniPath =
(
	(getdir #temp) + "\\JXTools_MultiBillboard_Test.ini"
)


function JXMBT_getExportBoolSetting key defaultValue:false =
(
	local rawValue = getINISetting (JXMBT_getMultiBillboardIniPath()) "Export" key
	if rawValue == "" do return defaultValue
	try (rawValue as booleanClass) catch (defaultValue)
)


function JXMBT_setExportBoolSetting key value =
(
	setINISetting (JXMBT_getMultiBillboardIniPath()) "Export" key (value as string)
)


function JXMBT_getExportPathHistory =
(
	local iniPath = JXMBT_getMultiBillboardIniPath()
	local paths = #()
	local pathCount = try ((getINISetting iniPath "ExportPaths" "Count") as integer) catch (0)

	for pathIndex = 1 to pathCount do
	(
		local savedPath = getINISetting iniPath "ExportPaths" ("Path" + (pathIndex as string))
		if savedPath != "" do append paths savedPath
	)

	if paths.count == 0 do append paths (getdir #export)
	paths
)


function JXMBT_saveExportPathHistory paths maxCount:10 =
(
	local iniPath = JXMBT_getMultiBillboardIniPath()
	local saveCount = amin paths.count maxCount
	setINISetting iniPath "ExportPaths" "Count" (saveCount as string)
	for pathIndex = 1 to saveCount do
	(
		setINISetting iniPath "ExportPaths" ("Path" + (pathIndex as string)) paths[pathIndex]
	)
	true
)


function JXMBT_insertExportPathHistory paths newPath maxCount:10 =
(
	local result = #()
	if (newPath != undefined) and (newPath != "") do append result newPath

	for oldPath in paths do
	(
		local duplicate = false
		for existingPath in result do
		(
			if (toLower existingPath) == (toLower oldPath) do duplicate = true
		)
		if not duplicate do append result oldPath
	)

	while result.count > maxCount do deleteItem result result.count
	result
)


function JXMBT_resetObjectForExport obj =
(
	if (isValidNode obj == false) do return obj
	if (JXMBT_isPolyOpProcessable obj == false) do return obj
	if (superClassOf obj != GeometryClass) do return obj
	if isGroupMember obj do return obj

	local originalPivot = obj.pivot
	local originalName = obj.name
	local originalWireColor = obj.wirecolor
	local originalChildren = for child in obj.children collect child
	local originalParent = obj.parent
	local resetObj = undefined

	try
	(
		resetObj = Box()
		resetObj = convertTo resetObj PolyMeshObject
		resetObj.EditablePoly.attach obj resetObj
		resetObj.EditablePoly.SetSelection #Face #{1..6}
		resetObj.EditablePoly.delete #Face
		resetObj.name = originalName
		resetObj.wirecolor = originalWireColor
		for child in originalChildren do child.parent = resetObj
		resetObj.parent = originalParent
		resetObj.pivot = originalPivot
		resetObj
	)
	catch
	(
		if (resetObj != undefined) and (isValidNode resetObj) do delete resetObj
		obj
	)
)


function JXMBT_alignPivotToUnityForExport obj =
(
	if (isValidNode obj == false) do return false

	local targetTM = Matrix3 [1,0,0] [0,0,1] [0,-1,0] obj.transform.pos
	local offsetScaleTM = scaleMatrix obj.objectOffsetScale
	local offsetRotTM = obj.objectOffsetRot as matrix3
	local offsetPosTM = transMatrix obj.objectOffsetPos
	local offsetTM = offsetScaleTM * offsetRotTM * offsetPosTM

	offsetTM *= obj.transform * inverse targetTM
	obj.transform = targetTM
	obj.objectOffsetPos = offsetTM.translation
	obj.objectOffsetRot = offsetTM.rotation
	obj.objectOffsetScale = offsetTM.scale
	true
)


function JXMBT_alignHierarchyToUnityForExport rootObj =
(
	if (isValidNode rootObj == false) do return false
	local hierarchy = #(rootObj)
	join hierarchy (for child in rootObj.children collect child)

	-- 递归收集全部后代。
	local scanIndex = 2
	while scanIndex <= hierarchy.count do
	(
		for child in hierarchy[scanIndex].children do append hierarchy child
		scanIndex += 1
	)

	local parents = for node in hierarchy collect node.parent
	for nodeIndex = 2 to hierarchy.count do hierarchy[nodeIndex].parent = undefined
	for node in hierarchy do JXMBT_alignPivotToUnityForExport node
	for nodeIndex = 2 to hierarchy.count do hierarchy[nodeIndex].parent = parents[nodeIndex]
	true
)


function JXMBT_applyExportPreparation exportObjs applyTransform:false moveToOrigin:false alignToUnity:false =
(
	if applyTransform do
	(
		for objIndex = 1 to exportObjs.count do
		(
			exportObjs[objIndex] = JXMBT_resetObjectForExport exportObjs[objIndex]
		)
	)

	if moveToOrigin do
	(
		for obj in exportObjs do
		(
			if (isValidNode obj) and (obj.parent == undefined) do obj.pos = [0,0,0]
		)
	)

	if alignToUnity do
	(
		for obj in exportObjs do
		(
			if (isValidNode obj) and (obj.parent == undefined) do JXMBT_alignHierarchyToUnityForExport obj
		)
	)

	exportObjs
)


function JXMBT_tryFixVerts Objs=
(
	undo on(
	for obj in Objs do
	(
		local skinIndex = JXMBT_getSkinModifierIndex obj

		local editPolyMod = JXMBT_addTempEditPolyModifier obj skinIndex
		editPolyMod.name = "Edit Poly: Try Fix Verts"

		for i = 1 to polyop.getNumFaces obj do
		(
			local centerPos = polyop.getFaceCenter obj i
			local verts = polyop.getFaceVerts obj i

			for index in verts do
			(
				local originPos = polyop.getVert obj index
				local offsetDir = originPos - centerPos
				local len = length offsetDir
				local xSign = 1
				local zSign = 1
				if (offsetDir.x < 0) then xSign = -1
				if (offsetDir.z < 0) then zSign = -1

				polyop.setVert obj index (centerPos + (normalize [xSign, 0, zSign]) * len)
			)
		)

		JXMBT_cleanupTempEditPolyModifier obj editPolyMod skinIndex
	)
	)
)


function JXMBT_tryFixNormal Objs=
(
	undo on(
	for obj in Objs do
	(
		local skinIndex = JXMBT_getSkinModifierIndex obj

		local editPolyMod = JXMBT_addTempEditPolyModifier obj skinIndex
		editPolyMod.name = "Edit Poly: Try Fix Verts"

		modPanel.setCurrentObject editPolyMod

		local ba = #()
		for i = 1 to polyop.getNumFaces obj do
		(
			local faceNormal = polyop.getFaceNormal obj i
			if(faceNormal.y >= 0) do
			(
				append ba i
			)
		)
		subObjectLevel = 4
		editPolyMod.Select #Face (ba as Bitarray)
		editPolyMod.ButtonOp #FlipFace
		editPolyMod.setSelection #Face #{}
		subObjectLevel = 0

		JXMBT_cleanupTempEditPolyModifier obj editPolyMod skinIndex
	)
	)
)


global JXTools_MultiBillboardTestLastExportPath


function JXMBT_exportMultiBillboardFBX Objs uvset processBillboard:true useMatID:false matIDs:#() ruleObjs:#() ruleIDs:#() \
	applyTransform:false moveToOrigin:false alignToUnity:false initialOutputDir:undefined =
(
	if Objs == undefined do
	(
		messageBox "没有选中物体"
		return false
	)

	local selObjs = for obj in Objs collect obj
	if selObjs.count == 0 do
	(
		messageBox "没有选中物体"
		return false
	)

	local useObjectRules = (ruleObjs != undefined) and (ruleObjs.count > 0)

	if processBillboard and useObjectRules and (JXMBT_hasAnyObjectRule ruleIDs == false) do
	(
		messageBox "映射列表中没有配置任何 Material ID"
		return false
	)

	if processBillboard and (not useObjectRules) and useMatID and ((matIDs == undefined) or (matIDs.count == 0)) do
	(
		messageBox "Material ID 列表为空或无效"
		return false
	)

	local defaultName = selObjs[1].name + ".FBX"
	local suggestedFileName = defaultName
	if (initialOutputDir != undefined) and (initialOutputDir != "") do
	(
		local lastPathCharacter = substring initialOutputDir initialOutputDir.count 1
		local pathSeparator = if lastPathCharacter == "\\" then "" else "\\"
		suggestedFileName = initialOutputDir + pathSeparator + defaultName
	)

	local filePath = getSaveFileName caption:"导出FBX" \
		types:"FBX Files (*.FBX)|*.FBX|All Files (*.*)|*.*|" \
		filename:suggestedFileName

	if filePath == undefined do return false

	if not (matchPattern filePath pattern:"*.FBX" ignoreCase:true) do
	(
		filePath = filePath + ".FBX"
	)

	local exportOk = false
	local exportError = undefined
	local shouldRestoreScene = applyTransform or moveToOrigin or alignToUnity
	local savedNames = ""
	for obj in selObjs do
	(
		if savedNames != "" then savedNames += "|"
		savedNames += obj.name
	)

	if shouldRestoreScene do holdMaxFile()

	try
	(
		with undo off
		(
			with redraw off
			(
				local tempProcessCopies = #()
				local needProcessObjs = #()
				local needProcessMatIDs = #()
				local needProcessFaces = #()
				local finalExportObjs = #()

				for obj in selObjs do
				(
					local shouldProcess = false
					local objMatIDs = #()
					local objProcessFaces = undefined

					if processBillboard and useObjectRules then
					(
						objMatIDs = JXMBT_getRuleIDsForObject obj ruleObjs ruleIDs
						if (objMatIDs != undefined) and (objMatIDs.count > 0) do
						(
							objProcessFaces = JXMBT_getFacesToProcessByMatID obj matIDs:objMatIDs
							shouldProcess = (objProcessFaces.numberSet > 0)
						)
					)
					else if processBillboard and useMatID then
					(
						objProcessFaces = JXMBT_getFacesToProcessByMatID obj matIDs:matIDs
						shouldProcess = (objProcessFaces.numberSet > 0)
						objMatIDs = matIDs
					)
					else if processBillboard then
					(
						shouldProcess = (JXMBT_shouldProcessObjBySuffix obj) and (JXMBT_isPolyOpProcessable obj)
					)

					if shouldProcess then
					(
						local copyObj = try (copy obj) catch (undefined)
						if copyObj != undefined then
						(
							copyObj.name = obj.name
							append tempProcessCopies copyObj
							append needProcessObjs copyObj
							append needProcessMatIDs objMatIDs
							append needProcessFaces objProcessFaces
							append finalExportObjs copyObj
						)
						else
						(
							append finalExportObjs obj
						)
					)
					else
					(
						append finalExportObjs obj
					)
				)

				if needProcessObjs.count > 0 do
				(
					if useObjectRules then
					(
						for processIndex = 1 to needProcessObjs.count do
						(
							JXMBT_execPolyMultiBillBoard #(needProcessObjs[processIndex]) uvset \
								matIDs:needProcessMatIDs[processIndex] \
								facesToProcess:needProcessFaces[processIndex] \
								fastMode:true isolateBoundaryVerts:true refreshViews:false
						)
					)
					else if useMatID then
					(
						JXMBT_execPolyMultiBillBoard needProcessObjs uvset matIDs:matIDs fastMode:true isolateBoundaryVerts:true
					)
					else
					(
						JXMBT_execPolyMultiBillBoard needProcessObjs uvset fastMode:true
					)
				)

				finalExportObjs = JXMBT_applyExportPreparation finalExportObjs \
					applyTransform:applyTransform moveToOrigin:moveToOrigin alignToUnity:alignToUnity
				finalExportObjs = for obj in finalExportObjs where isValidNode obj collect obj

				if finalExportObjs.count == 0 then
				(
					messageBox "没有可导出的对象"
				)
				else
				(
					select finalExportObjs
					exportFile filePath #noPrompt selectedOnly:true
					exportOk = true
				)

				for obj in tempProcessCopies do
				(
					if isValidNode obj do delete obj
				)

				if not shouldRestoreScene do select selObjs
			)
		)
	)
	catch
	(
		exportError = getCurrentException()
	)

	if shouldRestoreScene do fetchMaxFile quiet:true

	redrawViews()
	if exportError != undefined do
	(
		messageBox ("导出失败：\n" + (exportError as string))
		return false
	)

	if not exportOk do return false

	local iniPath = JXMBT_getMultiBillboardIniPath()
	setINISetting iniPath "Selection" "Objects" savedNames
	JXTools_MultiBillboardTestLastExportPath = filePath

	return true
)


function JXMBT_toggleSaveLoadSelection =
(
	local iniPath = (getdir #temp) + "\\JXTools_MultiBillboard_Test.ini"
	local sel = $

	local hasSelection = false
	if sel != undefined do
	(
		if classOf sel == Array then
		(
			hasSelection = sel.count > 0
		)
		else
		(
			hasSelection = true
		)
	)

	if not hasSelection then
	(
		local savedNames = getINISetting iniPath "Selection" "Objects"

		if savedNames == "" do
		(
			messageBox "没有记录的选择"
			return false
		)

		local names = filterString savedNames "|"
		local restoredSel = #()

		for name in names do
		(
			local obj = getNodeByName name
			if obj != undefined do append restoredSel obj
		)

		if restoredSel.count > 0 then
		(
			select restoredSel
		)
		else
		(
			messageBox "没有找到已记录的物体"
		)
	)
	else
	(
		local selArray = for obj in sel collect obj
		local savedNames = ""
		for obj in selArray do
		(
			if savedNames != "" then savedNames += "|"
			savedNames += obj.name
		)

		setINISetting iniPath "Selection" "Objects" savedNames
	)

	return true
)


if (rol_MultiBillboardSetter_Test != undefined) then (DestroyDialog rol_MultiBillboardSetter_Test)

rollout rol_MultiBillboardSetter_Test "珍珠导出插件测试 v1.0.2" width:440 height:900
(
	checkbutton 'btn_toggleExport' "▼ 导出功能" pos:[20,10] width:397 height:28 checked:(JXMBT_getExportBoolSetting "ExportPanelExpanded" defaultValue:true) align:#left
	GroupBox 'grp_export' "" pos:[20,44] width:397 height:200 align:#left
	checkbox 'chk_applyTransform' "应用变换" pos:[42,43] width:160 height:18 checked:(JXMBT_getExportBoolSetting "ApplyTransform" defaultValue:false) align:#left
	checkbox 'chk_moveToOrigin' "移动物体到原点" pos:[42,69] width:180 height:18 checked:(JXMBT_getExportBoolSetting "MoveToOrigin" defaultValue:false) align:#left
	checkbox 'chk_alignToUnity' "与Unity统一轴向" pos:[42,95] width:180 height:18 checked:(JXMBT_getExportBoolSetting "AlignToUnity" defaultValue:false) align:#left
	label 'lbl_outputPath' "导出路径" pos:[42,123] width:70 height:18 align:#left
	dropdownlist 'ddl_outputPaths' "" pos:[115,118] width:241 height:20 items:#() align:#left
	button 'btn_browseOutput' "..." pos:[364,117] width:32 height:24 tooltip:"选择并记录导出文件夹" align:#left
	button 'btn_export' "导出FBX" pos:[42,158] width:164 height:43 align:#left
	button 'btn_memSel' "记录/恢复选择" pos:[222,158] width:164 height:43 align:#left

	checkbutton 'btn_toggleBillboard' "▼ Billboard功能" pos:[20,252] width:397 height:28 checked:(JXMBT_getExportBoolSetting "BillboardPanelExpanded" defaultValue:true) align:#left
	GroupBox 'grp_billboard' "" pos:[20,286] width:397 height:500 align:#left
	button 'btn_fixVert' "尝试规范顶点(根据UV)" pos:[42,260] width:164 height:40 align:#left
	button 'btn_fixNorm' "修复法线为：(0,-1,0)" pos:[222,260] width:164 height:40 align:#left
	label 'lbl_uvSet' "信息所在UV集" pos:[42,317] width:78 height:18 align:#left
	dropdownlist 'ddl_uvSet' "" pos:[125,312] width:127 height:20 items:#("UV2", "UV3", "UV4") selection:3 align:#left
	label 'lbl_suffix' "材质名后缀" pos:[42,343] width:70 height:18 align:#left
	edittext 'edt_suffix' "" pos:[115,339] width:171 height:20 text:"_MBB" align:#left
	button 'btn_scan' "扫描当前选择" pos:[300,338] width:96 height:30 align:#left
	listbox 'lst_rules' "扫描结果（对象 → ID → 命中面数）" pos:[42,378] width:354 height:8 items:#() align:#left
	label 'lbl_selected' "当前项：未选择" pos:[45,542] width:345 height:18 align:#left
	label 'lbl_ruleIDs' "人工修改ID(逗号分隔)" pos:[42,567] width:126 height:18 align:#left
	edittext 'edt_ruleIDs' "" pos:[170,563] width:110 height:20 text:"" align:#left
	button 'btn_applyRule' "应用" pos:[290,563] width:50 height:28 align:#left
	button 'btn_clearRule' "清空" pos:[346,563] width:50 height:28 align:#left
	button 'btn_back' "按映射复原多边形" pos:[42,612] width:354 height:43 align:#left
	button 'btn_exec' "按映射运行" pos:[42,666] width:354 height:44 align:#left

	label 'lbl1' "Billboard用法：选择需要一起导出的对象后扫描。列表只显示可处理的Mesh；骨骼、Biped和辅助体不显示，但仍会随FBX原样导出。脚本自动查找_MBB材质并建立对象→ID映射，可逐行人工修改。导出区的变换、原点和Unity轴向只在导出临时状态中执行，完成后恢复当前场景。建议操作前备份。" pos:[31,800] width:382 height:88 align:#left

	local scannedExportObjs = #()
	local scannedObjs = #()
	local scannedRuleIDs = #()
	local scannedMaterialNames = #()
	local outputPathHistory = #()

	fn setExportPanelVisible state =
	(
		for control in #(grp_export, chk_applyTransform, chk_moveToOrigin, chk_alignToUnity, \
			lbl_outputPath, ddl_outputPaths, btn_browseOutput, btn_export, btn_memSel) do
		(
			control.visible = state
		)
	)

	fn setBillboardPanelVisible state =
	(
		for control in #(grp_billboard, btn_fixVert, btn_fixNorm, lbl_uvSet, ddl_uvSet, lbl_suffix, edt_suffix, btn_scan, \
			lst_rules, lbl_selected, lbl_ruleIDs, edt_ruleIDs, btn_applyRule, btn_clearRule, btn_back, btn_exec, lbl1) do
		(
			control.visible = state
		)
	)

	fn updateCollapsibleLayout =
	(
		local currentY = 10
		local panelTop = 0

		btn_toggleExport.pos = [20,currentY]
		btn_toggleExport.text = if btn_toggleExport.checked then "▼ 导出功能" else "▶ 导出功能"
		currentY += 34

		setExportPanelVisible btn_toggleExport.checked
		if btn_toggleExport.checked do
		(
			panelTop = currentY
			grp_export.pos = [20,panelTop]
			chk_applyTransform.pos = [42,panelTop + 28]
			chk_moveToOrigin.pos = [42,panelTop + 54]
			chk_alignToUnity.pos = [42,panelTop + 80]
			lbl_outputPath.pos = [42,panelTop + 108]
			ddl_outputPaths.pos = [115,panelTop + 103]
			btn_browseOutput.pos = [364,panelTop + 102]
			btn_export.pos = [42,panelTop + 143]
			btn_memSel.pos = [222,panelTop + 143]
			currentY += 208
		)

		btn_toggleBillboard.pos = [20,currentY]
		btn_toggleBillboard.text = if btn_toggleBillboard.checked then "▼ Billboard功能" else "▶ Billboard功能"
		currentY += 34

		setBillboardPanelVisible btn_toggleBillboard.checked
		if btn_toggleBillboard.checked do
		(
			panelTop = currentY
			grp_billboard.pos = [20,panelTop]
			btn_fixVert.pos = [42,panelTop + 30]
			btn_fixNorm.pos = [222,panelTop + 30]
			lbl_uvSet.pos = [42,panelTop + 87]
			ddl_uvSet.pos = [125,panelTop + 82]
			lbl_suffix.pos = [42,panelTop + 113]
			edt_suffix.pos = [115,panelTop + 109]
			btn_scan.pos = [300,panelTop + 108]
			lst_rules.pos = [42,panelTop + 148]
			lbl_selected.pos = [45,panelTop + 312]
			lbl_ruleIDs.pos = [42,panelTop + 337]
			edt_ruleIDs.pos = [170,panelTop + 333]
			btn_applyRule.pos = [290,panelTop + 333]
			btn_clearRule.pos = [346,panelTop + 333]
			btn_back.pos = [42,panelTop + 382]
			btn_exec.pos = [42,panelTop + 436]
			lbl1.pos = [31,panelTop + 515]
			currentY += 610
		)

		setDialogSize rol_MultiBillboardSetter_Test [440,currentY + 10]
	)

	fn refreshOutputPathHistory preferredPath:undefined =
	(
		if outputPathHistory.count == 0 do outputPathHistory = JXMBT_getExportPathHistory()
		if (preferredPath != undefined) and (preferredPath != "") do
		(
			outputPathHistory = JXMBT_insertExportPathHistory outputPathHistory preferredPath
		)

		ddl_outputPaths.items = outputPathHistory
		if outputPathHistory.count > 0 do
		(
			ddl_outputPaths.selection = 1
			ddl_outputPaths.tooltip = outputPathHistory[1]
		)
		JXMBT_saveExportPathHistory outputPathHistory
	)

	fn getCurrentOutputPath =
	(
		local selectedIndex = ddl_outputPaths.selection
		if (selectedIndex > 0) and (selectedIndex <= ddl_outputPaths.items.count) then
		(
			ddl_outputPaths.items[selectedIndex]
		)
		else
		(
			getdir #export
		)
	)

	fn getObjectNames objects =
	(
		for obj in objects collect (try (obj.name) catch (""))
	)

	fn rebindObjectsByName objectNames =
	(
		local result = #()
		for objectName in objectNames do
		(
			local obj = undefined
			if objectName != "" do
			(
				obj = getNodeByName objectName exact:true ignoreCase:false all:false
			)
			append result obj
		)
		result
	)

	fn getScannedValidObjects =
	(
		local result = #()
		for obj in scannedExportObjs do
		(
			if isValidNode obj do append result obj
		)
		result
	)

	fn hasScannedMBBMaterial =
	(
		for matchedNames in scannedMaterialNames do
		(
			if (matchedNames != undefined) and (matchedNames.count > 0) do return true
		)
		false
	)

	fn refreshRuleList preferredSelection:0 =
	(
		local rows = #()
		for ruleIndex = 1 to scannedObjs.count do
		(
			local obj = scannedObjs[ruleIndex]
			local ids = scannedRuleIDs[ruleIndex]
			local matchedNames = scannedMaterialNames[ruleIndex]
			local objName = if isValidNode obj then obj.name else "<对象已删除>"
			local idText = if ids.count > 0 then JXMBT_integerArrayToText ids else "未配置"
			local matText = if matchedNames.count > 0 then JXMBT_stringArrayToText matchedNames else "未匹配_MBB材质"
			local faceCount = 0

			if (isValidNode obj) and (ids.count > 0) do
			(
				local faces = JXMBT_getFacesToProcessByMatID obj matIDs:ids
				faceCount = faces.numberSet
			)

			local stateText = if (ids.count > 0) and (faceCount > 0) then "[处理] " else "[原样] "
			append rows (stateText + objName + " | ID:" + idText + " | 面:" + (faceCount as string) + " | " + matText)
		)

		lst_rules.items = rows
		if rows.count > 0 then
		(
			local selectIndex = preferredSelection
			if (selectIndex <= 0) or (selectIndex > rows.count) do selectIndex = 1
			lst_rules.selection = selectIndex
			lbl_selected.text = "当前项：" + (try (scannedObjs[selectIndex].name) catch ("<对象已删除>"))
			edt_ruleIDs.text = JXMBT_integerArrayToText scannedRuleIDs[selectIndex]
		)
		else
		(
			lbl_selected.text = "当前项：未选择"
			edt_ruleIDs.text = ""
		)
	)

	fn scanCurrentSelection =
	(
		local selObjs = for obj in selection collect obj
		if selObjs.count == 0 do
		(
			messageBox "没有选中物体"
			return false
		)

		local suffixText = edt_suffix.text
		if suffixText == "" do
		(
			messageBox "材质名后缀不能为空"
			return false
		)

		-- 保留完整选择用于最终导出，但扫描列表只展示脚本可处理的Mesh。
		scannedExportObjs = selObjs
		scannedObjs = #()
		scannedRuleIDs = #()
		scannedMaterialNames = #()

		for obj in selObjs do
		(
			if JXMBT_isPolyOpProcessable obj do
			(
				local scanResult = JXMBT_getMaterialIDsBySuffix obj suffix:suffixText
				append scannedObjs obj
				append scannedRuleIDs scanResult[1]
				append scannedMaterialNames scanResult[2]
			)
		)

		refreshRuleList()
		if scannedObjs.count == 0 do
		(
			messageBox "当前选择中没有可处理的Mesh对象"
			return false
		)
		true
	)

	fn getSelectedUVSet =
	(
		-- 下拉项依次为UV2、UV3、UV4。
		ddl_uvSet.selection + 1
	)

	fn validateRulesForAction =
	(
		if scannedObjs.count == 0 do
		(
			messageBox "请先选择对象并点击“扫描当前选择”"
			return false
		)

		if (JXMBT_hasAnyObjectRule scannedRuleIDs) == false do
		(
			messageBox "映射列表中没有配置任何 Material ID"
			return false
		)

		-- 该Unity Shader从TEXCOORD3读取offset，对应Max里UV4。
		if (getSelectedUVSet()) != 4 do
		(
			messageBox "当前Unity Shader使用TEXCOORD3作为offset，请将“信息所在UV集”设为4。"
			return false
		)

		true
	)

	on rol_MultiBillboardSetter_Test open do
	(
		outputPathHistory = JXMBT_getExportPathHistory()
		refreshOutputPathHistory()
		updateCollapsibleLayout()
	)

	on btn_toggleExport changed state do
	(
		JXMBT_setExportBoolSetting "ExportPanelExpanded" state
		updateCollapsibleLayout()
	)

	on btn_toggleBillboard changed state do
	(
		JXMBT_setExportBoolSetting "BillboardPanelExpanded" state
		updateCollapsibleLayout()
	)

	on chk_applyTransform changed state do
	(
		JXMBT_setExportBoolSetting "ApplyTransform" state
	)

	on chk_moveToOrigin changed state do
	(
		JXMBT_setExportBoolSetting "MoveToOrigin" state
	)

	on chk_alignToUnity changed state do
	(
		JXMBT_setExportBoolSetting "AlignToUnity" state
	)

	on btn_browseOutput pressed do
	(
		local selectedPath = getSavePath "选择导出文件夹" initialDir:(getCurrentOutputPath())
		if selectedPath != undefined do refreshOutputPathHistory preferredPath:selectedPath
	)

	on ddl_outputPaths selected pathIndex do
	(
		if (pathIndex > 0) and (pathIndex <= ddl_outputPaths.items.count) do
		(
			local selectedPath = ddl_outputPaths.items[pathIndex]
			refreshOutputPathHistory preferredPath:selectedPath
		)
	)

	on btn_scan pressed do
	(
		scanCurrentSelection()
	)

	on lst_rules selected ruleIndex do
	(
		if (ruleIndex > 0) and (ruleIndex <= scannedObjs.count) do
		(
			lbl_selected.text = "当前项：" + (try (scannedObjs[ruleIndex].name) catch ("<对象已删除>"))
			edt_ruleIDs.text = JXMBT_integerArrayToText scannedRuleIDs[ruleIndex]
		)
	)

	on btn_applyRule pressed do
	(
		local ruleIndex = lst_rules.selection
		if (ruleIndex <= 0) or (ruleIndex > scannedObjs.count) then
		(
			messageBox "请先在扫描结果中选择一个对象"
		)
		else
		(
			local ids = JXMBT_parseMaterialIDList edt_ruleIDs.text
			if ids.count == 0 then
			(
				messageBox "ID无效；如需不处理该对象，请点击“清空”"
			)
			else
			(
				scannedRuleIDs[ruleIndex] = ids
				refreshRuleList preferredSelection:ruleIndex
			)
		)
	)

	on btn_clearRule pressed do
	(
		local ruleIndex = lst_rules.selection
		if (ruleIndex > 0) and (ruleIndex <= scannedObjs.count) do
		(
			scannedRuleIDs[ruleIndex] = #()
			refreshRuleList preferredSelection:ruleIndex
		)
	)

	on btn_exec pressed do
	(
		if (validateRulesForAction() == false) do return false
		if yesNoCancelBox "确定按当前对象→ID映射运行吗？" == #yes then
		(
			local processCount = JXMBT_processMultiBillboardByRules scannedObjs (getSelectedUVSet()) scannedObjs scannedRuleIDs
			if processCount == 0 do messageBox "映射中的ID没有命中任何可处理面"
			refreshRuleList preferredSelection:lst_rules.selection
		)
	)

	on btn_back pressed do
	(
		if (validateRulesForAction() == false) do return false
		if yesNoCancelBox "确定按当前对象→ID映射复原吗？" == #yes then
		(
			local processCount = JXMBT_processMultiBillboardByRules scannedObjs (getSelectedUVSet()) scannedObjs scannedRuleIDs restoreMode:true
			if processCount == 0 do messageBox "映射中的ID没有命中任何可复原面"
			refreshRuleList preferredSelection:lst_rules.selection
		)
	)

	on btn_fixVert pressed do
	(
		local sel = $
		if sel == undefined then
		(
			messageBox "没有选中物体"
		)
		else
		(
			if yesNoCancelBox "确定运行吗？" == #yes then JXMBT_tryFixVerts sel
		)
	)

	on btn_fixNorm pressed do
	(
		local sel = $
		if sel == undefined then
		(
			messageBox "没有选中物体"
		)
		else
		(
			if yesNoCancelBox "确定运行吗？" == #yes then JXMBT_tryFixNormal sel
		)
	)

	on btn_export pressed do
	(
		local hasScanResult = scannedExportObjs.count > 0
		local useSpecialExport = hasScanResult and hasScannedMBBMaterial()
		if useSpecialExport and (validateRulesForAction() == false) do return false

		local exportObjs = if hasScanResult then getScannedValidObjects() else (for obj in selection collect obj)
		if exportObjs.count == 0 then
		(
			if hasScanResult then
				messageBox "扫描记录中的对象都已失效，请重新扫描"
			else
				messageBox "没有选中物体"
		)
		else
		(
			local exportObjectNames = getObjectNames scannedExportObjs
			local ruleObjectNames = getObjectNames scannedObjs
			local exportRuleObjs = if useSpecialExport then scannedObjs else #()
			local exportRuleIDs = if useSpecialExport then scannedRuleIDs else #()
			local restoresSceneAfterExport = chk_applyTransform.checked or chk_moveToOrigin.checked or chk_alignToUnity.checked
			local exportOk = JXMBT_exportMultiBillboardFBX exportObjs (getSelectedUVSet()) \
				processBillboard:useSpecialExport ruleObjs:exportRuleObjs ruleIDs:exportRuleIDs \
				applyTransform:chk_applyTransform.checked \
				moveToOrigin:chk_moveToOrigin.checked \
				alignToUnity:chk_alignToUnity.checked \
				initialOutputDir:(getCurrentOutputPath())

			-- Hold/Fetch会重建场景节点；按名称重新绑定，保留人工修改过的ID映射。
			if restoresSceneAfterExport do
			(
				scannedExportObjs = rebindObjectsByName exportObjectNames
				scannedObjs = rebindObjectsByName ruleObjectNames
				refreshRuleList preferredSelection:lst_rules.selection
			)

			if exportOk and (JXTools_MultiBillboardTestLastExportPath != undefined) do
			(
				local exportedDirectory = getFilenamePath JXTools_MultiBillboardTestLastExportPath
				if exportedDirectory != "" do refreshOutputPathHistory preferredPath:exportedDirectory
			)
		)
	)

	on btn_memSel pressed do
	(
		JXMBT_toggleSaveLoadSelection()
	)
)


global JXTools_ShowMultiBillboardSetter_Test

function JXTools_ShowMultiBillboardSetter_Test =
(
	try (DestroyDialog rol_MultiBillboardSetter_Test) catch ()
	CreateDialog rol_MultiBillboardSetter_Test
)


macroScript JXTools_MultiBillboardSetter_Test
category:"JXTools"
toolTip:"珍珠导出插件测试 v1.0.2"
buttonText:"珍珠导出插件测试"
(
	on execute do JXTools_ShowMultiBillboardSetter_Test()
)
