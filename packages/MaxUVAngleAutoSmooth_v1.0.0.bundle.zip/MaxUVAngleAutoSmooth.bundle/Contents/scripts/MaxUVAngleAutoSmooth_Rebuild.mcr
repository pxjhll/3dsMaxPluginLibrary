-- Max UV Angle Auto Smooth
-- Assigns smoothing groups from UV seam borders and face angle.

macroScript MaxUVAngleAutoSmooth_Rebuild
category:"UV Tools"
toolTip:"UV Angle Auto Smooth Rebuild"
buttonText:"UV Angle SG Rebuild"
(
    global MaxUVAngleAutoSmooth_Rebuild_Rollout

    fn UVAAS_isEditablePoly node =
    (
        isValidNode node and (classof node == Editable_Poly or classof node.baseObject == Editable_Poly)
    )

    fn UVAAS_isGeometryNode node =
    (
        isValidNode node and superclassof node == GeometryClass
    )

    fn UVAAS_clamp value low high =
    (
        if value < low then low else if value > high then high else value
    )

    fn UVAAS_edgeKey a b =
    (
        ((amin a b) as string) + "|" + ((amax a b) as string)
    )

    fn UVAAS_toIndexArray value =
    (
        if classof value == Point3 then
        (
            #(value.x as integer, value.y as integer, value.z as integer)
        )
        else
        (
            local result = #()
            for item in value do append result (item as integer)
            result
        )
    )

    fn UVAAS_faceNormal node faceIndex =
    (
        local n = try (polyop.getFaceNormal node faceIndex) catch ([0,0,1])
        if (length n) < 0.000001 then [0,0,1] else normalize n
    )

    fn UVAAS_angleBetween n1 n2 =
    (
        acos (UVAAS_clamp (dot n1 n2) -1.0 1.0)
    )

    fn UVAAS_foldAngleBetweenNormals n1 n2 =
    (
        180.0 - (UVAAS_angleBetween n1 n2)
    )

    fn UVAAS_sgMask groupIndex =
    (
        bit.set 0 groupIndex true
    )

    fn UVAAS_sgContains sgValue groupIndex =
    (
        try (bit.get sgValue groupIndex) catch false
    )

    fn UVAAS_appendUnique arr value =
    (
        if (findItem arr value) == 0 do append arr value
    )

    fn UVAAS_mapForGeoVert edgeRecord geoVert =
    (
        if edgeRecord[2] == geoVert then edgeRecord[4]
        else if edgeRecord[3] == geoVert then edgeRecord[5]
        else 0
    )

    fn UVAAS_buildAnalysis node uvChannel angleThreshold useUvSeams useAngleRule =
    (
        if not (UVAAS_isEditablePoly node) then return #(#fail, "Object is not Editable Poly.")

        local faceCount = polyop.getNumFaces node
        if faceCount < 1 then return #(#fail, "Object has no faces.")

        if useUvSeams do
        (
            if not (polyop.getMapSupport node uvChannel) then
            (
                return #(#fail, ("No UV map support on channel " + (uvChannel as string) + "."))
            )
            if (polyop.getNumMapVerts node uvChannel) < 1 then
            (
                return #(#fail, ("No UV vertices on channel " + (uvChannel as string) + "."))
            )
            if (polyop.getNumMapFaces node uvChannel) < faceCount then
            (
                return #(#fail, ("UV face data is incomplete on channel " + (uvChannel as string) + "."))
            )
        )

        local faceNormals = #()
        faceNormals.count = faceCount
        local smoothLinks = #()
        smoothLinks.count = faceCount
        for f = 1 to faceCount do
        (
            faceNormals[f] = UVAAS_faceNormal node f
            smoothLinks[f] = #()
        )

        local edgeTable = dotNetObject "System.Collections.Hashtable"
        local hardPairs = #()
        local hardEdges = #{}
        local hardEdgeCount = 0
        local smoothEdgeCount = 0

        for faceIndex = 1 to faceCount do
        (
            local geoVerts = UVAAS_toIndexArray (polyop.getFaceVerts node faceIndex)
            local mapVerts = #()
            if useUvSeams do mapVerts = UVAAS_toIndexArray (polyop.getMapFace node uvChannel faceIndex)

            local faceEdges = try (UVAAS_toIndexArray (polyop.getFaceEdges node faceIndex)) catch (#())
            local vertCount = geoVerts.count

            if vertCount >= 3 do
            (
                for i = 1 to vertCount do
                (
                    local nextIndex = if i == vertCount then 1 else i + 1
                    local gvA = geoVerts[i]
                    local gvB = geoVerts[nextIndex]
                    local mvA = if useUvSeams and mapVerts.count == vertCount then mapVerts[i] else 0
                    local mvB = if useUvSeams and mapVerts.count == vertCount then mapVerts[nextIndex] else 0
                    local edgeIndex = if faceEdges.count == vertCount then faceEdges[i] else 0
                    local key = UVAAS_edgeKey gvA gvB
                    local record = #(faceIndex, gvA, gvB, mvA, mvB, edgeIndex)

                    if edgeTable.ContainsKey key then
                    (
                        local existingRecords = edgeTable.Item[key]
                        for otherRecord in existingRecords do
                        (
                            local otherFace = otherRecord[1]
                            if otherFace != faceIndex do
                            (
                                local uvContinues = true
                                if useUvSeams do
                                (
                                    local otherMapA = UVAAS_mapForGeoVert otherRecord gvA
                                    local otherMapB = UVAAS_mapForGeoVert otherRecord gvB
                                    uvContinues = (otherMapA == mvA and otherMapB == mvB and mvA > 0 and mvB > 0)
                                )

                                local foldAngleBelowThreshold = true
                                if useAngleRule do
                                (
                                    foldAngleBelowThreshold = ((UVAAS_foldAngleBetweenNormals faceNormals[otherFace] faceNormals[faceIndex]) < angleThreshold)
                                )

                                local uvIsCut = (useUvSeams and not uvContinues)
                                local shouldSplit = false

                                if useUvSeams and useAngleRule then
                                (
                                    shouldSplit = (uvIsCut and foldAngleBelowThreshold)
                                )
                                else if useUvSeams then
                                (
                                    shouldSplit = uvIsCut
                                )
                                else if useAngleRule then
                                (
                                    shouldSplit = foldAngleBelowThreshold
                                )

                                -- The requested split rule is strict: UV seam and angle below the threshold.
                                if shouldSplit then
                                (
                                    append hardPairs #(otherFace, faceIndex)
                                    if edgeIndex > 0 then hardEdges[edgeIndex] = true
                                    if otherRecord[6] > 0 then hardEdges[otherRecord[6]] = true
                                    hardEdgeCount += 1
                                )
                                else
                                (
                                    UVAAS_appendUnique smoothLinks[otherFace] faceIndex
                                    UVAAS_appendUnique smoothLinks[faceIndex] otherFace
                                    smoothEdgeCount += 1
                                )
                            )
                        )
                        append existingRecords record
                    )
                    else
                    (
                        edgeTable.Add key #(record)
                    )
                )
            )
        )

        #(#ok, smoothLinks, hardPairs, hardEdges, smoothEdgeCount, hardEdgeCount, faceCount)
    )

    fn UVAAS_buildComponents faceCount smoothLinks =
    (
        local faceToComp = #()
        faceToComp.count = faceCount
        local compFaces = #()
        local visited = #{}

        for startFace = 1 to faceCount where not visited[startFace] do
        (
            local compIndex = compFaces.count + 1
            local faces = #{}
            local queue = #(startFace)
            local head = 1
            visited[startFace] = true

            while head <= queue.count do
            (
                local f = queue[head]
                head += 1
                faces[f] = true
                faceToComp[f] = compIndex

                for nextFace in smoothLinks[f] where not visited[nextFace] do
                (
                    visited[nextFace] = true
                    append queue nextFace
                )
            )

            append compFaces faces
        )

        #(faceToComp, compFaces)
    )

    fn UVAAS_colorComponents compFaces faceToComp hardPairs =
    (
        local compCount = compFaces.count
        local compNeighbors = #()
        local compGroup = #()
        local compOrder = #()
        compGroup.count = compCount
        compNeighbors.count = compCount
        compOrder.count = compCount
        local overflow = 0

        for compIndex = 1 to compCount do
        (
            compNeighbors[compIndex] = #{}
            compOrder[compIndex] = compIndex
        )

        if compCount <= 32 do
        (
            for compIndex = 1 to compCount do compGroup[compIndex] = compIndex
            return #(compGroup, 0)
        )

        for hardPair in hardPairs do
        (
            local compA = faceToComp[hardPair[1]]
            local compB = faceToComp[hardPair[2]]

            if compA != undefined and compB != undefined and compA != compB do
            (
                compNeighbors[compA][compB] = true
                compNeighbors[compB][compA] = true
            )
        )

        for i = 1 to compCount - 1 do
        (
            local bestIndex = i
            local bestDegree = compNeighbors[compOrder[i]].numberset

            for j = i + 1 to compCount do
            (
                local testDegree = compNeighbors[compOrder[j]].numberset
                if testDegree > bestDegree do
                (
                    bestDegree = testDegree
                    bestIndex = j
                )
            )

            if bestIndex != i do
            (
                local temp = compOrder[i]
                compOrder[i] = compOrder[bestIndex]
                compOrder[bestIndex] = temp
            )
        )

        for compIndex = 1 to compCount do
        (
            local currentComp = compOrder[compIndex]
            local blockedGroups = #{}
            local pickedGroup = 0

            for neighborComp in compNeighbors[currentComp] do
            (
                local neighborGroup = compGroup[neighborComp]
                if neighborGroup != undefined and neighborGroup > 0 do blockedGroups[neighborGroup] = true
            )

            for groupIndex = 1 to 32 while pickedGroup == 0 do
            (
                if not blockedGroups[groupIndex] do pickedGroup = groupIndex
            )

            if pickedGroup == 0 do
            (
                overflow += 1
                pickedGroup = (mod (currentComp - 1) 32) + 1
            )

            compGroup[currentComp] = pickedGroup
        )

        #(compGroup, overflow)
    )

    fn UVAAS_colorIslandGraph islandCount islandHardPairs =
    (
        local hardNeighbors = #()
        local islandGroups = #()
        local islandOrder = #()
        hardNeighbors.count = islandCount
        islandGroups.count = islandCount
        islandOrder.count = islandCount

        for islandIndex = 1 to islandCount do
        (
            hardNeighbors[islandIndex] = #{}
            islandGroups[islandIndex] = 0
            islandOrder[islandIndex] = islandIndex
        )

        for hardPair in islandHardPairs do
        (
            local islandA = hardPair[1]
            local islandB = hardPair[2]

            if islandA >= 1 and islandA <= islandCount and islandB >= 1 and islandB <= islandCount and islandA != islandB do
            (
                hardNeighbors[islandA][islandB] = true
                hardNeighbors[islandB][islandA] = true
            )
        )

        for i = 1 to islandCount - 1 do
        (
            local bestIndex = i
            local bestDegree = hardNeighbors[islandOrder[i]].numberset

            for j = i + 1 to islandCount do
            (
                local testDegree = hardNeighbors[islandOrder[j]].numberset
                if testDegree > bestDegree do
                (
                    bestDegree = testDegree
                    bestIndex = j
                )
            )

            if bestIndex != i do
            (
                local temp = islandOrder[i]
                islandOrder[i] = islandOrder[bestIndex]
                islandOrder[bestIndex] = temp
            )
        )

        local overflow = 0

        for orderIndex = 1 to islandCount do
        (
            local islandIndex = islandOrder[orderIndex]
            local blockedGroups = #{}

            for hardIsland in hardNeighbors[islandIndex] do
            (
                local hardGroup = islandGroups[hardIsland]
                if hardGroup != undefined and hardGroup > 0 do blockedGroups[hardGroup] = true
            )

            local pickedGroup = 0
            for groupIndex = 1 to 32 while pickedGroup == 0 do
            (
                if not blockedGroups[groupIndex] do pickedGroup = groupIndex
            )

            if pickedGroup == 0 do
            (
                overflow += 1
                pickedGroup = (mod (islandIndex - 1) 32) + 1
            )

            islandGroups[islandIndex] = pickedGroup
        )

        local usedGroups = #{}
        for islandIndex = 1 to islandCount do
        (
            if islandGroups[islandIndex] > 0 do usedGroups[islandGroups[islandIndex]] = true
        )

        #(islandGroups, usedGroups.numberset, overflow)
    )

    fn UVAAS_colorFaces faceCount smoothLinks hardPairs =
    (
        local hardNeighbors = #()
        local faceGroups = #()
        local faceOrder = #()
        hardNeighbors.count = faceCount
        faceGroups.count = faceCount
        faceOrder.count = faceCount

        for faceIndex = 1 to faceCount do
        (
            hardNeighbors[faceIndex] = #{}
            faceGroups[faceIndex] = 0
            faceOrder[faceIndex] = faceIndex
        )

        for hardPair in hardPairs do
        (
            local faceA = hardPair[1]
            local faceB = hardPair[2]

            if faceA >= 1 and faceA <= faceCount and faceB >= 1 and faceB <= faceCount and faceA != faceB do
            (
                hardNeighbors[faceA][faceB] = true
                hardNeighbors[faceB][faceA] = true
            )
        )

        for i = 1 to faceCount - 1 do
        (
            local bestIndex = i
            local bestDegree = hardNeighbors[faceOrder[i]].numberset

            for j = i + 1 to faceCount do
            (
                local testDegree = hardNeighbors[faceOrder[j]].numberset
                if testDegree > bestDegree do
                (
                    bestDegree = testDegree
                    bestIndex = j
                )
            )

            if bestIndex != i do
            (
                local temp = faceOrder[i]
                faceOrder[i] = faceOrder[bestIndex]
                faceOrder[bestIndex] = temp
            )
        )

        local overflow = 0

        for orderIndex = 1 to faceCount do
        (
            local faceIndex = faceOrder[orderIndex]
            local blockedGroups = #{}

            for hardFace in hardNeighbors[faceIndex] do
            (
                local hardGroup = faceGroups[hardFace]
                if hardGroup != undefined and hardGroup > 0 do blockedGroups[hardGroup] = true
            )

            local pickedGroup = 0
            local bestSmoothScore = -1

            for groupIndex = 1 to 32 where not blockedGroups[groupIndex] do
            (
                local smoothScore = 0
                for smoothFace in smoothLinks[faceIndex] do
                (
                    if faceGroups[smoothFace] == groupIndex do smoothScore += 1
                )

                if smoothScore > bestSmoothScore do
                (
                    bestSmoothScore = smoothScore
                    pickedGroup = groupIndex
                )
            )

            if pickedGroup == 0 do
            (
                overflow += 1
                local bestConflictCount = faceCount + 1

                for groupIndex = 1 to 32 do
                (
                    local conflictCount = 0
                    for hardFace in hardNeighbors[faceIndex] do
                    (
                        if faceGroups[hardFace] == groupIndex do conflictCount += 1
                    )

                    if conflictCount < bestConflictCount do
                    (
                        bestConflictCount = conflictCount
                        pickedGroup = groupIndex
                    )
                )

                if pickedGroup == 0 do pickedGroup = 1
            )

            faceGroups[faceIndex] = pickedGroup
        )

        local usedGroups = #{}
        for faceIndex = 1 to faceCount do
        (
            if faceGroups[faceIndex] > 0 do usedGroups[faceGroups[faceIndex]] = true
        )

        #(faceGroups, usedGroups.numberset, overflow)
    )

    fn UVAAS_applyNode node uvChannel angleThreshold useUvSeams useAngleRule =
    (
        local uvAnalysis = UVAAS_buildAnalysis node uvChannel angleThreshold true false
        if uvAnalysis[1] != #ok then return uvAnalysis

        local splitAnalysis = UVAAS_buildAnalysis node uvChannel angleThreshold true true
        if splitAnalysis[1] != #ok then return splitAnalysis

        local faceCount = uvAnalysis[7]
        local uvComponentData = UVAAS_buildComponents faceCount uvAnalysis[2]
        local faceToIsland = uvComponentData[1]
        local islandFaces = uvComponentData[2]
        local islandHardPairs = #()

        for hardPair in splitAnalysis[3] do
        (
            local islandA = faceToIsland[hardPair[1]]
            local islandB = faceToIsland[hardPair[2]]

            if islandA != undefined and islandB != undefined and islandA != islandB do
            (
                append islandHardPairs #(islandA, islandB)
            )
        )

        local colorData = UVAAS_colorIslandGraph islandFaces.count islandHardPairs
        local islandGroups = colorData[1]
        local usedGroupCount = colorData[2]
        local overflow = colorData[3]

        for islandIndex = 1 to islandFaces.count do
        (
            local groupIndex = islandGroups[islandIndex]
            if groupIndex >= 1 and groupIndex <= 32 do
            (
                polyop.setFaceSmoothGroup node islandFaces[islandIndex] (UVAAS_sgMask groupIndex) add:false
            )
        )

        update node
        redrawViews()
        #(#ok, usedGroupCount, splitAnalysis[6], splitAnalysis[5], overflow)
    )

    fn UVAAS_selectHardEdges node uvChannel angleThreshold useUvSeams useAngleRule =
    (
        local analysis = UVAAS_buildAnalysis node uvChannel angleThreshold true true
        if analysis[1] != #ok then return analysis

        polyop.setEdgeSelection node analysis[4]
        update node
        redrawViews()
        #(#ok, analysis[4].numberset, analysis[6], analysis[5], 0)
    )

    fn UVAAS_collectUsedSmoothGroups node =
    (
        if not (UVAAS_isEditablePoly node) then return #{}

        local usedGroups = #{}
        local faceCount = polyop.getNumFaces node

        for faceIndex = 1 to faceCount do
        (
            local sgValue = try (polyop.getFaceSmoothGroup node faceIndex) catch 0
            for groupIndex = 1 to 32 do
            (
                if UVAAS_sgContains sgValue groupIndex do usedGroups[groupIndex] = true
            )
        )

        usedGroups
    )

    fn UVAAS_selectFacesBySmoothGroups node groups clearSelection =
    (
        if not (UVAAS_isEditablePoly node) then return #(#fail, "Object is not Editable Poly.")
        if groups.count == 0 then return #(#fail, "No smoothing group is checked.")

        local faceCount = polyop.getNumFaces node
        local selectedFaces = if clearSelection then #{} else (try (copy (polyop.getFaceSelection node)) catch (#{}))

        for faceIndex = 1 to faceCount do
        (
            local sgValue = try (polyop.getFaceSmoothGroup node faceIndex) catch 0
            local matched = false

            for groupIndex in groups do
            (
                if UVAAS_sgContains sgValue groupIndex do matched = true
            )

            if matched do selectedFaces[faceIndex] = true
        )

        polyop.setFaceSelection node selectedFaces
        update node
        redrawViews()
        #(#ok, selectedFaces.numberset, groups.count, 0, 0)
    )

    fn UVAAS_smoothMaskFromGroups groups =
    (
        local sgValue = 0
        for groupIndex in groups do sgValue = bit.set sgValue groupIndex true
        sgValue
    )

    fn UVAAS_setSelectedFacesSmoothGroups node groups =
    (
        if not (UVAAS_isEditablePoly node) then return #(#fail, "Object is not Editable Poly.")
        if groups.count == 0 then return #(#fail, "No smoothing group is checked.")

        local faceSelection = try (copy (polyop.getFaceSelection node)) catch (#{})
        if faceSelection.numberset < 1 then return #(#fail, "Select one or more faces first.")

        local sgValue = UVAAS_smoothMaskFromGroups groups
        polyop.setFaceSmoothGroup node faceSelection sgValue add:false
        update node
        redrawViews()
        #(#ok, faceSelection.numberset, groups.count, 0, 0)
    )

    fn UVAAS_sgSharesAny sgValue groups =
    (
        local matched = false
        for groupIndex in groups do
        (
            if UVAAS_sgContains sgValue groupIndex do matched = true
        )
        matched
    )

    fn UVAAS_groupsFromSmoothMask sgValue =
    (
        local groups = #()
        for groupIndex = 1 to 32 do
        (
            if UVAAS_sgContains sgValue groupIndex do append groups groupIndex
        )
        groups
    )

    fn UVAAS_buildFaceAdjacency node =
    (
        local faceCount = polyop.getNumFaces node
        local adjacency = #()
        adjacency.count = faceCount
        for faceIndex = 1 to faceCount do adjacency[faceIndex] = #()

        local edgeTable = dotNetObject "System.Collections.Hashtable"

        for faceIndex = 1 to faceCount do
        (
            local geoVerts = UVAAS_toIndexArray (polyop.getFaceVerts node faceIndex)
            local vertCount = geoVerts.count

            if vertCount >= 3 do
            (
                for i = 1 to vertCount do
                (
                    local nextIndex = if i == vertCount then 1 else i + 1
                    local key = UVAAS_edgeKey geoVerts[i] geoVerts[nextIndex]

                    if edgeTable.ContainsKey key then
                    (
                        local existingFaces = edgeTable.Item[key]
                        for otherFace in existingFaces where otherFace != faceIndex do
                        (
                            UVAAS_appendUnique adjacency[otherFace] faceIndex
                            UVAAS_appendUnique adjacency[faceIndex] otherFace
                        )
                        append existingFaces faceIndex
                    )
                    else
                    (
                        edgeTable.Add key #(faceIndex)
                    )
                )
            )
        )

        adjacency
    )

    fn UVAAS_selectConnectedSameSmoothGroup node =
    (
        if not (UVAAS_isEditablePoly node) then return #(#fail, "Object is not Editable Poly.")

        local faceSelection = try (copy (polyop.getFaceSelection node)) catch (#{})
        if faceSelection.numberset < 1 then return #(#fail, "Select one face first.")

        local faceCount = polyop.getNumFaces node
        local adjacency = UVAAS_buildFaceAdjacency node
        local resultFaces = #{}
        local visited = #{}

        for seedFace in faceSelection do
        (
            if seedFace >= 1 and seedFace <= faceCount and not visited[seedFace] do
            (
                local seedGroups = UVAAS_groupsFromSmoothMask (try (polyop.getFaceSmoothGroup node seedFace) catch 0)
                if seedGroups.count > 0 do
                (
                    local queue = #(seedFace)
                    local head = 1
                    visited[seedFace] = true

                    while head <= queue.count do
                    (
                        local faceIndex = queue[head]
                        head += 1
                        resultFaces[faceIndex] = true

                        for nextFace in adjacency[faceIndex] where not visited[nextFace] do
                        (
                            local nextSg = try (polyop.getFaceSmoothGroup node nextFace) catch 0
                            if UVAAS_sgSharesAny nextSg seedGroups do
                            (
                                visited[nextFace] = true
                                append queue nextFace
                            )
                        )
                    )
                )
            )
        )

        if resultFaces.numberset < 1 then return #(#fail, "Selected face has no smoothing group.")

        polyop.setFaceSelection node resultFaces
        update node
        redrawViews()
        #(#ok, resultFaces.numberset, faceSelection.numberset, 0, 0)
    )

    fn UVAAS_selectConnectedSameUvIsland node uvChannel =
    (
        if not (UVAAS_isEditablePoly node) then return #(#fail, "Object is not Editable Poly.")

        local faceSelection = try (copy (polyop.getFaceSelection node)) catch (#{})
        if faceSelection.numberset < 1 then return #(#fail, "Select one face first.")

        local analysis = UVAAS_buildAnalysis node uvChannel 180.0 true false
        if analysis[1] != #ok then return analysis

        local adjacency = analysis[2]
        local faceCount = polyop.getNumFaces node
        local resultFaces = #{}
        local visited = #{}

        for seedFace in faceSelection do
        (
            if seedFace >= 1 and seedFace <= faceCount and not visited[seedFace] do
            (
                local queue = #(seedFace)
                local head = 1
                visited[seedFace] = true

                while head <= queue.count do
                (
                    local faceIndex = queue[head]
                    head += 1
                    resultFaces[faceIndex] = true

                    for nextFace in adjacency[faceIndex] where not visited[nextFace] do
                    (
                        visited[nextFace] = true
                        append queue nextFace
                    )
                )
            )
        )

        if resultFaces.numberset < 1 then return #(#fail, "Selected face has no UV island.")

        polyop.setFaceSelection node resultFaces
        update node
        redrawViews()
        #(#ok, resultFaces.numberset, faceSelection.numberset, 0, 0)
    )

    fn UVAAS_getTargets autoConvert =
    (
        local targets = #()
        local selectedNodes = for node in selection collect node

        for node in selectedNodes where UVAAS_isGeometryNode node do
        (
            if autoConvert then
            (
                try
                (
                    convertToPoly node
                    if UVAAS_isEditablePoly node do append targets node
                )
                catch()
            )
            else if UVAAS_isEditablePoly node then
            (
                append targets node
            )
        )
        targets
    )

    fn UVAAS_reportLine node result =
    (
        if result[1] == #ok then
        (
            node.name + ": " + (result[2] as string) + " smooth groups, split edges " + (result[3] as string)
        )
        else
        (
            node.name + ": " + result[2]
        )
    )

    fn UVAAS_connectedReportLine node result =
    (
        if result[1] == #ok then
        (
            node.name + ": connected faces " + (result[2] as string)
        )
        else
        (
            node.name + ": " + result[2]
        )
    )

    fn UVAAS_selectBySgReportLine node result =
    (
        if result[1] == #ok then
        (
            node.name + ": selected faces " + (result[2] as string)
        )
        else
        (
            node.name + ": " + result[2]
        )
    )

    fn UVAAS_setSgReportLine node result =
    (
        if result[1] == #ok then
        (
            node.name + ": set faces " + (result[2] as string)
        )
        else
        (
            node.name + ": " + result[2]
        )
    )

    try
    (
        try (destroyDialog MaxUVAngleAutoSmooth_Rebuild_Rollout) catch()

        rollout MaxUVAngleAutoSmooth_Rebuild_Rollout "UV Angle Auto Smooth Rebuild" width:340 height:596
        (
            local lastFaceSignature = ""
            local currentUsedGroups = #{}
            local showAllGroups = false
            local suppressSgEvents = false

        groupBox grpRules "Rules" pos:[10,10] width:320 height:124
        spinner spnAngle "Split seam if fold <" pos:[24,36] width:190 height:18 range:[0.1,180.0,90.0] type:#float scale:1 fieldWidth:58
        label lblDeg "deg" pos:[220,38] width:38 height:18
        spinner spnChannel "UV channel" pos:[24,64] width:190 height:18 range:[1,99,1] type:#integer fieldWidth:58
        checkbox chkUv "Require UV seam / island border" pos:[24,92] width:246 height:18 checked:true
        checkbox chkAngle "Require angle below threshold" pos:[24,114] width:248 height:18 checked:true

        groupBox grpOptions "Options" pos:[10,144] width:320 height:56
        checkbox chkConvert "Apply stack / Convert to Editable Poly" pos:[24,168] width:270 height:18 checked:true

        button btnApply "Set Smooth Groups" pos:[10,210] width:154 height:32
        button btnPreview "Select Split Edges" pos:[176,210] width:154 height:32

        groupBox grpResult "Result" pos:[10,254] width:320 height:82
        label lblUsedGroups "Smooth Groups: -" pos:[24,276] width:292 height:18
        button btnConnectedSameUV "Select Same UV Area" pos:[24,302] width:142 height:26
        button btnConnectedSameSG "Select Same SG Area" pos:[174,302] width:142 height:26

        groupBox grpSelectBySG "Select By Smooth Groups" pos:[10,348] width:320 height:210
        checkButton btnSG01 "1" pos:[24,372] width:24 height:20
        checkButton btnSG02 "2" pos:[49,372] width:24 height:20
        checkButton btnSG03 "3" pos:[74,372] width:24 height:20
        checkButton btnSG04 "4" pos:[99,372] width:24 height:20
        checkButton btnSG05 "5" pos:[124,372] width:24 height:20
        checkButton btnSG06 "6" pos:[149,372] width:24 height:20
        checkButton btnSG07 "7" pos:[174,372] width:24 height:20
        checkButton btnSG08 "8" pos:[199,372] width:24 height:20
        checkButton btnSG09 "9" pos:[24,396] width:24 height:20
        checkButton btnSG10 "10" pos:[49,396] width:24 height:20
        checkButton btnSG11 "11" pos:[74,396] width:24 height:20
        checkButton btnSG12 "12" pos:[99,396] width:24 height:20
        checkButton btnSG13 "13" pos:[124,396] width:24 height:20
        checkButton btnSG14 "14" pos:[149,396] width:24 height:20
        checkButton btnSG15 "15" pos:[174,396] width:24 height:20
        checkButton btnSG16 "16" pos:[199,396] width:24 height:20
        checkButton btnSG17 "17" pos:[24,420] width:24 height:20
        checkButton btnSG18 "18" pos:[49,420] width:24 height:20
        checkButton btnSG19 "19" pos:[74,420] width:24 height:20
        checkButton btnSG20 "20" pos:[99,420] width:24 height:20
        checkButton btnSG21 "21" pos:[124,420] width:24 height:20
        checkButton btnSG22 "22" pos:[149,420] width:24 height:20
        checkButton btnSG23 "23" pos:[174,420] width:24 height:20
        checkButton btnSG24 "24" pos:[199,420] width:24 height:20
        checkButton btnSG25 "25" pos:[24,444] width:24 height:20
        checkButton btnSG26 "26" pos:[49,444] width:24 height:20
        checkButton btnSG27 "27" pos:[74,444] width:24 height:20
        checkButton btnSG28 "28" pos:[99,444] width:24 height:20
        checkButton btnSG29 "29" pos:[124,444] width:24 height:20
        checkButton btnSG30 "30" pos:[149,444] width:24 height:20
        checkButton btnSG31 "31" pos:[174,444] width:24 height:20
        checkButton btnSG32 "32" pos:[199,444] width:24 height:20
        button btnSgOk "OK" pos:[224,372] width:92 height:24
        button btnSgCancel "Cancel" pos:[224,400] width:92 height:24
        button btnSgPlus "+" pos:[224,428] width:92 height:24 toolTip:"Show all 32 smoothing groups"
        button btnSgSet "Set Selected" pos:[224,456] width:92 height:24 toolTip:"Set selected faces to the checked smoothing groups"
        label lblFaceGroups "Face SG: -" pos:[24,486] width:192 height:18
        checkbox chkSgClearSelection "Clear Selection" pos:[24,510] width:130 height:18 checked:true

        label lblStatus "Select Editable Poly objects, then run." pos:[12,574] width:318 height:16
        timer tmrFaceWatch interval:350 active:false

        fn sgControls =
        (
            #(btnSG01, btnSG02, btnSG03, btnSG04, btnSG05, btnSG06, btnSG07, btnSG08,
              btnSG09, btnSG10, btnSG11, btnSG12, btnSG13, btnSG14, btnSG15, btnSG16,
              btnSG17, btnSG18, btnSG19, btnSG20, btnSG21, btnSG22, btnSG23, btnSG24,
              btnSG25, btnSG26, btnSG27, btnSG28, btnSG29, btnSG30, btnSG31, btnSG32)
        )

        fn selectedSgGroups =
        (
            local groups = #()
            local controls = sgControls()
            for groupIndex = 1 to controls.count do
            (
                if controls[groupIndex].visible and controls[groupIndex].checked do append groups groupIndex
            )
            groups
        )

        fn hasSelectedFaces targets =
        (
            for node in targets do
            (
                local faceSelection = try (copy (polyop.getFaceSelection node)) catch (#{} )
                if faceSelection.numberset > 0 do return true
            )
            false
        )

        fn clearSgButtons =
        (
            local controls = sgControls()
            for ctrl in controls do ctrl.checked = false
        )

        fn checkSgButtons groups =
        (
            local controls = sgControls()
            for groupIndex = 1 to controls.count do
            (
                controls[groupIndex].checked = (controls[groupIndex].visible and groups[groupIndex])
            )
        )

        fn groupListText groups =
        (
            if groups.numberset == 0 then return "-"

            local text = ""
            for groupIndex in groups do
            (
                if text != "" do text += ", "
                text += groupIndex as string
            )
            text
        )

        fn setSgButtonsVisible usedGroups checkFirst =
        (
            local controls = sgControls()
            local shownCount = 0
            local firstGroup = 0
            currentUsedGroups = copy usedGroups

            for groupIndex = 1 to controls.count do
            (
                local ctrl = controls[groupIndex]
                ctrl.checked = false
                ctrl.visible = false

                if usedGroups[groupIndex] or showAllGroups do
                (
                    local col = mod shownCount 8
                    local row = (floor ((shownCount as float) / 8.0)) as integer
                    ctrl.pos = [24 + col * 25, 372 + row * 24]
                    ctrl.visible = true
                    shownCount += 1
                    if firstGroup == 0 and usedGroups[groupIndex] do firstGroup = groupIndex
                )
            )

            if checkFirst and firstGroup > 0 do controls[firstGroup].checked = true
            btnSgOk.enabled = shownCount > 0
            btnSgCancel.enabled = shownCount > 0
            btnSgPlus.enabled = not showAllGroups
            btnSgSet.enabled = shownCount > 0
            shownCount
        )

        fn refreshUsedGroupCount targets =
        (
            local usedGroups = #{}
            showAllGroups = false
            for node in targets do
            (
                local nodeGroups = UVAAS_collectUsedSmoothGroups node
                for groupIndex in nodeGroups do usedGroups[groupIndex] = true
            )

            lblUsedGroups.text = "Smooth Groups: " + (usedGroups.numberset as string)
            setSgButtonsVisible usedGroups false
            usedGroups.numberset
        )

        fn selectedFaceGroupsData targets =
        (
            local groups = #{}
            local faceCount = 0
            local signature = ""

            for node in targets do
            (
                local faceSelection = try (copy (polyop.getFaceSelection node)) catch (#{})
                if faceSelection.numberset > 0 do
                (
                    signature += node.name + ":"
                    for faceIndex in faceSelection do
                    (
                        local sgValue = try (polyop.getFaceSmoothGroup node faceIndex) catch 0
                        signature += (faceIndex as string) + "=" + (sgValue as string) + ","
                        faceCount += 1

                        for groupIndex = 1 to 32 do
                        (
                            if UVAAS_sgContains sgValue groupIndex do groups[groupIndex] = true
                        )
                    )
                    signature += ";"
                )
            )

            #(groups, faceCount, signature)
        )

        fn refreshFromSelectedFaces forceRefresh =
        (
            local targets = UVAAS_getTargets false
            if targets.count == 0 then return false

            local data = selectedFaceGroupsData targets
            local faceGroups = data[1]
            local faceCount = data[2]
            local signature = data[3]

            if not forceRefresh and signature == lastFaceSignature then return false
            lastFaceSignature = signature

            if faceCount > 0 then
            (
                lblFaceGroups.text = "Face SG: " + (groupListText faceGroups)

                local visibleGroups = #{}
                for node in targets do
                (
                    local nodeGroups = UVAAS_collectUsedSmoothGroups node
                    for groupIndex in nodeGroups do visibleGroups[groupIndex] = true
                )

                for groupIndex in faceGroups do visibleGroups[groupIndex] = true
                setSgButtonsVisible visibleGroups false
                checkSgButtons faceGroups
            )
            else
            (
                lblFaceGroups.text = "Face SG: -"
            )

            true
        )

        fn selectFacesBySg =
        (
            local groups = selectedSgGroups()
            if groups.count == 0 then
            (
                messageBox "Check one or more smoothing groups first." title:"UV Angle Auto Smooth"
                return false
            )

            local targets = UVAAS_getTargets chkConvert.checked
            if targets.count == 0 then
            (
                messageBox "No Editable Poly targets found." title:"UV Angle Auto Smooth"
                return false
            )

            local reportLines = #()
            local okCount = 0

            undo "Select By Smooth Groups" on
            (
                for node in targets do
                (
                    local result = UVAAS_selectFacesBySmoothGroups node groups chkSgClearSelection.checked
                    if result[1] == #ok do okCount += 1
                    append reportLines (UVAAS_selectBySgReportLine node result)
                )
            )

            max modify mode
            subObjectLevel = 4
            lblStatus.text = (okCount as string) + " object(s) selected by SG."

            if okCount < targets.count then
            (
                local summary = ""
                for line in reportLines do summary += line + "\n"
                messageBox summary title:"UV Angle Auto Smooth"
            )
            true
        )

        fn setSelectedFacesSgFromGroups groups =
        (
            if groups.count == 0 then
            (
                messageBox "Check one or more smoothing groups first." title:"UV Angle Auto Smooth"
                return false
            )

            local targets = UVAAS_getTargets chkConvert.checked
            if targets.count == 0 then
            (
                messageBox "No Editable Poly targets found." title:"UV Angle Auto Smooth"
                return false
            )

            local seedTargets = #()
            for node in targets do
            (
                local faceSelection = try (polyop.getFaceSelection node) catch (#{})
                if faceSelection.numberset > 0 do append seedTargets node
            )

            if seedTargets.count == 0 then
            (
                messageBox "Select one or more faces first." title:"UV Angle Auto Smooth"
                return false
            )

            local reportLines = #()
            local okCount = 0

            undo "Set Selected Faces Smooth Groups" on
            (
                for node in seedTargets do
                (
                    local result = UVAAS_setSelectedFacesSmoothGroups node groups
                    if result[1] == #ok do okCount += 1
                    append reportLines (UVAAS_setSgReportLine node result)
                )
            )

            max modify mode
            subObjectLevel = 4
            refreshUsedGroupCount targets
            lastFaceSignature = ""
            refreshFromSelectedFaces true
            lblStatus.text = (okCount as string) + " object(s) set SG."

            if okCount < seedTargets.count then
            (
                local summary = ""
                for line in reportLines do summary += line + "\n"
                messageBox summary title:"UV Angle Auto Smooth"
            )
            true
        )

        fn setSelectedFacesSg =
        (
            setSelectedFacesSgFromGroups (selectedSgGroups())
        )

        fn sgButtonChanged groupIndex state =
        (
            if suppressSgEvents then return false
            true
        )

        fn selectConnectedSameSg =
        (
            local targets = UVAAS_getTargets chkConvert.checked
            if targets.count == 0 then
            (
                messageBox "No Editable Poly targets found." title:"UV Angle Auto Smooth"
                return false
            )

            local seedTargets = #()
            for node in targets do
            (
                local faceSelection = try (polyop.getFaceSelection node) catch (#{})
                if faceSelection.numberset > 0 do append seedTargets node
            )

            if seedTargets.count == 0 then
            (
                messageBox "Select one face first." title:"UV Angle Auto Smooth"
                return false
            )

            local reportLines = #()
            local okCount = 0
            local selectedFaceTotal = 0

            undo "Select Connected Same Smooth Group" on
            (
                for node in seedTargets do
                (
                    local result = UVAAS_selectConnectedSameSmoothGroup node
                    if result[1] == #ok do
                    (
                        okCount += 1
                        selectedFaceTotal += result[2]
                    )
                    append reportLines (UVAAS_connectedReportLine node result)
                )
            )

            max modify mode
            subObjectLevel = 4

            local summary = ""
            for line in reportLines do summary += line + "\n"
            lblStatus.text = "SG Area faces: " + (selectedFaceTotal as string)

            if okCount == 0 then
            (
                messageBox summary title:"UV Angle Auto Smooth"
            )
            true
        )

        fn selectConnectedSameUvArea =
        (
            local targets = UVAAS_getTargets chkConvert.checked
            if targets.count == 0 then
            (
                messageBox "No Editable Poly targets found." title:"UV Angle Auto Smooth Rebuild"
                return false
            )

            local seedTargets = #()
            for node in targets do
            (
                local faceSelection = try (polyop.getFaceSelection node) catch (#{} )
                if faceSelection.numberset > 0 do append seedTargets node
            )

            if seedTargets.count == 0 then
            (
                messageBox "Select one face first." title:"UV Angle Auto Smooth Rebuild"
                return false
            )

            local reportLines = #()
            local okCount = 0
            local selectedFaceTotal = 0

            undo "Select Connected Same UV Area" on
            (
                for node in seedTargets do
                (
                    local result = UVAAS_selectConnectedSameUvIsland node spnChannel.value
                    if result[1] == #ok do
                    (
                        okCount += 1
                        selectedFaceTotal += result[2]
                    )
                    append reportLines (UVAAS_connectedReportLine node result)
                )
            )

            max modify mode
            subObjectLevel = 4

            local summary = ""
            for line in reportLines do summary += line + "\n"
            lblStatus.text = "UV Area faces: " + (selectedFaceTotal as string)

            if okCount == 0 then
            (
                messageBox summary title:"UV Angle Auto Smooth Rebuild"
            )
            true
        )

        fn runTool previewOnly:false =
        (
            if selection.count == 0 then
            (
                messageBox "Select one or more geometry objects first." title:"UV Angle Auto Smooth"
                return false
            )

            local targets = UVAAS_getTargets chkConvert.checked
            if targets.count == 0 then
            (
                messageBox "No Editable Poly targets found. Enable conversion if you want to convert selected geometry." title:"UV Angle Auto Smooth"
                return false
            )

            local reportLines = #()
            local okCount = 0
            local warnCount = 0
            local useUvRule = true
            local useAngleRule = true
            chkUv.checked = true
            chkAngle.checked = true

            undo "UV Angle Auto Smooth" on
            (
                for node in targets do
                (
                    local result = if previewOnly then
                    (
                        UVAAS_selectHardEdges node spnChannel.value spnAngle.value useUvRule useAngleRule
                    )
                    else
                    (
                        UVAAS_applyNode node spnChannel.value spnAngle.value useUvRule useAngleRule
                    )

                    if result[1] == #ok then
                    (
                        okCount += 1
                        if result[5] > 0 do warnCount += 1
                    )

                    append reportLines (UVAAS_reportLine node result)
                )
            )

            if previewOnly do
            (
                max modify mode
                subObjectLevel = 2
            )

            local summary = ""
            for line in reportLines do summary += line + "\n"

            if not previewOnly then
            (
                if okCount > 0 then
                (
                    local usedCount = refreshUsedGroupCount targets
                    lastFaceSignature = ""
                    refreshFromSelectedFaces true
                    lblStatus.text = "Done. Smooth Groups: " + (usedCount as string)
                )
                else
                (
                    lblUsedGroups.text = "Smooth Groups: -"
                    lblStatus.text = "Failed."
                )
            )
            else
            (
                lblStatus.text = (okCount as string) + " object(s) previewed."
            )

            if warnCount > 0 do
            (
                summary += "\nWarning: one or more objects needed more than 32 local smoothing groups. Some distant hard regions may reuse group numbers."
                messageBox summary title:"UV Angle Auto Smooth"
            )

            if okCount < targets.count and warnCount == 0 do
            (
                messageBox summary title:"UV Angle Auto Smooth"
            )
            true
        )

        on btnApply pressed do runTool previewOnly:false
        on btnPreview pressed do runTool previewOnly:true
        on btnConnectedSameSG pressed do selectConnectedSameSg()
        on btnConnectedSameUV pressed do selectConnectedSameUvArea()
        on btnSgOk pressed do selectFacesBySg()
        on btnSgCancel pressed do clearSgButtons()
        on btnSgSet pressed do setSelectedFacesSg()
        on btnSgPlus pressed do
        (
            showAllGroups = true
            setSgButtonsVisible currentUsedGroups false
            lastFaceSignature = ""
            refreshFromSelectedFaces true
        )
        on btnSG01 changed state do sgButtonChanged 1 state
        on btnSG02 changed state do sgButtonChanged 2 state
        on btnSG03 changed state do sgButtonChanged 3 state
        on btnSG04 changed state do sgButtonChanged 4 state
        on btnSG05 changed state do sgButtonChanged 5 state
        on btnSG06 changed state do sgButtonChanged 6 state
        on btnSG07 changed state do sgButtonChanged 7 state
        on btnSG08 changed state do sgButtonChanged 8 state
        on btnSG09 changed state do sgButtonChanged 9 state
        on btnSG10 changed state do sgButtonChanged 10 state
        on btnSG11 changed state do sgButtonChanged 11 state
        on btnSG12 changed state do sgButtonChanged 12 state
        on btnSG13 changed state do sgButtonChanged 13 state
        on btnSG14 changed state do sgButtonChanged 14 state
        on btnSG15 changed state do sgButtonChanged 15 state
        on btnSG16 changed state do sgButtonChanged 16 state
        on btnSG17 changed state do sgButtonChanged 17 state
        on btnSG18 changed state do sgButtonChanged 18 state
        on btnSG19 changed state do sgButtonChanged 19 state
        on btnSG20 changed state do sgButtonChanged 20 state
        on btnSG21 changed state do sgButtonChanged 21 state
        on btnSG22 changed state do sgButtonChanged 22 state
        on btnSG23 changed state do sgButtonChanged 23 state
        on btnSG24 changed state do sgButtonChanged 24 state
        on btnSG25 changed state do sgButtonChanged 25 state
        on btnSG26 changed state do sgButtonChanged 26 state
        on btnSG27 changed state do sgButtonChanged 27 state
        on btnSG28 changed state do sgButtonChanged 28 state
        on btnSG29 changed state do sgButtonChanged 29 state
        on btnSG30 changed state do sgButtonChanged 30 state
        on btnSG31 changed state do sgButtonChanged 31 state
        on btnSG32 changed state do sgButtonChanged 32 state
        on tmrFaceWatch tick do (try (refreshFromSelectedFaces false) catch())
        on MaxUVAngleAutoSmooth_Rebuild_Rollout open do
        (
            local emptyGroups = #{}
            chkUv.checked = true
            chkAngle.checked = true
            chkUv.enabled = false
            chkAngle.enabled = false
            showAllGroups = false
            setSgButtonsVisible emptyGroups false
            tmrFaceWatch.active = true
        )
        on MaxUVAngleAutoSmooth_Rebuild_Rollout close do
        (
            tmrFaceWatch.active = false
        )
        )

        createDialog MaxUVAngleAutoSmooth_Rebuild_Rollout
    )
    catch
    (
        local errText = ""
        try (errText = getCurrentException() as string) catch (errText = "Unknown MAXScript error.")
        format "MaxUVAngleAutoSmooth_Rebuild load error: %\n" errText
        messageBox ("UV Angle Auto Smooth failed to open.\n\n" + errText) title:"UV Angle Auto Smooth"
    )
)
