﻿-- CompanyPluginManager Bundle adaptation; business implementation remains v4.6.1 Experimental.
-- File load defines helpers and registers the action without opening a dialog.
global HCE_Rollout
global HCE_GuideRollout
global HCS_Rollout
global HCS_TemplateRollout
global HCE_V4Launcher
global HCT_Open
/*
    Hair Card Toolkit v4.6.1 Experimental
    3ds Max / MAXScript

    Edits selected hair-card ELEMENTS inside one or more Editable Poly nodes.
    No preview mesh is created. Only vertices belonging to selected elements move.
    Control splines are temporary and are deleted on Apply or Cancel.
*/

try (destroyDialog HCE_Rollout) catch()
try (destroyDialog HCE_GuideRollout) catch()
try (destroyDialog HCS_Rollout) catch()
try (destroyDialog HCS_TemplateRollout) catch()
try (destroyDialog HCE_V4Launcher) catch()
try (deleteAllChangeHandlers id:#HCE_LiveControl) catch()
try (deleteAllChangeHandlers id:#HCS_LiveCard) catch()

global HCE_Items = #()
global HCE_Active = false
global HCE_IsUpdating = false
global HCE_ControlShape = undefined
global HCE_ChangeHandlers = #()
global HCE_LiveEnabled = true
global HCE_TwistAngle = 0.0
global HCE_TwistMode = #tail
global HCE_TwistReverse = false
global HCE_TwistKnotRadius = 1.0
global HCE_TwistProfileMode = #tail
global HCE_TailTwistAngle = 0.0
global HCE_WholeTwistAngle = 0.0
global HCE_WidthScale = 1.0
global HCE_WidthMode = #tail
global HCE_WidthReverse = false
global HCE_WidthKnotRadius = 1.0
global HCE_WidthProfileMode = #tail
global HCE_TailWidthScale = 1.0
global HCE_WholeWidthScale = 1.0
global HCE_SuppressUI
if HCE_SuppressUI == undefined do HCE_SuppressUI = false

struct HCE_ItemData
(
    source,
    curve,
    splineIndex = 1,
    faces = #{},
    vertIDs = #(),
    params = #(),
    localCoords = #(),
    originalWorld = #(),
    seedWidth = [1,0,0],
    lastCurveState = #(),
    knotTwistAngles = #(),
    knotWidthScales = #()
)

struct HCE_FlowJob
(
    source,
    edges = #{}
)

struct HCE_FlowSourceState
(
    source,
    faceSelection = #{},
    edgeSelection = #{}
)

struct HCE_InsertFlowPlan
(
    source,
    edges = #{},
    lineCount = 0,
    expectedSegments = 0
)

fn HCE_safeNormalize v fallback:[1,0,0] =
(
    if (length v) < 0.000001 then fallback else normalize v
)

fn HCE_localKnotTwistAngle item u =
(
    if not isValidNode item.curve then return 0.0
    local knotCount = numKnots item.curve item.splineIndex
    if knotCount < 2 then return 0.0
    if item.knotTwistAngles.count != knotCount then return 0.0

    local radius = HCE_TwistKnotRadius / (knotCount - 1.0)
    radius = amax #(radius, 0.000001)
    local weightedAngle = 0.0
    local totalWeight = 0.0
    for k = 1 to knotCount do
    (
        local knotU = (k - 1.0) / (knotCount - 1.0)
        local normalizedDistance = (abs (u - knotU)) / radius
        if normalizedDistance < 1.0 do
        (
            local x = 1.0 - normalizedDistance
            local weight = x*x*(3.0 - 2.0*x)
            weightedAngle += item.knotTwistAngles[k] * weight
            totalWeight += weight
        )
    )
    if totalWeight < 0.000001 then 0.0 else weightedAngle / totalWeight
)

fn HCE_storeCurrentTwistProfile =
(
    if HCE_TwistMode == #tail then HCE_TailTwistAngle = HCE_TwistAngle
    else if HCE_TwistMode == #whole then HCE_WholeTwistAngle = HCE_TwistAngle
)

fn HCE_setTwistEditMode mode =
(
    HCE_storeCurrentTwistProfile()
    if (mode == #tail or mode == #whole) then
    (
        HCE_TwistProfileMode = mode
        HCE_TwistMode = mode
        HCE_TwistAngle = if mode == #tail then HCE_TailTwistAngle else HCE_WholeTwistAngle
    )
    else HCE_TwistMode = #knots
    HCE_TwistMode
)

fn HCE_setCurrentTwistProfileAngle angle =
(
    HCE_TwistAngle = angle
    if HCE_TwistMode == #tail then HCE_TailTwistAngle = angle
    else if HCE_TwistMode == #whole then HCE_WholeTwistAngle = angle
    angle
)

fn HCE_twistBaseAngleAtParam u =
(
    -- 三层旋转始终同时存在；当前模式只决定 UI 正在编辑哪一层。
    if HCE_TwistMode == #tail then HCE_TailTwistAngle = HCE_TwistAngle
    else if HCE_TwistMode == #whole then HCE_WholeTwistAngle = HCE_TwistAngle
    local s = if HCE_TwistReverse then (1.0-u) else u
    s = amax #(0.0, amin #(1.0, s))
    HCE_WholeTwistAngle + HCE_TailTwistAngle*s*s*(3.0-2.0*s)
)

fn HCE_twistAngleAtParam item u =
(
    HCE_twistBaseAngleAtParam u + HCE_localKnotTwistAngle item u
)

fn HCE_selectedKnotAngleInfo =
(
    local selectedCount = 0
    local firstAngle = undefined
    local mixedValues = false
    for item in HCE_Items where isValidNode item.curve do
    (
        local selectedKnots = getKnotSelection item.curve item.splineIndex
        for k = 1 to item.knotTwistAngles.count where (findItem selectedKnots k) != 0 do
        (
            local angle = item.knotTwistAngles[k]
            if firstAngle == undefined then firstAngle = angle
            else if (abs (angle - firstAngle)) > 0.0001 do mixedValues = true
            selectedCount += 1
        )
    )
    #(selectedCount, if firstAngle == undefined then 0.0 else firstAngle, mixedValues)
)

fn HCE_setSelectedKnotAngles angle =
(
    local changedCount = 0
    for item in HCE_Items where isValidNode item.curve do
    (
        local selectedKnots = getKnotSelection item.curve item.splineIndex
        for k = 1 to item.knotTwistAngles.count where (findItem selectedKnots k) != 0 do
        (
            item.knotTwistAngles[k] = angle
            changedCount += 1
        )
    )
    changedCount
)

fn HCE_localKnotWidthScale item u =
(
    if not isValidNode item.curve then return 1.0
    local knotCount = numKnots item.curve item.splineIndex
    if knotCount < 2 or item.knotWidthScales.count != knotCount then return 1.0
    local radius = amax #(HCE_WidthKnotRadius / (knotCount - 1.0), 0.000001)
    local weightedDelta = 0.0
    local totalWeight = 0.0
    for k = 1 to knotCount do
    (
        local knotU = (k - 1.0) / (knotCount - 1.0)
        local normalizedDistance = (abs (u - knotU)) / radius
        if normalizedDistance < 1.0 do
        (
            local x = 1.0 - normalizedDistance
            local weight = x*x*(3.0 - 2.0*x)
            weightedDelta += (item.knotWidthScales[k] - 1.0) * weight
            totalWeight += weight
        )
    )
    if totalWeight < 0.000001 then 1.0 else amax #(0.001, 1.0 + weightedDelta/totalWeight)
)

fn HCE_storeCurrentWidthProfile =
(
    if HCE_WidthMode == #tail then HCE_TailWidthScale = HCE_WidthScale
    else if HCE_WidthMode == #whole then HCE_WholeWidthScale = HCE_WidthScale
)

fn HCE_setWidthEditMode mode =
(
    HCE_storeCurrentWidthProfile()
    if (mode == #tail or mode == #whole) then
    (
        HCE_WidthProfileMode = mode
        HCE_WidthMode = mode
        HCE_WidthScale = if mode == #tail then HCE_TailWidthScale else HCE_WholeWidthScale
    )
    else HCE_WidthMode = #knots
    HCE_WidthMode
)

fn HCE_setCurrentWidthProfileScale scale =
(
    scale = amax #(0.001, scale)
    HCE_WidthScale = scale
    if HCE_WidthMode == #tail then HCE_TailWidthScale = scale
    else if HCE_WidthMode == #whole then HCE_WholeWidthScale = scale
    scale
)

fn HCE_widthBaseScaleAtParam u =
(
    -- 三层宽度始终同时存在：整条倍率 × 尾部渐变倍率 × 局部点倍率。
    if HCE_WidthMode == #tail then HCE_TailWidthScale = HCE_WidthScale
    else if HCE_WidthMode == #whole then HCE_WholeWidthScale = HCE_WidthScale
    local s = if HCE_WidthReverse then (1.0-u) else u
    s = amax #(0.0, amin #(1.0, s))
    local tailScale = 1.0+(HCE_TailWidthScale-1.0)*s*s*(3.0-2.0*s)
    amax #(0.001, HCE_WholeWidthScale*tailScale)
)

fn HCE_widthScaleAtParam item u =
(
    amax #(0.001, HCE_widthBaseScaleAtParam u * HCE_localKnotWidthScale item u)
)

fn HCE_selectedKnotWidthInfo =
(
    local selectedCount = 0
    local firstScale = undefined
    local mixedValues = false
    for item in HCE_Items where isValidNode item.curve do
    (
        local selectedKnots = getKnotSelection item.curve item.splineIndex
        for k = 1 to item.knotWidthScales.count where (findItem selectedKnots k) != 0 do
        (
            local scale = item.knotWidthScales[k]
            if firstScale == undefined then firstScale = scale
            else if (abs (scale-firstScale)) > 0.0001 do mixedValues = true
            selectedCount += 1
        )
    )
    #(selectedCount, if firstScale == undefined then 1.0 else firstScale, mixedValues)
)

fn HCE_setSelectedKnotWidthScales scale =
(
    local changedCount = 0
    scale = amax #(0.001, scale)
    for item in HCE_Items where isValidNode item.curve do
    (
        local selectedKnots = getKnotSelection item.curve item.splineIndex
        for k = 1 to item.knotWidthScales.count where (findItem selectedKnots k) != 0 do
        (
            item.knotWidthScales[k] = scale
            changedCount += 1
        )
    )
    changedCount
)

fn HCE_rotatedRibbonAxes item widthAxis binormalAxis u =
(
    -- MAXScript trigonometric functions use degrees.
    local angleDegrees = HCE_twistAngleAtParam item u
    if (abs angleDegrees) < 0.0000001 then return #(widthAxis, binormalAxis)
    local cs = cos angleDegrees
    local sn = sin angleDegrees
    local rotatedWidth = HCE_safeNormalize (widthAxis*cs + binormalAxis*sn) fallback:widthAxis
    local rotatedBinormal = HCE_safeNormalize (binormalAxis*cs - widthAxis*sn) fallback:binormalAxis
    #(rotatedWidth, rotatedBinormal)
)

fn HCE_wrapIndex i count =
(
    (mod ((mod (i - 1) count) + count) count) + 1
)

fn HCE_addUnique arr value =
(
    if (findItem arr value) == 0 do append arr value
)

fn HCE_isEditablePolyNode n =
(
    isValidNode n and (classof n == Editable_Poly or classof n.baseObject == Editable_Poly)
)

fn HCE_getWorldVert polyNode vertID =
(
    local p
    in coordsys world p = polyop.getVert polyNode vertID
    p
)

fn HCE_setWorldVert polyNode vertID p =
(
    in coordsys world polyop.setVert polyNode vertID p
)

fn HCE_selectedElementComponents polyNode =
(
    local selectedFaces = polyop.getFaceSelection polyNode
    if selectedFaces.numberSet == 0 then throw "没有选中多边形。请进入元素级别并选择发片。"

    local remaining = copy selectedFaces
    local components = #()
    while remaining.numberSet > 0 do
    (
        local seed = undefined
        for f in remaining while seed == undefined do seed = f
        local seedBits = #{}
        seedBits[seed] = true
        local wholeElement = polyop.getElementsUsingFace polyNode seedBits
        local selectedPart = wholeElement * selectedFaces
        if selectedPart.numberSet != wholeElement.numberSet then
            throw "当前选择只包含发片的一部分面。请在元素级别选择完整发片。"
        append components wholeElement
        remaining = remaining - wholeElement
    )
    components
)

fn HCE_getElementBoundaryLoop polyNode elementFaces =
(
    local elementVerts = polyop.getVertsUsingFace polyNode elementFaces
    local elementEdges = polyop.getEdgesUsingFace polyNode elementFaces
    local vertCount = polyop.getNumVerts polyNode
    local adjacency = for i = 1 to vertCount collect #()
    local boundaryVerts = #()
    local boundaryEdgeCount = 0

    for e in elementEdges do
    (
        local edgeFaces = polyop.getEdgeFaces polyNode e
        local insideCount = 0
        for f in edgeFaces where elementFaces[f] do insideCount += 1
        if insideCount == 1 do
        (
            local ev = polyop.getEdgeVerts polyNode e
            append adjacency[ev[1]] ev[2]
            append adjacency[ev[2]] ev[1]
            HCE_addUnique boundaryVerts ev[1]
            HCE_addUnique boundaryVerts ev[2]
            boundaryEdgeCount += 1
        )
    )

    if boundaryVerts.count < 6 then throw "所选元素的开放边界顶点太少。"
    if (mod boundaryVerts.count 2) != 0 then throw "所选发片的边界顶点数不是偶数。"
    if boundaryEdgeCount != boundaryVerts.count then throw "所选发片存在孔洞或多个边界。"
    for v in boundaryVerts where adjacency[v].count != 2 do
        throw "所选发片包含分叉、孔洞或非流形边。"

    local ordered = #()
    local startVert = boundaryVerts[1]
    local previous = 0
    local current = startVert
    local finished = false
    while not finished do
    (
        append ordered current
        local neighbors = adjacency[current]
        local nextVert = if neighbors[1] != previous then neighbors[1] else neighbors[2]
        if nextVert == startVert then
            finished = true
        else
        (
            if (findItem ordered nextVert) != 0 then throw "边界追踪遇到重复顶点。"
            previous = current
            current = nextVert
            if ordered.count > boundaryVerts.count then throw "边界追踪失败。"
        )
    )
    if ordered.count != boundaryVerts.count then throw "所选元素不是单一连续发片。"
    ordered
)

fn HCE_rowWorldCenter polyNode rowVerts =
(
    local center = [0,0,0]
    for v in rowVerts do center += HCE_getWorldVert polyNode v
    center / rowVerts.count
)

fn HCE_vertexPathLength polyNode pathVerts =
(
    local pathLength = 0.0
    for i = 2 to pathVerts.count do
        pathLength += distance (HCE_getWorldVert polyNode pathVerts[i-1]) (HCE_getWorldVert polyNode pathVerts[i])
    pathLength
)

fn HCE_boundaryPath boundaryLoop startIndex endIndex =
(
    local result = #()
    local i = startIndex
    local done = false
    while not done do
    (
        append result boundaryLoop[i]
        if i == endIndex then done = true else i = HCE_wrapIndex (i + 1) boundaryLoop.count
    )
    result
)

fn HCE_orderCrossRow rowVerts adjacency polyNode previousRow:undefined =
(
    if rowVerts.count < 2 then return rowVerts
    local startVert = undefined
    for v in rowVerts while startVert == undefined do
    (
        local sameRowCount = 0
        for n in adjacency[v] where (findItem rowVerts n) != 0 do sameRowCount += 1
        if sameRowCount == 1 do startVert = v
    )
    if startVert == undefined then throw "发片横向顶点不能组成开放线段。"

    local ordered = #()
    local previous = 0
    local current = startVert
    while current != 0 do
    (
        append ordered current
        local nextVert = 0
        for n in adjacency[current] while nextVert == 0 do
            if n != previous and (findItem rowVerts n) != 0 and (findItem ordered n) == 0 do nextVert = n
        previous = current
        current = nextVert
    )
    if ordered.count != rowVerts.count then throw "发片横向顶点存在分叉或断开。"

    if previousRow != undefined do
    (
        local keepOrder = (findItem adjacency[ordered[1]] previousRow[1]) != 0
        local reverseOrder = (findItem adjacency[ordered[ordered.count]] previousRow[1]) != 0
        if (not keepOrder and reverseOrder) or (not keepOrder and not reverseOrder and
            distance (HCE_getWorldVert polyNode ordered[ordered.count]) (HCE_getWorldVert polyNode previousRow[1]) <
            distance (HCE_getWorldVert polyNode ordered[1]) (HCE_getWorldVert polyNode previousRow[1])) do
        (
            local reversed = #()
            for i = ordered.count to 1 by -1 do append reversed ordered[i]
            ordered = reversed
        )
    )
    ordered
)

fn HCE_findTwoColumnRibbonRows boundaryLoop polyNode =
(
    local n = boundaryLoop.count
    local rowCount = n / 2
    local worldVerts = for v = 1 to (polyop.getNumVerts polyNode) collect (HCE_getWorldVert polyNode v)
    local bestScore = 1.0e30
    local bestRows = undefined

    for cut = 1 to rowCount do
    (
        local rows = #()
        local centers = #()
        local widthSum = 0.0
        local widthSqSum = 0.0
        for r = 1 to rowCount do
        (
            local ia = HCE_wrapIndex (cut - (r - 1)) n
            local ib = HCE_wrapIndex (cut + r) n
            local va = boundaryLoop[ia]
            local vb = boundaryLoop[ib]
            local w = distance worldVerts[va] worldVerts[vb]
            append rows #(va,vb)
            append centers ((worldVerts[va] + worldVerts[vb]) * 0.5)
            widthSum += w
            widthSqSum += w*w
        )

        local centerLength = 0.0
        for r = 2 to centers.count do centerLength += distance centers[r-1] centers[r]
        local avgWidth = widthSum / rowCount
        local variance = amax #((widthSqSum / rowCount) - avgWidth*avgWidth, 0.0)
        local widthVariation = (sqrt variance) / (amax #(avgWidth, 0.000001))
        local score = (avgWidth / (amax #(centerLength, 0.000001))) + widthVariation*0.03
        if score < bestScore do
        (
            bestScore = score
            bestRows = rows
        )
    )

    if bestRows == undefined then throw "无法识别发片的纵向拓扑。"
    local pivotPoint = polyNode.objectTransform.row4
    local firstCenter = (worldVerts[bestRows[1][1]] + worldVerts[bestRows[1][2]]) * 0.5
    local lastCenter = (worldVerts[bestRows[bestRows.count][1]] + worldVerts[bestRows[bestRows.count][2]]) * 0.5
    if distance lastCenter pivotPoint < distance firstCenter pivotPoint do
    (
        local reversed = #()
        for i = bestRows.count to 1 by -1 do append reversed bestRows[i]
        bestRows = reversed
    )
    bestRows
)

fn HCE_findRibbonRows boundaryLoop polyNode elementFaces =
(
    local elementVerts = polyop.getVertsUsingFace polyNode elementFaces
    local allQuads = true
    for f in elementFaces where (polyop.getFaceVerts polyNode f).count != 4 do allQuads = false
    if not allQuads do
    (
        if boundaryLoop.count != elementVerts.numberSet then
            throw "带中间线的发片需要由规则四边形网格组成；三角面仅支持宽度两列顶点的旧发片。"
        return HCE_findTwoColumnRibbonRows boundaryLoop polyNode
    )

    local elementEdges = polyop.getEdgesUsingFace polyNode elementFaces
    local adjacency = for i = 1 to (polyop.getNumVerts polyNode) collect #()
    for e in elementEdges do
    (
        local ev = polyop.getEdgeVerts polyNode e
        HCE_addUnique adjacency[ev[1]] ev[2]
        HCE_addUnique adjacency[ev[2]] ev[1]
    )

    local cornerIndices = #()
    for i = 1 to boundaryLoop.count where adjacency[boundaryLoop[i]].count == 2 do append cornerIndices i
    if cornerIndices.count != 4 then
        throw "无法识别规则发片的四个角点；请检查是否存在三角面、分叉或缺面。"

    local path1 = HCE_boundaryPath boundaryLoop cornerIndices[1] cornerIndices[2]
    local path2 = HCE_boundaryPath boundaryLoop cornerIndices[2] cornerIndices[3]
    local path3 = HCE_boundaryPath boundaryLoop cornerIndices[3] cornerIndices[4]
    local path4 = HCE_boundaryPath boundaryLoop cornerIndices[4] cornerIndices[1]

    local pair13Length = (HCE_vertexPathLength polyNode path1 + HCE_vertexPathLength polyNode path3) * 0.5
    local pair24Length = (HCE_vertexPathLength polyNode path2 + HCE_vertexPathLength polyNode path4) * 0.5
    local rootEnd
    local tipEnd
    if pair13Length <= pair24Length then
    (
        rootEnd = path1
        tipEnd = path3
    )
    else
    (
        rootEnd = path2
        tipEnd = path4
    )

    if rootEnd.count != tipEnd.count then throw "发片两端的宽度顶点数量不一致。"

    local pivotPoint = polyNode.objectTransform.row4
    if distance (HCE_rowWorldCenter polyNode tipEnd) pivotPoint < distance (HCE_rowWorldCenter polyNode rootEnd) pivotPoint do
    (
        local swapEnd = rootEnd
        rootEnd = tipEnd
        tipEnd = swapEnd
    )

    -- Multi-source topological distance from the complete root cross-row
    -- groups every width column into its corresponding longitudinal row.
    local distances = for i = 1 to (polyop.getNumVerts polyNode) collect -1
    local queue = #()
    for v in rootEnd do
    (
        distances[v] = 0
        append queue v
    )
    local queueIndex = 1
    local maxDistance = 0
    while queueIndex <= queue.count do
    (
        local v = queue[queueIndex]
        queueIndex += 1
        for n in adjacency[v] where elementVerts[n] and distances[n] == -1 do
        (
            distances[n] = distances[v] + 1
            maxDistance = amax #(maxDistance, distances[n])
            append queue n
        )
    )

    for v in elementVerts where distances[v] < 0 do throw "发片网格存在断开的顶点。"
    for v in tipEnd where distances[v] != maxDistance do throw "发片内部走线不规则，无法对应首尾横向排。"

    local rowGroups = for d = 0 to maxDistance collect #()
    for v in elementVerts do append rowGroups[distances[v] + 1] v
    local columnCount = rootEnd.count
    for row in rowGroups where row.count != columnCount do
        throw "发片宽度方向的顶点列数不一致。"

    local rows = #()
    append rows (for v in rootEnd collect v)
    for r = 2 to rowGroups.count do
        append rows (HCE_orderCrossRow rowGroups[r] adjacency polyNode previousRow:rows[r-1])

    rows
)

fn HCE_findEdgeBetweenVerts polyNode vertA vertB =
(
    local vertBits = #{}
    vertBits[vertA] = true
    local edges = polyop.getEdgesUsingVert polyNode vertBits
    for e in edges do
    (
        local ev = polyop.getEdgeVerts polyNode e
        if (ev[1] == vertA and ev[2] == vertB) or (ev[1] == vertB and ev[2] == vertA) do return e
    )
    0
)

fn HCE_elementsTouchedByFaces polyNode selectedFaces =
(
    local remaining = copy selectedFaces
    local elements = #()
    while remaining.numberSet > 0 do
    (
        local seed = undefined
        for f in remaining while seed == undefined do seed = f
        local seedBits = #{}
        seedBits[seed] = true
        local wholeElement = polyop.getElementsUsingFace polyNode seedBits
        append elements wholeElement
        remaining = remaining - wholeElement
    )
    elements
)

fn HCE_facesBetweenRows polyNode elementFaces rowA rowB =
(
    local rowABits = #{}
    local rowBBits = #{}
    local bothRows = #{}
    for v in rowA do
    (
        rowABits[v] = true
        bothRows[v] = true
    )
    for v in rowB do
    (
        rowBBits[v] = true
        bothRows[v] = true
    )

    local result = #{}
    for f in elementFaces do
    (
        local faceVerts = polyop.getFaceVerts polyNode f
        local allInside = true
        local hasA = false
        local hasB = false
        for v in faceVerts do
        (
            if not bothRows[v] do allInside = false
            if rowABits[v] do hasA = true
            if rowBBits[v] do hasB = true
        )
        if allInside and hasA and hasB do result[f] = true
    )
    result
)

fn HCE_crossRowEdges polyNode rowVerts =
(
    local edges = #{}
    for i = 1 to (rowVerts.count - 1) do
    (
        local edgeID = HCE_findEdgeBetweenVerts polyNode rowVerts[i] rowVerts[i+1]
        if edgeID == 0 then throw "横向顶点之间缺少边，无法执行设置流。"
        edges[edgeID] = true
    )
    edges
)

fn HCE_buildSetFlowJobs polyNode selectedFaces =
(
    if selectedFaces.numberSet == 0 then throw "没有选中面。请在多边形或元素级别选择要顺线的区域。"
    local jobs = #()
    local touchedElements = HCE_elementsTouchedByFaces polyNode selectedFaces

    for elementFaces in touchedElements do
    (
        local boundary = HCE_getElementBoundaryLoop polyNode elementFaces
        local rows = HCE_findRibbonRows boundary polyNode elementFaces
        if rows.count < 3 then throw "所选发片纵向排数不足，无法排除首尾后执行设置流。"

        local intervalSelected = #()
        for r = 1 to (rows.count - 1) do
        (
            local intervalFaces = HCE_facesBetweenRows polyNode elementFaces rows[r] rows[r+1]
            if intervalFaces.numberSet == 0 then throw "无法识别发片相邻横线之间的面。"
            local selectedPart = intervalFaces * selectedFaces
            if selectedPart.numberSet > 0 and selectedPart.numberSet != intervalFaces.numberSet then
                throw "面选区必须横跨发片完整宽度；请补选同一排缺少的面。"
            append intervalSelected (selectedPart.numberSet == intervalFaces.numberSet)
        )

        local interval = 1
        while interval <= intervalSelected.count do
        (
            if intervalSelected[interval] then
            (
                local runStart = interval
                while interval <= intervalSelected.count and intervalSelected[interval] do interval += 1
                local runEnd = interval - 1
                -- Selected face intervals run from runStart to runEnd.
                -- Their endpoint cross-rows are runStart and runEnd+1, so only
                -- rows runStart+1 through runEnd are processed.
                for rowIndex = (runStart + 1) to runEnd do
                    append jobs (HCE_FlowJob source:polyNode edges:(HCE_crossRowEdges polyNode rows[rowIndex]))
            )
            else interval += 1
        )
    )
    jobs
)

fn HCE_buildInsertFlowPlan polyNode selectedFaces =
(
    if selectedFaces.numberSet == 0 then throw "没有选中面。请在多边形级别选择要平滑加线的区域。"
    local connectEdges = #{}
    local lineCount = 0
    local expectedSegments = 0
    local touchedElements = HCE_elementsTouchedByFaces polyNode selectedFaces

    for elementFaces in touchedElements do
    (
        local boundary = HCE_getElementBoundaryLoop polyNode elementFaces
        local rows = HCE_findRibbonRows boundary polyNode elementFaces
        for r = 1 to (rows.count - 1) do
        (
            local intervalFaces = HCE_facesBetweenRows polyNode elementFaces rows[r] rows[r+1]
            if intervalFaces.numberSet == 0 then throw "无法识别发片相邻横线之间的面。"
            local selectedPart = intervalFaces * selectedFaces
            if selectedPart.numberSet > 0 do
            (
                if selectedPart.numberSet != intervalFaces.numberSet then
                    throw "面选区必须横跨发片完整宽度；请补选同一排缺少的面。"
                for f in intervalFaces where (polyop.getFaceVerts polyNode f).count != 4 do
                    throw "平滑加线只支持规则四边形面；选区中不能包含三角面或多边面。"
                if rows[r].count != rows[r+1].count then
                    throw "发片相邻横排的顶点数不一致，无法在中间加线。"

                for column = 1 to rows[r].count do
                (
                    local edgeID = HCE_findEdgeBetweenVerts polyNode rows[r][column] rows[r+1][column]
                    if edgeID == 0 then throw "纵向顶点之间缺少边，无法连接新横线。"
                    connectEdges[edgeID] = true
                )
                lineCount += 1
                expectedSegments += rows[r].count - 1
            )
        )
    )
    HCE_InsertFlowPlan source:polyNode edges:connectEdges lineCount:lineCount expectedSegments:expectedSegments
)

fn HCE_restoreFlowSelection nodeSelection sourceStates oldSubObjectLevel =
(
    for state in sourceStates where isValidNode state.source do
    (
        polyop.setFaceSelection state.source state.faceSelection
        polyop.setEdgeSelection state.source state.edgeSelection
    )
    if nodeSelection.count > 0 do select nodeSelection
    if oldSubObjectLevel != undefined do subObjectLevel = oldSubObjectLevel
)

fn HCE_setFlowSelectedFaceRegions =
(
    if HCE_Active then throw "请先应用或取消当前样条控制，再单独运行一键顺线。"
    local sourceNodes = for n in selection where HCE_isEditablePolyNode n collect n
    if sourceNodes.count == 0 then throw "请选择 Editable Poly，并在多边形或元素级别选择面。"

    local originalNodeSelection = for n in selection collect n
    local oldSubObjectLevel = subObjectLevel
    local sourceStates = #()
    local jobs = #()
    for src in sourceNodes do
    (
        local faceSelection = polyop.getFaceSelection src
        append sourceStates (HCE_FlowSourceState source:src faceSelection:(copy faceSelection) edgeSelection:(copy (polyop.getEdgeSelection src)))
        join jobs (HCE_buildSetFlowJobs src faceSelection)
    )
    if jobs.count == 0 then throw "选区内部没有可处理的横线；首尾横线会被自动排除。"

    local completed = 0
    local failure = undefined
    undo "发片横线依次设置流" on
    (
        try
        (
            local currentSource = undefined
            for job in jobs do
            (
                if currentSource != job.source do
                (
                    if isValidNode currentSource do update currentSource
                    currentSource = job.source
                    select currentSource
                    max modify mode
                    subObjectLevel = 2
                )
                polyop.setEdgeSelection job.source job.edges
                if not (PolyToolsModeling.SetFlow false) then throw "3ds Max 设置流命令执行失败。"
                completed += 1
            )
            if isValidNode currentSource do update currentSource
        )
        catch
        (
            failure = getCurrentException()
        )
    )
    HCE_restoreFlowSelection originalNodeSelection sourceStates oldSubObjectLevel
    redrawViews()
    if failure != undefined then throw failure
    completed
)

fn HCE_insertSetFlowLoopsSelectedFaces =
(
    if HCE_Active then throw "请先应用或取消当前样条控制，再单独运行平滑加线。"
    local sourceNodes = for n in selection where HCE_isEditablePolyNode n collect n
    if sourceNodes.count == 0 then throw "请选择 Editable Poly，并在多边形级别选择要加线的面。"

    local originalNodeSelection = for n in selection collect n
    local oldSubObjectLevel = subObjectLevel
    local sourceStates = #()
    local plans = #()
    for src in sourceNodes do
    (
        local faceSelection = polyop.getFaceSelection src
        append sourceStates (HCE_FlowSourceState source:src faceSelection:(copy faceSelection) edgeSelection:(copy (polyop.getEdgeSelection src)))
        local plan = HCE_buildInsertFlowPlan src faceSelection
        if plan.lineCount > 0 do append plans plan
    )
    if plans.count == 0 then throw "选区中没有可平滑加线的完整四边形面排。"

    local totalLines = 0
    local totalSegments = 0
    local results = #()
    local failure = undefined
    local mutated = false
    try
    (
        undo "发片选中面平滑加线" on
        (
            for plan in plans do
            (
                local src = plan.source
                local ep = src.baseObject
                local oldVertCount = polyop.getNumVerts src
                local oldSegments = ep.connectEdgeSegments
                local oldPinch = ep.connectEdgePinch
                local oldSlide = ep.connectEdgeSlide

                select src
                max modify mode
                subObjectLevel = 2
                polyop.setEdgeSelection src plan.edges
                ep.connectEdgeSegments = 1
                ep.connectEdgePinch = 0
                ep.connectEdgeSlide = 0

                local connected = false
                try (connected = ep.EditablePoly.ConnectEdges edgeFlag:1) catch()
                ep.connectEdgeSegments = oldSegments
                ep.connectEdgePinch = oldPinch
                ep.connectEdgeSlide = oldSlide
                if not connected then throw "3ds Max 连接边失败；请确认选区是规则四边形发片。"
                mutated = true
                update src

                local newCrossEdges = #{}
                for edgeID = 1 to (polyop.getNumEdges src) do
                (
                    local ev = polyop.getEdgeVerts src edgeID
                    if ev[1] > oldVertCount and ev[2] > oldVertCount do newCrossEdges[edgeID] = true
                )
                if newCrossEdges.numberSet != plan.expectedSegments then
                    throw ("新增横线识别数量不符：预期 " + plan.expectedSegments as string + " 段，实际 " + newCrossEdges.numberSet as string + " 段。")

                polyop.setEdgeSelection src newCrossEdges
                if not (PolyToolsModeling.SetFlow false) then throw "新横线已生成，但 3ds Max 设置流执行失败。"
                update src
                append results #(src, copy newCrossEdges)
                totalLines += plan.lineCount
                totalSegments += newCrossEdges.numberSet
            )
        )
    )
    catch
    (
        failure = getCurrentException()
    )

    if failure != undefined then
    (
        if mutated do try (max undo) catch()
        HCE_restoreFlowSelection originalNodeSelection sourceStates oldSubObjectLevel
        redrawViews()
        throw failure
    )

    select sourceNodes
    for result in results where isValidNode result[1] do polyop.setEdgeSelection result[1] result[2]
    max modify mode
    subObjectLevel = 2
    redrawViews()
    #(totalLines, totalSegments)
)

fn HCE_polylineParams points =
(
    local cumulative = #(0.0)
    local params = #()
    local total = 0.0
    for i = 2 to points.count do
    (
        total += distance points[i-1] points[i]
        append cumulative total
    )
    if total < 0.000001 then throw "发片中心线长度为零。"
    for d in cumulative do append params (d / total)
    params
)

fn HCE_pointOnPolyline points params u =
(
    if u <= 0.0 then return points[1]
    if u >= 1.0 then return points[points.count]
    for i = 2 to params.count do
    (
        if u <= params[i] do
        (
            local span = params[i] - params[i-1]
            local t = if span < 0.000001 then 0.0 else ((u - params[i-1]) / span)
            return (points[i-1] + (points[i] - points[i-1]) * t)
        )
    )
    points[points.count]
)

fn HCE_createControlShape sourceName =
(
    local curveNode = splineShape name:(uniqueName (sourceName + "_TEMP_MULTI_CTRL"))
    curveNode.transform = matrix3 1
    curveNode.wirecolor = color 255 150 0
    curveNode.renderable = false
    curveNode.vertexTicks = true
    curveNode.steps = 6
    curveNode.optimize = true
    curveNode
)

fn HCE_addControlSpline curveNode centers rowParams requestedKnots =
(
    local knotCount = amin #(requestedKnots, centers.count)
    knotCount = amax #(knotCount, 2)
    local splineIndex = addNewSpline curveNode
    for k = 1 to knotCount do
    (
        local u = (k - 1.0) / (knotCount - 1.0)
        addKnot curveNode splineIndex #smooth #curve (HCE_pointOnPolyline centers rowParams u)
    )
    updateShape curveNode
    splineIndex
)

fn HCE_createGuideShape sourceName =
(
    local curveNode = splineShape name:(uniqueName (sourceName + "_CARD_GUIDE"))
    curveNode.transform = matrix3 1
    curveNode.wirecolor = color 80 255 170
    curveNode.renderable = false
    curveNode.vertexTicks = true
    curveNode.steps = 6
    curveNode.optimize = true
    curveNode
)

fn HCE_addGuideSpline curveNode centers rowParams requestedKnots =
(
    -- This independent export honors the requested count exactly. Even when a
    -- low-poly card has fewer rows, extra knots are sampled along its center
    -- polyline so the guide is immediately useful for spline-to-card work.
    local knotCount = amax #(2, requestedKnots)
    local splineIndex = addNewSpline curveNode
    for k = 1 to knotCount do
    (
        local u = (k - 1.0) / (knotCount - 1.0)
        addKnot curveNode splineIndex #smooth #curve (HCE_pointOnPolyline centers rowParams u)
    )
    splineIndex
)

fn HCE_generateGuideSplines requestedKnots =
(
    local sources = for node in selection where HCE_isEditablePolyNode node collect node
    if sources.count == 0 then throw "请选中 Editable Poly，并在元素级别选择一个或多个完整发片。"
    local oldSelection = selection as array
    local oldSubObjectLevel = subObjectLevel
    local guideNodes = #()
    local guideCount = 0
    try
    (
        for source in sources do
        (
            local components = HCE_selectedElementComponents source
            for elementFaces in components do
            (
                local boundary = HCE_getElementBoundaryLoop source elementFaces
                local rows = HCE_findRibbonRows boundary source elementFaces
                local centers = for row in rows collect (HCE_rowWorldCenter source row)
                local rowParams = HCE_polylineParams centers
                local guideNode = HCE_createGuideShape source.name
                append guideNodes guideNode
                HCE_addGuideSpline guideNode centers rowParams requestedKnots
                updateShape guideNode
                guideCount += 1
            )
        )
        if guideCount == 0 then throw "没有找到可生成样条的完整发片元素。"
        -- Keep every card as an independently selectable Shape node. Finish
        -- at object level instead of exposing/selecting spline control points.
        try (subObjectLevel = 0) catch()
        select guideNodes
    )
    catch
    (
        for guideNode in guideNodes where isValidNode guideNode do delete guideNode
        if oldSelection.count > 0 do select oldSelection
        try (subObjectLevel = oldSubObjectLevel) catch()
        throw()
    )
    #(guideNodes,guideCount)
)

fn HCE_sampleFrames curveNode splineIndex params seedWidth =
(
    local points = #()
    local tangents = #()
    local widths = #()
    local bins = #()
    resetLengthInterp()
    for u in params do
    (
        local p
        local pBefore
        local pAfter
        -- At the two ends use a full control-knot interval. Very short samples
        -- can follow a collapsed/sideways auto Bezier handle and incorrectly
        -- mix ribbon width into the longitudinal coordinate.
        local endpointStep = 1.0 / (amax #(1, (numKnots curveNode splineIndex)-1))
        local sampleStep = if u < 0.000001 or u > 0.999999 then endpointStep else 0.001
        local uBefore = amax #(0.0, u-sampleStep)
        local uAfter = amin #(1.0, u+sampleStep)
        in coordsys world
        (
            p = lengthInterp curveNode splineIndex u
            pBefore = lengthInterp curveNode splineIndex uBefore
            pAfter = lengthInterp curveNode splineIndex uAfter
        )
        local t = pAfter-pBefore
        if (length t) < 0.000001 do
        (
            in coordsys world t = lengthTangent curveNode splineIndex u
        )
        append points p
        append tangents (HCE_safeNormalize t fallback:(if tangents.count > 0 then tangents[tangents.count] else [0,1,0]))
    )

    local prevWidth = seedWidth
    for i = 1 to points.count do
    (
        local t = tangents[i]
        local w = prevWidth - t * (dot prevWidth t)
        if (length w) < 0.000001 do
        (
            local fallbackAxis = if (abs (dot t [0,0,1])) < 0.95 then [0,0,1] else [1,0,0]
            w = cross fallbackAxis t
        )
        w = normalize w
        local b = HCE_safeNormalize (cross t w) fallback:[0,0,1]
        w = HCE_safeNormalize (cross b t) fallback:w
        if i > 1 and (dot w prevWidth) < 0.0 do
        (
            w = -w
            b = -b
        )
        append widths w
        append bins b
        prevWidth = w
    )
    #(points,tangents,widths,bins)
)

fn HCE_buildItem polyNode elementFaces knotCount controlNode =
(
    try
    (
        local boundary = HCE_getElementBoundaryLoop polyNode elementFaces
        local rows = HCE_findRibbonRows boundary polyNode elementFaces
        local centers = #()
        for row in rows do
            append centers (HCE_rowWorldCenter polyNode row)
        local rowParams = HCE_polylineParams centers
        local splineIndex = HCE_addControlSpline controlNode centers rowParams knotCount
        local seed = HCE_safeNormalize (HCE_getWorldVert polyNode rows[1][rows[1].count] - HCE_getWorldVert polyNode rows[1][1]) fallback:[1,0,0]
        local restFrames = HCE_sampleFrames controlNode splineIndex rowParams seed
        local vertIDs = #()
        local params = #()
        local coords = #()
        local originals = #()
        local knotAngles = for k = 1 to (numKnots controlNode splineIndex) collect 0.0
        local knotWidthScales = for k = 1 to (numKnots controlNode splineIndex) collect 1.0

        for r = 1 to rows.count do
        (
            local p = restFrames[1][r]
            local t = restFrames[2][r]
            local w = restFrames[3][r]
            local b = restFrames[4][r]
            for v in rows[r] do
            (
                local original = HCE_getWorldVert polyNode v
                local delta = original - p
                append vertIDs v
                append params rowParams[r]
                append coords [dot delta w, dot delta b, dot delta t]
                append originals original
            )
        )

        HCE_ItemData source:polyNode curve:controlNode splineIndex:splineIndex faces:(copy elementFaces) vertIDs:vertIDs \
            params:params localCoords:coords originalWorld:originals seedWidth:seed knotTwistAngles:knotAngles knotWidthScales:knotWidthScales
    )
    catch
    (
        throw()
    )
)

fn HCE_captureCurveState item =
(
    local state = #()
    if not isValidNode item.curve then return state
    in coordsys world
    (
        for k = 1 to (numKnots item.curve item.splineIndex) do
        (
            append state (getKnotPoint item.curve item.splineIndex k)
            append state (getInVec item.curve item.splineIndex k)
            append state (getOutVec item.curve item.splineIndex k)
        )
    )
    -- Knot selection is part of the deformation state in local twist mode.
    -- Encoding it as point3 values lets the existing state comparator detect
    -- selection changes without introducing a second callback system.
    local selectedKnots = getKnotSelection item.curve item.splineIndex
    for k = 1 to (numKnots item.curve item.splineIndex) do
        append state (if (findItem selectedKnots k) != 0 then [1,0,0] else [0,0,0])
    state
)

fn HCE_curveStateEqual a b =
(
    if a.count != b.count then return false
    for i = 1 to a.count where (distance a[i] b[i]) > 0.000001 do return false
    true
)

fn HCE_updateAll force:false requestRedraw:true =
(
    if not HCE_Active or HCE_IsUpdating then return false
    HCE_IsUpdating = true
    local ok = true
    try
    (
        local pendingStates = #()
        local curveChanged = force
        for item in HCE_Items do
        (
            if not isValidNode item.source then throw "原 Editable Poly 已被删除。"
            if not isValidNode item.curve then throw "临时控制样条已被删除。"
            local newState = HCE_captureCurveState item
            append pendingStates newState
            if not (HCE_curveStateEqual newState item.lastCurveState) do curveChanged = true
        )

        if curveChanged do
        (
            local sources = #()
            for item in HCE_Items do HCE_addUnique sources item.source

            -- Build every changed vertex position first, then submit one atomic
            -- polyop.setVert call per Editable Poly. This prevents the viewport
            -- from drawing half-updated ribbons while a spline knot is dragged.
            with redraw off
            (
                for src in sources do
                (
                    local positionsByVert = for v = 1 to (polyop.getNumVerts src) collect undefined
                    local changedVerts = #{}
                    for item in HCE_Items where item.source == src do
                    (
                        local frames = HCE_sampleFrames item.curve item.splineIndex item.params item.seedWidth
                        for i = 1 to item.vertIDs.count do
                        (
                            local c = item.localCoords[i]
                            local axes = HCE_rotatedRibbonAxes item frames[3][i] frames[4][i] item.params[i]
                            local widthScale = HCE_widthScaleAtParam item item.params[i]
                            local worldP = frames[1][i] + axes[1]*(c.x*widthScale) + axes[2]*c.y + frames[2][i]*c.z
                            local vertID = item.vertIDs[i]
                            positionsByVert[vertID] = worldP
                            changedVerts[vertID] = true
                        )
                    )

                    local worldPositions = #()
                    for vertID in changedVerts do append worldPositions positionsByVert[vertID]
                    in coordsys world polyop.setVert src changedVerts worldPositions
                    update src
                )
            )

            for i = 1 to HCE_Items.count do HCE_Items[i].lastCurveState = pendingStates[i]
            if requestRedraw do redrawViews()
        )
    )
    catch
    (
        ok = false
        format "Hair Card Element Spline update error: %\n" (getCurrentException())
    )
    HCE_IsUpdating = false
    ok
)

fn HCE_liveControlChanged =
(
    if HCE_Active and HCE_LiveEnabled and not HCE_IsUpdating do
        HCE_updateAll force:true requestRedraw:false
)

fn HCE_removeLiveHandlers =
(
    try (deleteAllChangeHandlers id:#HCE_LiveControl) catch()
    HCE_ChangeHandlers = #()
)

fn HCE_installLiveHandlers controlNode =
(
    HCE_removeLiveHandlers()
    if isValidNode controlNode do
    (
        append HCE_ChangeHandlers (when geometry controlNode changes id:#HCE_LiveControl handleAt:#redrawViews do HCE_liveControlChanged())
        append HCE_ChangeHandlers (when transform controlNode changes id:#HCE_LiveControl handleAt:#redrawViews do HCE_liveControlChanged())
    )
)

fn HCE_deleteControlShape =
(
    HCE_removeLiveHandlers()
    if isValidNode HCE_ControlShape do delete HCE_ControlShape
    HCE_ControlShape = undefined
)

fn HCE_selectEditedElements =
(
    local sources = #()
    for item in HCE_Items where isValidNode item.source do HCE_addUnique sources item.source
    if sources.count > 0 do
    (
        select sources
        for src in sources do
        (
            local faces = #{}
            for item in HCE_Items where item.source == src do faces += item.faces
            polyop.setFaceSelection src faces
        )
        max modify mode
        subObjectLevel = 5
    )
)

fn HCE_cancelSession =
(
    if HCE_Active do
    (
        HCE_removeLiveHandlers()
        local sources = #()
        for item in HCE_Items where isValidNode item.source do HCE_addUnique sources item.source
        with redraw off
        (
            for src in sources do
            (
                local positionsByVert = for v = 1 to (polyop.getNumVerts src) collect undefined
                local restoreVerts = #{}
                for item in HCE_Items where item.source == src do
                (
                    for i = 1 to item.vertIDs.count do
                    (
                        local vertID = item.vertIDs[i]
                        positionsByVert[vertID] = item.originalWorld[i]
                        restoreVerts[vertID] = true
                    )
                )
                local restorePositions = #()
                for vertID in restoreVerts do append restorePositions positionsByVert[vertID]
                in coordsys world polyop.setVert src restoreVerts restorePositions
                update src
            )
        )
        HCE_deleteControlShape()
        HCE_selectEditedElements()
    )
    HCE_Items = #()
    HCE_Active = false
    HCE_IsUpdating = false
    redrawViews()
    true
)

fn HCE_applySession =
(
    if not HCE_Active then return 0
    HCE_updateAll force:true
    local count = HCE_Items.count
    HCE_selectEditedElements()
    HCE_deleteControlShape()
    HCE_Items = #()
    HCE_Active = false
    HCE_IsUpdating = false
    redrawViews()
    count
)

rollout HCE_GuideRollout "发片中心样条提取  v4.6.1 实验" width:350 height:178
(
    groupBox gbGuide "只生成普通样条" pos:[10,8] width:330 height:122
    label lbGuideHelp "每个选中发片元素生成一根样条，不控制也不修改原面片。" pos:[22,29] width:306 height:18
    label lbGuideKnots "每根控制点数：" pos:[22,57] width:102 height:18
    spinner spnGuideKnots "" pos:[126,54] width:116 height:18 range:[2,30,6] type:#integer
    button btnCreateGuides "从选中发片生成匹配样条" pos:[22,82] width:306 height:34
    label lbGuideStatus "状态：请选择完整发片元素。" pos:[12,139] width:326 height:32

    on btnCreateGuides pressed do
    (
        try
        (
            local result = HCE_generateGuideSplines spnGuideKnots.value
            lbGuideStatus.text = "状态：已生成 " + result[2] as string + " 根普通样条；原面片未改变。"
        )
        catch
        (
            messageBox ("无法提取中心样条：\n\n" + getCurrentException()) title:"发片中心样条提取"
            lbGuideStatus.text = "状态：生成失败，原面片未改变。"
        )
    )
)

rollout HCE_Rollout "面片转样条控制  v4.6.1 实验" width:370 height:900
(
    local twistUISyncing = false
    local widthUISyncing = false
    groupBox gbCreate "生成临时控制器" pos:[10,8] width:350 height:90
    label lbKnots "每根控制点数：" pos:[22,32] width:102 height:18
    spinner spnKnots "" pos:[126,29] width:116 height:18 range:[2,30,6] type:#integer
    button btnGenerate "控制选中的发片元素" pos:[22,56] width:326 height:30

    groupBox gbEdit "编辑 / 预览" pos:[10,106] width:350 height:120
    checkbox chkRealtime "实时更新原发片" pos:[22,129] width:155 height:20 checked:true
    button btnUpdate "立即刷新" pos:[190,125] width:158 height:28
    button btnSelectCurves "选择全部临时样条" pos:[22,162] width:158 height:30
    button btnSelectElements "返回选中发片元素" pos:[190,162] width:158 height:30
    label lbHint "可框选多根样条控制点，同时调整多片发片。" pos:[22,200] width:326 height:18

    groupBox gbTwist "面片旋转校正" pos:[10,234] width:350 height:170
    radiobuttons rbTwistMode labels:#("尾部渐变", "整条统一", "选中点局部") pos:[22,258] columns:3 default:1 enabled:false
    label lbTwistAngle "旋转角度：" pos:[22,289] width:80 height:18
    spinner spnTwistAngle "" pos:[104,286] width:123 height:18 range:[-180.0,180.0,0.0] type:#float scale:1.0 enabled:false
    checkbutton btnTwistReverse "首尾反向" pos:[238,282] width:110 height:26 checked:false enabled:false
    label lbKnotRangeValue "点影响范围：" pos:[22,319] width:80 height:18
    spinner spnKnotRange "" pos:[104,316] width:123 height:18 range:[0.25,3.0,1.0] type:#float scale:0.25 enabled:false
    label lbKnotRange "相邻间距倍率" pos:[238,319] width:110 height:18
    button btnTwistReset "旋转归零" pos:[22,346] width:110 height:28 enabled:false
    label lbTwistHint "尾部、整条和局部点会叠加生效。" pos:[142,346] width:206 height:42

    groupBox gbCardWidth "面片宽度调节" pos:[10,412] width:350 height:170
    radiobuttons rbWidthMode labels:#("尾部渐变", "整条倍率", "选中点局部") pos:[22,436] columns:3 default:1 enabled:false
    label lbWidthScale "宽度倍率：" pos:[22,467] width:80 height:18
    spinner spnWidthScale "" pos:[104,464] width:123 height:18 range:[0.01,10.0,1.0] type:#float scale:0.05 enabled:false
    checkbutton btnWidthReverse "首尾反向" pos:[238,460] width:110 height:26 checked:false enabled:false
    label lbWidthKnotRangeValue "点影响范围：" pos:[22,497] width:80 height:18
    spinner spnWidthKnotRange "" pos:[104,494] width:123 height:18 range:[0.25,3.0,1.0] type:#float scale:0.25 enabled:false
    label lbWidthRange "相邻间距倍率" pos:[238,497] width:110 height:18
    button btnWidthReset "宽度归一" pos:[22,524] width:110 height:28 enabled:false
    label lbWidthHint "尾部、整条和局部点会叠加生效。" pos:[142,524] width:206 height:42

    groupBox gbFinish "完成" pos:[10,590] width:350 height:82
    button btnApply "应用到原物体" pos:[22,616] width:158 height:38 enabled:false
    button btnCancel "取消并恢复" pos:[190,616] width:158 height:38 enabled:false

    checkbutton btnFoldWorkflow "[+] 使用说明" pos:[10,680] width:350 height:24 checked:false
    groupBox gbWorkflow "正确使用方式" pos:[10,708] width:350 height:104 visible:false
    label lb1 "1. 物体必须是 Editable Poly" pos:[23,729] width:326 height:18 visible:false
    label lb2 "2. 进入元素级别，只选择要调整的发片" pos:[23,749] width:326 height:18 visible:false
    label lb3 "3. 生成临时样条并移动样条控制点" pos:[23,769] width:326 height:18 visible:false
    label lb4 "4. 应用后写回原物体，其他发片不会改变" pos:[23,789] width:326 height:18 visible:false

    checkbutton btnFoldTools "[+] 独立工具：提取样条 / 顺线 / 加线" pos:[10,708] width:350 height:24 checked:false
    groupBox gbSetFlow "独立工具：提取样条 / 顺线 / 加线" pos:[10,736] width:350 height:228 visible:false
    label lbGuideExtractHint "从每个完整发片元素提取一根普通中心样条。" pos:[22,757] width:326 height:18 visible:false
    button btnOpenGuideExtractor "只生成匹配样条（不控制原面片）" pos:[22,783] width:326 height:34 visible:false
    label lbSetFlowHint "高速逐排处理，自动排除选区首尾横线。" pos:[22,825] width:326 height:18 visible:false
    button btnSetFlow "一键顺线（高速依次设置流）" pos:[22,851] width:326 height:34 visible:false
    label lbInsertFlowHint "在完整选区中间增加横线，并自动设置流。" pos:[22,893] width:326 height:18 visible:false
    button btnInsertFlow "平滑加线（中间连接并设置流）" pos:[22,919] width:326 height:34 visible:false

    label lbStatus "状态：请在元素级别选择发片。" pos:[12,744] width:346 height:40
    timer liveTimer interval:100 active:false

    fn setControlsVisible controls state =
    (
        for control in controls do try (control.visible = state) catch()
    )

    fn layoutCompactUI =
    (
        -- Max 2020 会在运行时移动 spinner 后压缩其输入框。
        -- 所有主编辑区保持静态，只移动底部不含 spinner 的折叠区。
        local y = 680
        local showWorkflow = btnFoldWorkflow.checked
        btnFoldWorkflow.pos = [10,y]
        btnFoldWorkflow.text = if showWorkflow then "[-] 使用说明" else "[+] 使用说明"
        setControlsVisible #(gbWorkflow,lb1,lb2,lb3,lb4) showWorkflow
        if showWorkflow then
        (
            gbWorkflow.pos = [10,y+28]
            lb1.pos = [23,y+49]; lb2.pos = [23,y+69]; lb3.pos = [23,y+89]; lb4.pos = [23,y+109]
            y += 140
        )
        else y += 28

        local showTools = btnFoldTools.checked
        btnFoldTools.pos = [10,y]
        btnFoldTools.text = if showTools then "[-] 独立工具：提取样条 / 顺线 / 加线" else "[+] 独立工具：提取样条 / 顺线 / 加线"
        setControlsVisible #(gbSetFlow,lbGuideExtractHint,btnOpenGuideExtractor,lbSetFlowHint,btnSetFlow,lbInsertFlowHint,btnInsertFlow) showTools
        if showTools then
        (
            gbSetFlow.pos = [10,y+28]
            lbGuideExtractHint.pos = [22,y+49]; btnOpenGuideExtractor.pos = [22,y+75]
            lbSetFlowHint.pos = [22,y+117]; btnSetFlow.pos = [22,y+143]
            lbInsertFlowHint.pos = [22,y+185]; btnInsertFlow.pos = [22,y+211]
            y += 268
        )
        else y += 28

        lbStatus.pos = [12,y+4]
        try
        (
            local currentSize = getDialogSize HCE_Rollout
            setDialogSize HCE_Rollout [currentSize.x,amax #(260,y+52)]
        )
        catch()
    )

    fn setSessionUI activeState =
    (
        btnGenerate.enabled = not activeState
        spnKnots.enabled = not activeState
        btnApply.enabled = activeState
        btnCancel.enabled = activeState
        rbTwistMode.enabled = activeState
        spnTwistAngle.enabled = activeState
        btnTwistReverse.enabled = activeState and (rbTwistMode.state == 1)
        spnKnotRange.enabled = activeState and (rbTwistMode.state == 3)
        btnTwistReset.enabled = activeState
        rbWidthMode.enabled = activeState
        spnWidthScale.enabled = activeState
        btnWidthReverse.enabled = activeState and (rbWidthMode.state == 1)
        spnWidthKnotRange.enabled = activeState and (rbWidthMode.state == 3)
        btnWidthReset.enabled = activeState
        btnSetFlow.enabled = not activeState
        btnInsertFlow.enabled = not activeState
        btnOpenGuideExtractor.enabled = not activeState
        liveTimer.active = activeState
    )

    fn syncLocalKnotAngleUI =
    (
        if HCE_Active and rbTwistMode.state == 3 then
        (
            local info = HCE_selectedKnotAngleInfo()
            local count = info[1]
            spnTwistAngle.enabled = count > 0
            btnTwistReset.enabled = count > 0
            btnTwistReset.text = "选中点归零"
            if count == 0 then
                lbTwistHint.text = "请选择一个或多个样条控制点。"
            else if info[3] then
                lbTwistHint.text = "已选 " + count as string + " 点，数值不同；输入后统一赋值。"
            else
            (
                if (abs (spnTwistAngle.value - info[2])) > 0.0001 do
                (
                    twistUISyncing = true
                    spnTwistAngle.value = info[2]
                    twistUISyncing = false
                )
                lbTwistHint.text = "已选 " + count as string + " 点；角度 " + (formattedPrint info[2] format:".1f") + "°。"
            )
        )
        else
        (
            if HCE_Active do
            (
                spnTwistAngle.enabled = true
                if (abs (spnTwistAngle.value - HCE_TwistAngle)) > 0.0001 do
                (
                    twistUISyncing = true
                    spnTwistAngle.value = HCE_TwistAngle
                    twistUISyncing = false
                )
            )
            btnTwistReset.enabled = HCE_Active
            btnTwistReset.text = "旋转归零"
            lbTwistHint.text = "尾部、整条和局部点会叠加生效。"
        )
    )

    fn syncLocalKnotWidthUI =
    (
        if HCE_Active and rbWidthMode.state == 3 then
        (
            local info = HCE_selectedKnotWidthInfo()
            local count = info[1]
            spnWidthScale.enabled = count > 0
            btnWidthReset.enabled = count > 0
            btnWidthReset.text = "选中点归一"
            if count == 0 then
                lbWidthHint.text = "请选择一个或多个样条控制点。"
            else if info[3] then
                lbWidthHint.text = "已选 " + count as string + " 点，倍率不同；输入后统一赋值。"
            else
            (
                if (abs (spnWidthScale.value-info[2])) > 0.0001 do
                (
                    widthUISyncing = true
                    spnWidthScale.value = info[2]
                    widthUISyncing = false
                )
                lbWidthHint.text = "已选 " + count as string + " 点；倍率 " + (formattedPrint info[2] format:".2f") + "。"
            )
        )
        else
        (
            if HCE_Active do
            (
                spnWidthScale.enabled = true
                if (abs (spnWidthScale.value-HCE_WidthScale)) > 0.0001 do
                (
                    widthUISyncing = true
                    spnWidthScale.value = HCE_WidthScale
                    widthUISyncing = false
                )
            )
            btnWidthReset.enabled = HCE_Active
            btnWidthReset.text = "宽度归一"
            lbWidthHint.text = "尾部、整条和局部点会叠加生效。"
        )
    )

    on btnGenerate pressed do
    (
        local sources = for n in selection where HCE_isEditablePolyNode n collect n
        if sources.count == 0 then
        (
            messageBox "请选中 Editable Poly 物体，并在元素级别选择要调整的发片。" title:"选中发片样条控制器"
        )
        else
        (
            spnTwistAngle.value = 0.0
            rbTwistMode.state = 1
            btnTwistReverse.checked = false
            spnWidthScale.value = 1.0
            rbWidthMode.state = 1
            btnWidthReverse.checked = false
            HCE_TwistAngle = 0.0
            HCE_TwistMode = #tail
            HCE_TwistReverse = false
            HCE_TwistKnotRadius = spnKnotRange.value
            HCE_TwistProfileMode = #tail
            HCE_TailTwistAngle = 0.0
            HCE_WholeTwistAngle = 0.0
            HCE_WidthScale = 1.0
            HCE_WidthMode = #tail
            HCE_WidthReverse = false
            HCE_WidthKnotRadius = spnWidthKnotRange.value
            HCE_WidthProfileMode = #tail
            HCE_TailWidthScale = 1.0
            HCE_WholeWidthScale = 1.0
            HCE_Items = #()
            HCE_ControlShape = HCE_createControlShape sources[1].name
            local errorMessage = undefined
            try
            (
                for src in sources do
                (
                    local components = HCE_selectedElementComponents src
                    for faces in components do
                    (
                        append HCE_Items (HCE_buildItem src faces spnKnots.value HCE_ControlShape)
                    )
                )
            )
            catch
            (
                errorMessage = getCurrentException()
            )

            if errorMessage != undefined then
            (
                HCE_deleteControlShape()
                HCE_Items = #()
                messageBox ("无法生成：\n\n" + errorMessage) title:"发片拓扑不符合要求"
            )
            else if HCE_Items.count > 0 do
            (
                HCE_Active = true
                HCE_LiveEnabled = chkRealtime.checked
                HCE_installLiveHandlers HCE_ControlShape
                setSessionUI true
                select HCE_ControlShape
                max modify mode
                subObjectLevel = 1
                lbStatus.text = "状态：正在控制 " + HCE_Items.count as string + " 个选中发片元素。"
            )
        )
    )

    on liveTimer tick do
    (
        if HCE_Active and chkRealtime.checked do HCE_updateAll()
        if HCE_Active do
        (
            syncLocalKnotAngleUI()
            syncLocalKnotWidthUI()
        )
    )

    on chkRealtime changed state do
    (
        HCE_LiveEnabled = state
        liveTimer.active = HCE_Active
        if state and HCE_Active do HCE_updateAll force:true
    )

    fn updateTwistFromUI statusText writeLocalAngle:false writeGlobalAngle:false =
    (
        local editMode = case rbTwistMode.state of
        (
            1: #tail
            2: #whole
            3: #knots
        )
        HCE_setTwistEditMode editMode
        HCE_TwistReverse = btnTwistReverse.checked
        HCE_TwistKnotRadius = spnKnotRange.value
        if HCE_TwistMode == #knots then
        (
            if writeLocalAngle and not twistUISyncing do HCE_setSelectedKnotAngles spnTwistAngle.value
        )
        else if writeGlobalAngle and not twistUISyncing do HCE_setCurrentTwistProfileAngle spnTwistAngle.value
        btnTwistReverse.enabled = HCE_Active and (rbTwistMode.state == 1)
        spnKnotRange.enabled = HCE_Active and (rbTwistMode.state == 3)
        if HCE_Active do
        (
            if HCE_updateAll force:true then lbStatus.text = statusText
            else lbStatus.text = "状态：旋转更新失败，请点击立即刷新。"
        )
        syncLocalKnotAngleUI()
    )

    on spnTwistAngle changed value do
        if not twistUISyncing do updateTwistFromUI "状态：旋转角度已更新。" writeLocalAngle:true writeGlobalAngle:true

    on rbTwistMode changed state do updateTwistFromUI "状态：面片旋转模式已切换。" writeLocalAngle:false

    on spnKnotRange changed value do updateTwistFromUI "状态：局部旋转影响范围已更新。" writeLocalAngle:false

    on btnTwistReverse changed state do updateTwistFromUI (if state then "状态：首尾方向已反向。" else "状态：已恢复原首尾方向。") writeLocalAngle:false

    on btnTwistReset pressed do
    (
        twistUISyncing = true
        spnTwistAngle.value = 0.0
        twistUISyncing = false
        if rbTwistMode.state == 3 then
        (
            HCE_setSelectedKnotAngles 0.0
            updateTwistFromUI "状态：选中控制点的独立旋转已归零。" writeLocalAngle:false
        )
        else
        (
            HCE_setCurrentTwistProfileAngle 0.0
            updateTwistFromUI "状态：面片旋转已归零。" writeLocalAngle:false
        )
    )

    fn updateWidthFromUI statusText writeLocalScale:false writeGlobalScale:false =
    (
        local editMode = case rbWidthMode.state of
        (
            1: #tail
            2: #whole
            3: #knots
        )
        HCE_setWidthEditMode editMode
        HCE_WidthReverse = btnWidthReverse.checked
        HCE_WidthKnotRadius = spnWidthKnotRange.value
        if HCE_WidthMode == #knots then
        (
            if writeLocalScale and not widthUISyncing do HCE_setSelectedKnotWidthScales spnWidthScale.value
        )
        else if writeGlobalScale and not widthUISyncing do HCE_setCurrentWidthProfileScale spnWidthScale.value
        btnWidthReverse.enabled = HCE_Active and (rbWidthMode.state == 1)
        spnWidthKnotRange.enabled = HCE_Active and (rbWidthMode.state == 3)
        if HCE_Active do
        (
            if HCE_updateAll force:true then lbStatus.text = statusText
            else lbStatus.text = "状态：宽度更新失败，请点击立即刷新。"
        )
        syncLocalKnotWidthUI()
    )

    on spnWidthScale changed value do
        if not widthUISyncing do updateWidthFromUI "状态：面片宽度已更新。" writeLocalScale:true writeGlobalScale:true

    on rbWidthMode changed state do updateWidthFromUI "状态：面片宽度模式已切换。" writeLocalScale:false

    on spnWidthKnotRange changed value do updateWidthFromUI "状态：局部宽度影响范围已更新。" writeLocalScale:false

    on btnWidthReverse changed state do updateWidthFromUI (if state then "状态：宽度首尾方向已反向。" else "状态：宽度已恢复原首尾方向。") writeLocalScale:false

    on btnWidthReset pressed do
    (
        widthUISyncing = true
        spnWidthScale.value = 1.0
        widthUISyncing = false
        if rbWidthMode.state == 3 then
        (
            HCE_setSelectedKnotWidthScales 1.0
            updateWidthFromUI "状态：选中控制点的独立宽度已归一。" writeLocalScale:false
        )
        else
        (
            HCE_setCurrentWidthProfileScale 1.0
            updateWidthFromUI "状态：面片宽度已恢复原始宽度。" writeLocalScale:false
        )
    )

    on btnSetFlow pressed do
    (
        try
        (
            local flowCount = HCE_setFlowSelectedFaceRegions()
            lbStatus.text = "状态：顺线完成，已依次设置流 " + flowCount as string + " 排横线。"
        )
        catch
        (
            local message = getCurrentException()
            messageBox ("无法顺线：\n\n" + message) title:"横线依次设置流"
            lbStatus.text = "状态：一键顺线未执行。"
        )
    )

    on btnOpenGuideExtractor pressed do
    (
        try (destroyDialog HCE_GuideRollout) catch()
        createDialog HCE_GuideRollout style:#(#style_titlebar, #style_sysmenu, #style_toolwindow)
    )

    on btnInsertFlow pressed do
    (
        try
        (
            local result = HCE_insertSetFlowLoopsSelectedFaces()
            lbStatus.text = "状态：平滑加线完成，新增 " + result[1] as string + " 排横线（" + result[2] as string + " 段边），已设置流。"
        )
        catch
        (
            local message = getCurrentException()
            messageBox ("无法平滑加线：\n\n" + message) title:"选中面平滑加线"
            lbStatus.text = "状态：平滑加线未执行。"
        )
    )

    on btnUpdate pressed do
    (
        if HCE_Active do
            if (HCE_updateAll force:true) then lbStatus.text = "状态：原发片已刷新。" else lbStatus.text = "状态：刷新失败，请勿删除临时样条。"
    )

    on btnSelectCurves pressed do
    (
        if HCE_Active do
        (
            if isValidNode HCE_ControlShape do
            (
                select HCE_ControlShape
                max modify mode
                subObjectLevel = 1
            )
        )
    )

    on btnSelectElements pressed do if HCE_Active do HCE_selectEditedElements()

    on btnApply pressed do
    (
        if HCE_Active do
        (
            liveTimer.active = false
            local count = HCE_applySession()
            setSessionUI false
            lbStatus.text = "状态：已应用 " + count as string + " 个发片元素；临时样条已删除。"
        )
    )

    on btnCancel pressed do
    (
        if HCE_Active do
        (
            liveTimer.active = false
            HCE_cancelSession()
            setSessionUI false
            lbStatus.text = "状态：已取消，选中发片已恢复原状。"
        )
    )

    on btnFoldWorkflow changed state do layoutCompactUI()
    on btnFoldTools changed state do layoutCompactUI()

    on HCE_Rollout open do
    (
        setSessionUI HCE_Active
        layoutCompactUI()
    )

    on HCE_Rollout close do
    (
        liveTimer.active = false
        try (destroyDialog HCE_GuideRollout) catch()
        if HCE_Active do HCE_cancelSession()
    )
)

global HCS_Items = #()
global HCS_Active = false
global HCS_IsUpdating = false
global HCS_LiveDirty = false
global HCS_LengthSegments = 8
global HCS_WidthSegments = 1
global HCS_CardWidth = 10.0
global HCS_CenterBulge = 0.0
global HCS_PreventFolding = true
global HCS_TwistAngle = 0.0
global HCS_TwistMode = #tail
global HCS_TwistReverse = false
global HCS_TwistKnotRadius = 1.0
global HCS_TwistProfileMode = #tail
global HCS_TailTwistAngle = 0.0
global HCS_WholeTwistAngle = 0.0
global HCS_WidthScale = 1.0
global HCS_WidthMode = #tail
global HCS_WidthReverse = false
global HCS_WidthKnotRadius = 1.0
global HCS_WidthProfileMode = #tail
global HCS_TailWidthScale = 1.0
global HCS_WholeWidthScale = 1.0
global HCS_LiveEnabled = true
global HCS_GeneratorMode = #ribbon
global HCS_TemplateNode = undefined
global HCS_TemplateAxis = #z
global HCS_TemplateCapEnds = true
global HCS_TemplateName = ""
global HCS_TemplateBaseWidth = 1.0
global HCS_TemplateProfilePoints = #()
global HCS_TemplateSpans = #()
global HCS_TemplateMaterial = undefined
global HCS_TemplateDialogOpen = false
global HCS_ProfileVersion = 2
global HCS_ProfileKeyPrefix = "HCS_LiveCard_Profile_"
global HCS_MeshLinkKey = "HCS_LiveCard_LinkID"
-- Restore is defined before the live-update helpers below. Predeclare them so a
-- fresh script load does not capture undefined forward references.
global HCS_removeHandlers
global HCS_updateAll
global HCS_setMeshesFrozen
global HCS_installHandlers
global HCS_TemplateRollout

struct HCS_CardItem
(
    curve,
    splineIndex = 1,
    meshNode,
    profileID = "",
    seedWidth = [1,0,0],
    lengthSegments = 8,
    widthSegments = 1,
    cardWidth = 10.0,
    centerBulge = 0.0,
    preventFolding = true,
    twistAngle = 0.0,
    twistMode = #tail,
    twistReverse = false,
    twistKnotRadius = 1.0,
    twistProfileMode = #tail,
    tailTwistAngle = 0.0,
    wholeTwistAngle = 0.0,
    widthScale = 1.0,
    widthMode = #tail,
    widthReverse = false,
    widthKnotRadius = 1.0,
    widthProfileMode = #tail,
    tailWidthScale = 1.0,
    wholeWidthScale = 1.0,
    generatorMode = #ribbon,
    templateAxis = #z,
    templateCapEnds = true,
    templateName = "",
    templateBaseWidth = 1.0,
    templateProfilePoints = #(),
    templateSpans = #(),
    templateMaterial,
    params = #(),
    widthCoords = #(),
    knotTwistAngles = #(),
    knotWidthScales = #(),
    lastCurveState = #()
)

fn HCS_loadItemSettings item =
(
    HCS_LengthSegments = item.lengthSegments
    HCS_WidthSegments = item.widthSegments
    HCS_CardWidth = item.cardWidth
    HCS_CenterBulge = item.centerBulge
    HCS_PreventFolding = item.preventFolding
    HCS_TwistAngle = item.twistAngle
    HCS_TwistMode = item.twistMode
    HCS_TwistReverse = item.twistReverse
    HCS_TwistKnotRadius = item.twistKnotRadius
    HCS_TwistProfileMode = item.twistProfileMode
    HCS_TailTwistAngle = item.tailTwistAngle
    HCS_WholeTwistAngle = item.wholeTwistAngle
    HCS_WidthScale = item.widthScale
    HCS_WidthMode = item.widthMode
    HCS_WidthReverse = item.widthReverse
    HCS_WidthKnotRadius = item.widthKnotRadius
    HCS_WidthProfileMode = item.widthProfileMode
    HCS_TailWidthScale = item.tailWidthScale
    HCS_WholeWidthScale = item.wholeWidthScale
    HCS_GeneratorMode = item.generatorMode
    HCS_TemplateAxis = item.templateAxis
    HCS_TemplateCapEnds = item.templateCapEnds
    HCS_TemplateName = item.templateName
    HCS_TemplateBaseWidth = item.templateBaseWidth
    HCS_TemplateProfilePoints = for value in item.templateProfilePoints collect value
    HCS_TemplateSpans = for span in item.templateSpans collect (for value in span collect value)
    HCS_TemplateMaterial = item.templateMaterial
    item
)

fn HCS_saveSettingsToItem item =
(
    item.lengthSegments = HCS_LengthSegments
    item.widthSegments = HCS_WidthSegments
    item.cardWidth = HCS_CardWidth
    item.centerBulge = HCS_CenterBulge
    item.preventFolding = HCS_PreventFolding
    item.twistAngle = HCS_TwistAngle
    item.twistMode = HCS_TwistMode
    item.twistReverse = HCS_TwistReverse
    item.twistKnotRadius = HCS_TwistKnotRadius
    item.twistProfileMode = HCS_TwistProfileMode
    item.tailTwistAngle = HCS_TailTwistAngle
    item.wholeTwistAngle = HCS_WholeTwistAngle
    item.widthScale = HCS_WidthScale
    item.widthMode = HCS_WidthMode
    item.widthReverse = HCS_WidthReverse
    item.widthKnotRadius = HCS_WidthKnotRadius
    item.widthProfileMode = HCS_WidthProfileMode
    item.tailWidthScale = HCS_TailWidthScale
    item.wholeWidthScale = HCS_WholeWidthScale
    item
)

fn HCS_profileKey splineIndex = HCS_ProfileKeyPrefix + splineIndex as string

fn HCS_newProfileID =
(
    try (((dotNetClass "System.Guid").NewGuid()).ToString())
    catch ((timestamp() as string) + "_" + (random 100000 999999) as string)
)

fn HCS_getUserValue node key defaultValue:undefined =
(
    if not isValidNode node then return defaultValue
    local value = try (getUserPropVal node key) catch (undefined)
    if value == undefined then defaultValue else value
)

fn HCS_itemProfileData item =
(
    if item.profileID == undefined or item.profileID == "" do item.profileID = HCS_newProfileID()
    #(
        HCS_ProfileVersion, item.profileID,
        item.lengthSegments, item.widthSegments, item.cardWidth, item.centerBulge, item.preventFolding,
        item.twistAngle, item.twistMode as string, item.twistReverse, item.twistKnotRadius, item.twistProfileMode as string,
        item.tailTwistAngle, item.wholeTwistAngle,
        item.widthScale, item.widthMode as string, item.widthReverse, item.widthKnotRadius, item.widthProfileMode as string,
        item.tailWidthScale, item.wholeWidthScale, item.seedWidth,
        (for value in item.knotTwistAngles collect value),
        (for value in item.knotWidthScales collect value),
        item.generatorMode as string, item.templateAxis as string, item.templateCapEnds,
        item.templateName, item.templateBaseWidth,
        (for value in item.templateProfilePoints collect value),
        (for span in item.templateSpans collect (for value in span collect value))
    )
)

fn HCS_itemFromProfileData curve splineIndex meshNode data =
(
    if classOf data != Array or data.count < 24 then return undefined
    local profileVersion = data[1]
    if profileVersion != 1 and profileVersion != HCS_ProfileVersion then return undefined
    local twistModeValue = try (data[9] as name) catch (#tail)
    local twistProfileValue = try (data[12] as name) catch (#tail)
    local widthModeValue = try (data[16] as name) catch (#tail)
    local widthProfileValue = try (data[19] as name) catch (#tail)
    local generatorModeValue = #ribbon
    local templateAxisValue = #z
    local templateCapValue = false
    local templateNameValue = ""
    local templateBaseWidthValue = 1.0
    local templatePointsValue = #()
    local templateSpansValue = #()
    if profileVersion >= 2 and data.count >= 31 do
    (
        generatorModeValue = try (data[25] as name) catch (#ribbon)
        templateAxisValue = try (data[26] as name) catch (#z)
        templateCapValue = data[27]
        templateNameValue = data[28] as string
        templateBaseWidthValue = data[29]
        templatePointsValue = for value in data[30] collect value
        templateSpansValue = for span in data[31] collect (for value in span collect value)
    )
    HCS_CardItem curve:curve splineIndex:splineIndex meshNode:meshNode profileID:(data[2] as string) \
        lengthSegments:data[3] widthSegments:data[4] cardWidth:data[5] centerBulge:data[6] preventFolding:data[7] \
        twistAngle:data[8] twistMode:twistModeValue twistReverse:data[10] twistKnotRadius:data[11] twistProfileMode:twistProfileValue \
        tailTwistAngle:data[13] wholeTwistAngle:data[14] widthScale:data[15] widthMode:widthModeValue widthReverse:data[17] \
        widthKnotRadius:data[18] widthProfileMode:widthProfileValue tailWidthScale:data[20] wholeWidthScale:data[21] seedWidth:data[22] \
        knotTwistAngles:(for value in data[23] collect value) knotWidthScales:(for value in data[24] collect value) \
        generatorMode:generatorModeValue templateAxis:templateAxisValue templateCapEnds:templateCapValue \
        templateName:templateNameValue templateBaseWidth:templateBaseWidthValue \
        templateProfilePoints:templatePointsValue templateSpans:templateSpansValue
)

fn HCS_persistItem item =
(
    if not isValidNode item.curve then return false
    if item.profileID == undefined or item.profileID == "" do item.profileID = HCS_newProfileID()
    local ok = true
    try (setUserPropVal item.curve (HCS_profileKey item.splineIndex) (HCS_itemProfileData item) quoteStrings:true) catch (ok = false)
    if isValidNode item.meshNode do
        try (setUserPropVal item.meshNode HCS_MeshLinkKey item.profileID quoteStrings:true) catch (ok = false)
    ok
)

fn HCS_persistAll =
(
    local persistedCount = 0
    if classOf HCS_Items != Array then return 0
    for item in HCS_Items do
    (
        if HCS_persistItem item do persistedCount += 1
    )
    persistedCount
)

fn HCS_clearItemPersistence item =
(
    if isValidNode item.curve do try (deleteUserProp item.curve (HCS_profileKey item.splineIndex)) catch()
    if isValidNode item.meshNode do try (deleteUserProp item.meshNode HCS_MeshLinkKey) catch()
    true
)

fn HCS_clearCurveProfileProps curve =
(
    if isValidNode curve do
        for splineIndex = 1 to (numSplines curve) do try (deleteUserProp curve (HCS_profileKey splineIndex)) catch()
    true
)

fn HCS_findPersistentMesh linkID usedMeshes:#() =
(
    for node in objects where isValidNode node and (findItem usedMeshes node) == 0 do
    (
        local nodeLink = HCS_getUserValue node HCS_MeshLinkKey defaultValue:""
        if (nodeLink as string) == linkID do return node
    )
    undefined
)

fn HCS_restoreCoordinatesFromUV item =
(
    if not isValidNode item.meshNode then return false
    local vertCount = polyop.getNumVerts item.meshNode
    local profileCount = if item.generatorMode == #template then item.templateProfilePoints.count else (item.widthSegments + 1)
    local expectedCount = (item.lengthSegments + 1) * profileCount
    if vertCount != expectedCount then return false
    if item.generatorMode == #template then
    (
        if profileCount < 2 or item.templateSpans.count < 1 then return false
        item.params = #()
        item.widthCoords = #()
        local halfBase = amax #(item.templateBaseWidth*0.5, 0.0001)
        for row = 0 to item.lengthSegments do
        (
            local u = row as float / item.lengthSegments
            for profileIndex = 1 to profileCount do
            (
                append item.params u
                append item.widthCoords (item.templateProfilePoints[profileIndex].x / halfBase)
            )
        )
        return true
    )
    local mapCount = try (polyop.getNumMapVerts item.meshNode 1) catch (0)
    if mapCount < vertCount then return false
    item.params = #()
    item.widthCoords = #()
    for vertID = 1 to vertCount do
    (
        local uv = polyop.getMapVert item.meshNode 1 vertID
        append item.params uv.y
        append item.widthCoords (uv.x*2.0 - 1.0)
    )
    true
)

fn HCS_findItem curve splineIndex =
(
    for item in HCS_Items where item.curve == curve and item.splineIndex == splineIndex do return item
    undefined
)

fn HCS_selectedItems includeMeshes:false =
(
    local result = #()
    for item in HCS_Items where isValidNode item.curve and (item.curve.isSelected or (includeMeshes and isValidNode item.meshNode and item.meshNode.isSelected)) do append result item
    result
)

fn HCS_isSplineNode n =
(
    if not isValidNode n then return false
    local count = 0
    try (count = numSplines n) catch()
    count > 0
)

struct HCS_TemplateData
(
    sourceName = "",
    axis = #z,
    baseWidth = 1.0,
    profilePoints = #(),
    spans = #(),
    material
)

fn HCS_isTemplateNode n =
(
    isValidNode n and (try (superClassOf n == GeometryClass) catch (false))
)

fn HCS_templateAxisCoordinate p axis =
(
    case axis of
    (
        #x: p.x
        #y: p.y
        default: p.z
    )
)

fn HCS_templateCrossPoint p axis =
(
    -- The two cross axes and the chosen longitudinal axis remain right-handed.
    case axis of
    (
        #x: [p.y, p.z, 0]
        #y: [p.z, p.x, 0]
        default: [p.x, p.y, 0]
    )
)

fn HCS_visibleLocalVert node vertID =
(
    local worldPoint
    in coordsys world worldPoint = polyop.getVert node vertID
    local tm = node.objectTransform
    local xAxis = HCE_safeNormalize tm.row1 fallback:[1,0,0]
    local yAxis = HCE_safeNormalize tm.row2 fallback:[0,1,0]
    local zAxis = HCE_safeNormalize tm.row3 fallback:[0,0,1]
    local delta = worldPoint - tm.row4
    [dot delta xAxis, dot delta yAxis, dot delta zAxis]
)

fn HCS_captureTemplateProfile sourceNode axis:#z =
(
    if not HCS_isTemplateNode sourceNode then throw "模板必须是有效的几何体。"
    local tempNode = undefined
    local result = undefined
    try
    (
        with undo off
        (
            tempNode = copy sourceNode
            tempNode.name = uniqueName "HCS_TEMPLATE_READ"
            try (hide tempNode) catch()
            convertToPoly tempNode
        )
        local vertCount = polyop.getNumVerts tempNode
        local faceCount = polyop.getNumFaces tempNode
        if vertCount < 2 or faceCount < 1 then throw "模板没有可用的顶点或多边形。"

        local localPoints = for v = 1 to vertCount collect (HCS_visibleLocalVert tempNode v)
        local minAxis = 1.0e30
        local maxAxis = -1.0e30
        for point in localPoints do
        (
            local value = HCS_templateAxisCoordinate point axis
            minAxis = amin #(minAxis, value)
            maxAxis = amax #(maxAxis, value)
        )
        local axisLength = maxAxis - minAxis
        if axisLength < 0.0001 then throw "模板在所选长度轴上没有厚度，请切换 X/Y/Z 轴。"
        local tolerance = amax #(0.0001, axisLength*0.001)
        local rawSpans = #()
        local spanKeys = #()
        local profileSourceIDs = #()
        local hasMap = try (polyop.getMapSupport tempNode 1) catch (false)

        for faceID = 1 to faceCount do
        (
            local faceVerts = polyop.getFaceVerts tempNode faceID
            local minFlags = for vertID in faceVerts collect ((abs ((HCS_templateAxisCoordinate localPoints[vertID] axis) - minAxis)) <= tolerance)
            local hasAbove = false
            for isMinimum in minFlags where not isMinimum do hasAbove = true
            if hasAbove do
            (
                local pairPosition = 0
                for j = 1 to faceVerts.count while pairPosition == 0 do
                (
                    local j2 = if j == faceVerts.count then 1 else j+1
                    if minFlags[j] and minFlags[j2] do pairPosition = j
                )
                if pairPosition > 0 do
                (
                    local nextPosition = if pairPosition == faceVerts.count then 1 else pairPosition+1
                    local sourceA = faceVerts[pairPosition]
                    local sourceB = faceVerts[nextPosition]
                    local lowID = amin #(sourceA, sourceB)
                    local highID = amax #(sourceA, sourceB)
                    local edgeKey = lowID as string + ":" + highID as string
                    if (findItem spanKeys edgeKey) == 0 do
                    (
                        append spanKeys edgeKey
                        HCE_addUnique profileSourceIDs sourceA
                        HCE_addUnique profileSourceIDs sourceB
                        local uA = undefined
                        local uB = undefined
                        if hasMap do
                        (
                            try
                            (
                                local mapFace = polyop.getMapFace tempNode 1 faceID
                                if mapFace.count == faceVerts.count do
                                (
                                    uA = (polyop.getMapVert tempNode 1 mapFace[pairPosition]).x
                                    uB = (polyop.getMapVert tempNode 1 mapFace[nextPosition]).x
                                )
                            )
                            catch()
                        )
                        local materialID = try (polyop.getFaceMatID tempNode faceID) catch (1)
                        append rawSpans #(sourceA, sourceB, materialID, uA, uB)
                    )
                )
            )
        )
        if rawSpans.count == 0 then throw "模板没有沿所选轴延伸的侧面。请使用带侧面的管、方管或交叉面模板。"

        local profilePoints = for sourceID in profileSourceIDs collect (HCS_templateCrossPoint localPoints[sourceID] axis)
        local spans = #()
        for spanIndex = 1 to rawSpans.count do
        (
            local raw = rawSpans[spanIndex]
            local profileA = findItem profileSourceIDs raw[1]
            local profileB = findItem profileSourceIDs raw[2]
            local uA = raw[4]
            local uB = raw[5]
            if uA == undefined or uB == undefined then
            (
                uA = (spanIndex-1.0) / rawSpans.count
                uB = spanIndex as float / rawSpans.count
            )
            append spans #(profileA, profileB, raw[3], uA, uB)
        )

        local minCrossX = 1.0e30
        local maxCrossX = -1.0e30
        local minCrossY = 1.0e30
        local maxCrossY = -1.0e30
        for point in profilePoints do
        (
            minCrossX = amin #(minCrossX, point.x)
            maxCrossX = amax #(maxCrossX, point.x)
            minCrossY = amin #(minCrossY, point.y)
            maxCrossY = amax #(maxCrossY, point.y)
        )
        local baseWidth = amax #(maxCrossX-minCrossX, maxCrossY-minCrossY)
        if baseWidth < 0.0001 then throw "模板横截面尺寸为零。"
        result = HCS_TemplateData sourceName:sourceNode.name axis:axis baseWidth:baseWidth \
            profilePoints:profilePoints spans:spans material:sourceNode.material
    )
    catch
    (
        if isValidNode tempNode do with undo off delete tempNode
        throw()
    )
    if isValidNode tempNode do with undo off delete tempNode
    result
)

fn HCS_setPendingTemplate templateData sourceNode:undefined =
(
    if templateData == undefined then return false
    HCS_GeneratorMode = #template
    HCS_TemplateNode = sourceNode
    HCS_TemplateAxis = templateData.axis
    HCS_TemplateName = templateData.sourceName
    HCS_TemplateBaseWidth = templateData.baseWidth
    HCS_TemplateProfilePoints = for value in templateData.profilePoints collect value
    HCS_TemplateSpans = for span in templateData.spans collect (for value in span collect value)
    HCS_TemplateMaterial = templateData.material
    true
)

fn HCS_applyPendingGeneratorToItem item =
(
    item.generatorMode = HCS_GeneratorMode
    item.templateAxis = HCS_TemplateAxis
    item.templateCapEnds = HCS_TemplateCapEnds
    item.templateName = HCS_TemplateName
    item.templateBaseWidth = HCS_TemplateBaseWidth
    item.templateProfilePoints = for value in HCS_TemplateProfilePoints collect value
    item.templateSpans = for span in HCS_TemplateSpans collect (for value in span collect value)
    item.templateMaterial = HCS_TemplateMaterial
    if item.generatorMode == #template and (item.templateProfilePoints.count < 2 or item.templateSpans.count < 1) then
        throw "尚未拾取有效的自定义模板。"
    item
)

fn HCS_generatorDescription mode templateName:"" =
(
    if mode == #template then ("自定义模板：" + (if templateName == "" then "未命名" else templateName)) else "标准带状面片"
)

fn HCS_ensureKnotAngles item =
(
    local knotCount = numKnots item.curve item.splineIndex
    if item.knotTwistAngles.count != knotCount do
    (
        local oldAngles = item.knotTwistAngles
        item.knotTwistAngles = for k = 1 to knotCount collect (if k <= oldAngles.count then oldAngles[k] else 0.0)
    )
    knotCount
)

fn HCS_ensureKnotWidthScales item =
(
    local knotCount = numKnots item.curve item.splineIndex
    if item.knotWidthScales.count != knotCount do
    (
        local oldScales = item.knotWidthScales
        item.knotWidthScales = for k = 1 to knotCount collect (if k <= oldScales.count then oldScales[k] else 1.0)
    )
    knotCount
)

fn HCS_localKnotTwistAngle item u =
(
    local knotCount = HCS_ensureKnotAngles item
    if knotCount < 2 then return 0.0
    local radius = amax #(HCS_TwistKnotRadius / (knotCount - 1.0), 0.000001)
    local weightedAngle = 0.0
    local totalWeight = 0.0
    for k = 1 to knotCount do
    (
        local knotU = (k - 1.0) / (knotCount - 1.0)
        local normalizedDistance = (abs (u - knotU)) / radius
        if normalizedDistance < 1.0 do
        (
            local x = 1.0 - normalizedDistance
            local weight = x*x*(3.0 - 2.0*x)
            weightedAngle += item.knotTwistAngles[k] * weight
            totalWeight += weight
        )
    )
    if totalWeight < 0.000001 then 0.0 else weightedAngle / totalWeight
)

fn HCS_storeCurrentTwistProfile =
(
    if HCS_TwistMode == #tail then HCS_TailTwistAngle = HCS_TwistAngle
    else if HCS_TwistMode == #whole then HCS_WholeTwistAngle = HCS_TwistAngle
)

fn HCS_setTwistEditMode mode =
(
    HCS_storeCurrentTwistProfile()
    if (mode == #tail or mode == #whole) then
    (
        HCS_TwistProfileMode = mode
        HCS_TwistMode = mode
        HCS_TwistAngle = if mode == #tail then HCS_TailTwistAngle else HCS_WholeTwistAngle
    )
    else HCS_TwistMode = #knots
    HCS_TwistMode
)

fn HCS_setCurrentTwistProfileAngle angle =
(
    HCS_TwistAngle = angle
    if HCS_TwistMode == #tail then HCS_TailTwistAngle = angle
    else if HCS_TwistMode == #whole then HCS_WholeTwistAngle = angle
    angle
)

fn HCS_twistBaseAngleAtParam u =
(
    -- 三层旋转始终同时存在；当前模式只决定 UI 正在编辑哪一层。
    if HCS_TwistMode == #tail then HCS_TailTwistAngle = HCS_TwistAngle
    else if HCS_TwistMode == #whole then HCS_WholeTwistAngle = HCS_TwistAngle
    local s = if HCS_TwistReverse then (1.0-u) else u
    s = amax #(0.0, amin #(1.0, s))
    HCS_WholeTwistAngle + HCS_TailTwistAngle*s*s*(3.0-2.0*s)
)

fn HCS_twistAngleAtParam item u =
(
    HCS_twistBaseAngleAtParam u + HCS_localKnotTwistAngle item u
)

fn HCS_localKnotWidthScale item u =
(
    local knotCount = HCS_ensureKnotWidthScales item
    if knotCount < 2 then return 1.0
    local radius = amax #(HCS_WidthKnotRadius / (knotCount - 1.0), 0.000001)
    local weightedDelta = 0.0
    local totalWeight = 0.0
    for k = 1 to knotCount do
    (
        local knotU = (k - 1.0) / (knotCount - 1.0)
        local normalizedDistance = (abs (u - knotU)) / radius
        if normalizedDistance < 1.0 do
        (
            local x = 1.0 - normalizedDistance
            local weight = x*x*(3.0 - 2.0*x)
            weightedDelta += (item.knotWidthScales[k] - 1.0) * weight
            totalWeight += weight
        )
    )
    if totalWeight < 0.000001 then 1.0 else amax #(0.001, 1.0 + weightedDelta/totalWeight)
)

fn HCS_storeCurrentWidthProfile =
(
    if HCS_WidthMode == #tail then HCS_TailWidthScale = HCS_WidthScale
    else if HCS_WidthMode == #whole then HCS_WholeWidthScale = HCS_WidthScale
)

fn HCS_setWidthEditMode mode =
(
    HCS_storeCurrentWidthProfile()
    if (mode == #tail or mode == #whole) then
    (
        HCS_WidthProfileMode = mode
        HCS_WidthMode = mode
        HCS_WidthScale = if mode == #tail then HCS_TailWidthScale else HCS_WholeWidthScale
    )
    else HCS_WidthMode = #knots
    HCS_WidthMode
)

fn HCS_setCurrentWidthProfileScale scale =
(
    scale = amax #(0.001, scale)
    HCS_WidthScale = scale
    if HCS_WidthMode == #tail then HCS_TailWidthScale = scale
    else if HCS_WidthMode == #whole then HCS_WholeWidthScale = scale
    scale
)

fn HCS_widthBaseScaleAtParam u =
(
    -- 三层宽度始终同时存在：整条倍率 × 尾部渐变倍率 × 局部点倍率。
    if HCS_WidthMode == #tail then HCS_TailWidthScale = HCS_WidthScale
    else if HCS_WidthMode == #whole then HCS_WholeWidthScale = HCS_WidthScale
    local s = if HCS_WidthReverse then (1.0-u) else u
    s = amax #(0.0, amin #(1.0, s))
    local tailScale = 1.0+(HCS_TailWidthScale-1.0)*s*s*(3.0-2.0*s)
    amax #(0.001, HCS_WholeWidthScale*tailScale)
)

fn HCS_widthScaleAtParam item u =
(
    amax #(0.001, HCS_widthBaseScaleAtParam u * HCS_localKnotWidthScale item u)
)

fn HCS_rotatedAxes item widthAxis binormalAxis u =
(
    local angleDegrees = HCS_twistAngleAtParam item u
    if (abs angleDegrees) < 0.0000001 then return #(widthAxis, binormalAxis)
    local cs = cos angleDegrees
    local sn = sin angleDegrees
    local rotatedWidth = HCE_safeNormalize (widthAxis*cs + binormalAxis*sn) fallback:widthAxis
    local rotatedBinormal = HCE_safeNormalize (binormalAxis*cs - widthAxis*sn) fallback:binormalAxis
    #(rotatedWidth, rotatedBinormal)
)

fn HCS_sampleFrames curveNode splineIndex params seedWidth =
(
    local points = #()
    local tangents = #()
    local widths = #()
    local bins = #()
    resetLengthInterp()
    for u in params do
    (
        local p
        in coordsys world p = lengthInterp curveNode splineIndex u
        append points p
    )

    -- Derive tangents from neighboring sampled positions. In particular, the
    -- final tangent uses the last real chord instead of lengthTangent at 1.0,
    -- which can be zero or reversed on collapsed Bezier end handles.
    for i = 1 to points.count do
    (
        local t
        if points.count == 1 then
        (
            in coordsys world t = lengthTangent curveNode splineIndex params[i]
        )
        else if i == 1 then t = points[2] - points[1]
        else if i == points.count then t = points[points.count] - points[points.count-1]
        else t = points[i+1] - points[i-1]
        if (length t) < 0.000001 do
        (
            in coordsys world t = lengthTangent curveNode splineIndex params[i]
        )
        append tangents (HCE_safeNormalize t fallback:(if i > 1 then tangents[i-1] else [0,1,0]))
    )

    local prevWidth = seedWidth
    for i = 1 to points.count do
    (
        local t = tangents[i]
        local w = prevWidth - t * (dot prevWidth t)
        if (length w) < 0.000001 do
        (
            local fallbackAxis = if (abs (dot t [0,0,1])) < 0.95 then [0,0,1] else [1,0,0]
            w = cross fallbackAxis t
        )
        w = normalize w
        if i > 1 and (dot w prevWidth) < 0.0 do w = -w
        local b = HCE_safeNormalize (cross t w) fallback:[0,0,1]
        w = HCE_safeNormalize (cross b t) fallback:w
        append widths w
        append bins b
        prevWidth = w
    )
    #(points,tangents,widths,bins)
)

fn HCS_localCurvatureRadius points index =
(
    if points.count < 3 then return 1.0e30
    local a
    local b
    local c
    if index <= 1 then
    (
        a = points[1]; b = points[2]; c = points[3]
    )
    else if index >= points.count then
    (
        a = points[points.count-2]; b = points[points.count-1]; c = points[points.count]
    )
    else
    (
        a = points[index-1]; b = points[index]; c = points[index+1]
    )
    local ab = distance a b
    local bc = distance b c
    local ac = distance a c
    local twiceArea = length (cross (b-a) (c-a))
    if ab < 0.000001 or bc < 0.000001 or ac < 0.000001 or twiceArea < 0.000001 then 1.0e30
    else (ab*bc*ac) / (2.0*twiceArea)
)

fn HCS_foldPreventionScales points crossRadii:#() =
(
    local scales = for i = 1 to points.count collect 1.0
    if not HCS_PreventFolding or points.count < 3 then return scales
    local defaultCrossRadius = sqrt ((HCS_CardWidth*0.5)*(HCS_CardWidth*0.5) + HCS_CenterBulge*HCS_CenterBulge)
    if defaultCrossRadius < 0.000001 then return scales

    for i = 1 to points.count do
    (
        local crossRadius = if crossRadii.count == points.count then crossRadii[i] else defaultCrossRadius
        crossRadius = amax #(crossRadius, 0.000001)
        local curvatureRadius = HCS_localCurvatureRadius points i
        scales[i] = amax #(0.02, amin #(1.0, (curvatureRadius*0.80) / crossRadius))
    )

    -- Limit expansion by the real center-line step, not by a fixed percentage.
    -- A fixed 10% jump can itself make an offset edge run backwards when the
    -- card is wide and densely subdivided.  This bound keeps both sides
    -- longitudinally monotonic even around polyline corners.
    for i = 2 to scales.count do
    (
        local crossRadius = if crossRadii.count == points.count then amax #(crossRadii[i-1], crossRadii[i]) else defaultCrossRadius
        crossRadius = amax #(crossRadius, 0.000001)
        local growth = amax #(0.001, amin #(0.10, (distance points[i] points[i-1])*0.20/crossRadius))
        scales[i] = amin #(scales[i], scales[i-1] + growth)
    )
    for i = (scales.count-1) to 1 by -1 do
    (
        local crossRadius = if crossRadii.count == points.count then amax #(crossRadii[i], crossRadii[i+1]) else defaultCrossRadius
        crossRadius = amax #(crossRadius, 0.000001)
        local growth = amax #(0.001, amin #(0.10, (distance points[i+1] points[i])*0.20/crossRadius))
        scales[i] = amin #(scales[i], scales[i+1] + growth)
    )
    scales
)

fn HCS_writeStraightUV meshNode params widthCoords =
(
    local vertCount = polyop.getNumVerts meshNode
    polyop.setMapSupport meshNode 1 true
    polyop.setNumMapVerts meshNode 1 vertCount keep:false
    for v = 1 to vertCount do
        polyop.setMapVert meshNode 1 v [(widthCoords[v] + 1.0) * 0.5, params[v], 0]
    for f = 1 to (polyop.getNumFaces meshNode) do
        polyop.setMapFace meshNode 1 f (polyop.getFaceVerts meshNode f)
)

fn HCS_templateClosedLoops profilePoints spans =
(
    local pointCount = profilePoints.count
    local adjacency = for i = 1 to pointCount collect #()
    for span in spans where span[1] >= 1 and span[1] <= pointCount and span[2] >= 1 and span[2] <= pointCount do
    (
        HCE_addUnique adjacency[span[1]] span[2]
        HCE_addUnique adjacency[span[2]] span[1]
    )
    local handled = for i = 1 to pointCount collect false
    local loops = #()
    for startID = 1 to pointCount where not handled[startID] and adjacency[startID].count == 2 do
    (
        local loop = #()
        local previousID = 0
        local currentID = startID
        local closed = false
        local guard = 0
        while not closed and guard <= pointCount do
        (
            guard += 1
            append loop currentID
            handled[currentID] = true
            local neighbors = adjacency[currentID]
            if neighbors.count != 2 then guard = pointCount+1
            else
            (
                local nextID = if neighbors[1] != previousID then neighbors[1] else neighbors[2]
                previousID = currentID
                currentID = nextID
                if currentID == startID then closed = true
                else if handled[currentID] then guard = pointCount+1
            )
        )
        if closed and loop.count >= 3 do
        (
            local signedArea = 0.0
            for i = 1 to loop.count do
            (
                local j = if i == loop.count then 1 else i+1
                local a = profilePoints[loop[i]]
                local b = profilePoints[loop[j]]
                signedArea += a.x*b.y - b.x*a.y
            )
            if signedArea < 0.0 do loop = reverse loop
            append loops loop
        )
    )
    loops
)

fn HCS_createGridMesh item =
(
    HCS_loadItemSettings item
    local oldMesh = item.meshNode
    local oldName = if isValidNode oldMesh then oldMesh.name else (uniqueName (item.curve.name + "_CARD_S" + item.splineIndex as string))
    local oldMaterial = if isValidNode oldMesh then oldMesh.material else undefined
    local oldWireColor = if isValidNode oldMesh then oldMesh.wirecolor else (color 120 220 255)
    if isValidNode oldMesh do delete oldMesh

    local grid
    if item.generatorMode == #template then
    (
        local profileCount = item.templateProfilePoints.count
        local spanCount = item.templateSpans.count
        if profileCount < 2 or spanCount < 1 then throw "自定义模板截面数据无效，请重新拾取模板。"
        -- Editable_Poly itself is not a constructible scene primitive in older
        -- Max versions. Start with an empty TriMesh node, then convert it.
        grid = mesh name:oldName vertices:#() faces:#()
        convertToPoly grid
        grid.transform = matrix3 1
        item.params = #()
        item.widthCoords = #()
        local halfBase = amax #(item.templateBaseWidth*0.5, 0.0001)
        for row = 0 to HCS_LengthSegments do
        (
            local u = row as float / HCS_LengthSegments
            for profileIndex = 1 to profileCount do
            (
                polyop.createVert grid [0,0,0]
                append item.params u
                append item.widthCoords (item.templateProfilePoints[profileIndex].x / halfBase)
            )
        )
        for row = 0 to (HCS_LengthSegments-1) do
        (
            local currentOffset = row*profileCount
            local nextOffset = (row+1)*profileCount
            for span in item.templateSpans do
            (
                local faceID = polyop.createPolygon grid #(currentOffset+span[1], currentOffset+span[2], nextOffset+span[2], nextOffset+span[1])
                try (polyop.setFaceMatID grid #{faceID} (amax #(1, span[3]))) catch()
            )
        )
        local sideFaceCount = polyop.getNumFaces grid
        local capRecords = #()
        if item.templateCapEnds do
        (
            local loops = HCS_templateClosedLoops item.templateProfilePoints item.templateSpans
            for loop in loops do
            (
                local startVerts = for i = loop.count to 1 by -1 collect loop[i]
                local startProfiles = for i = loop.count to 1 by -1 collect loop[i]
                local endVerts = for profileID in loop collect (HCS_LengthSegments*profileCount + profileID)
                local startFace = polyop.createPolygon grid startVerts
                local endFace = polyop.createPolygon grid endVerts
                try (polyop.setFaceMatID grid #{startFace,endFace} 1) catch()
                append capRecords #(startFace,startProfiles)
                append capRecords #(endFace,(for profileID in loop collect profileID))
            )
        )
        local mapVertCount = sideFaceCount*4
        for record in capRecords do mapVertCount += record[2].count
        polyop.setMapSupport grid 1 true
        polyop.setNumMapVerts grid 1 mapVertCount keep:false
        local mapVertID = 1
        local faceID = 1
        for row = 0 to (HCS_LengthSegments-1) do
        (
            local v0 = row as float / HCS_LengthSegments
            local v1 = (row+1) as float / HCS_LengthSegments
            for span in item.templateSpans do
            (
                polyop.setMapVert grid 1 mapVertID [span[4],v0,0]
                polyop.setMapVert grid 1 (mapVertID+1) [span[5],v0,0]
                polyop.setMapVert grid 1 (mapVertID+2) [span[5],v1,0]
                polyop.setMapVert grid 1 (mapVertID+3) [span[4],v1,0]
                polyop.setMapFace grid 1 faceID #(mapVertID,mapVertID+1,mapVertID+2,mapVertID+3)
                mapVertID += 4
                faceID += 1
            )
        )
        if capRecords.count > 0 do
        (
            local minX = 1.0e30
            local maxX = -1.0e30
            local minY = 1.0e30
            local maxY = -1.0e30
            for point in item.templateProfilePoints do
            (
                minX = amin #(minX, point.x); maxX = amax #(maxX, point.x)
                minY = amin #(minY, point.y); maxY = amax #(maxY, point.y)
            )
            local rangeX = amax #(maxX-minX, 0.0001)
            local rangeY = amax #(maxY-minY, 0.0001)
            for record in capRecords do
            (
                local mapFace = #()
                for profileID in record[2] do
                (
                    local point = item.templateProfilePoints[profileID]
                    polyop.setMapVert grid 1 mapVertID [(point.x-minX)/rangeX,(point.y-minY)/rangeY,0]
                    append mapFace mapVertID
                    mapVertID += 1
                )
                polyop.setMapFace grid 1 record[1] mapFace
            )
        )
    )
    else
    (
        grid = plane name:oldName width:(amax #(HCS_CardWidth, 0.001)) length:100.0 \
            widthsegs:HCS_WidthSegments lengthsegs:HCS_LengthSegments mapcoords:true
        convertToPoly grid
        grid.transform = matrix3 1
        item.params = #()
        item.widthCoords = #()
        for v = 1 to (polyop.getNumVerts grid) do
        (
            local p = polyop.getVert grid v
            append item.params ((p.y + 50.0) / 100.0)
            append item.widthCoords (p.x / (amax #(HCS_CardWidth * 0.5, 0.0005)))
        )
        HCS_writeStraightUV grid item.params item.widthCoords
    )
    grid.wirecolor = oldWireColor
    local desiredMaterial = if item.generatorMode == #template and item.templateMaterial != undefined then item.templateMaterial else oldMaterial
    if desiredMaterial != undefined do grid.material = desiredMaterial
    item.meshNode = grid
    grid
)

fn HCS_restorePersistentSession force:false =
(
    if HCS_Active and not force then return HCS_Items.count
    HCS_removeHandlers()
    HCS_Items = #()
    HCS_Active = false
    local usedMeshes = #()
    local usedLinks = #()
    for curve in objects where HCS_isSplineNode curve do
    (
        for splineIndex = 1 to (numSplines curve) do
        (
            local data = HCS_getUserValue curve (HCS_profileKey splineIndex)
            if data != undefined do
            (
                local oldLink = try (data[2] as string) catch ("")
                local meshNode = if oldLink != "" then HCS_findPersistentMesh oldLink usedMeshes:usedMeshes else undefined
                local item = HCS_itemFromProfileData curve splineIndex meshNode data
                if item != undefined do
                (
                    if (findItem usedLinks oldLink) != 0 or oldLink == "" do item.profileID = HCS_newProfileID()
                    append usedLinks item.profileID
                    if isValidNode meshNode do append usedMeshes meshNode
                    HCS_ensureKnotAngles item
                    HCS_ensureKnotWidthScales item
                    if not (HCS_restoreCoordinatesFromUV item) do HCS_createGridMesh item
                    append HCS_Items item
                    HCS_persistItem item
                )
            )
        )
    )
    HCS_Active = HCS_Items.count > 0
    if HCS_Active do
    (
        HCS_updateAll force:true
        HCS_setMeshesFrozen true
        HCS_persistAll()
        HCS_installHandlers()
    )
    HCS_Items.count
)

fn HCS_captureCurveState item =
(
    local state = #()
    if not isValidNode item.curve then return state
    in coordsys world
    (
        for k = 1 to (numKnots item.curve item.splineIndex) do
        (
            append state (getKnotPoint item.curve item.splineIndex k)
            append state (getInVec item.curve item.splineIndex k)
            append state (getOutVec item.curve item.splineIndex k)
        )
    )
    state
)

fn HCS_updateItem item =
(
    if not isValidNode item.curve then throw "源样条已被删除。"
    if not isValidNode item.meshNode then throw "生成的面片已被删除。"
    HCS_loadItemSettings item
    HCS_ensureKnotAngles item
    -- Compute one ordered coordinate frame per longitudinal row. Every width
    -- vertex in the same row reuses that frame, preventing tail-row shearing.
    local rowParams = for row = 0 to HCS_LengthSegments collect (row as float / HCS_LengthSegments)
    local frames = HCS_sampleFrames item.curve item.splineIndex rowParams item.seedWidth
    local widthScales = for u in rowParams collect (HCS_widthScaleAtParam item u)
    local crossRadii
    local templateScale = 1.0
    if item.generatorMode == #template then
    (
        templateScale = HCS_CardWidth / amax #(item.templateBaseWidth, 0.0001)
        local maxTemplateRadius = 0.0001
        for point in item.templateProfilePoints do maxTemplateRadius = amax #(maxTemplateRadius, length point)
        crossRadii = for scale in widthScales collect (maxTemplateRadius*templateScale*scale)
    )
    else crossRadii = for scale in widthScales collect (sqrt ((HCS_CardWidth*0.5*scale)*(HCS_CardWidth*0.5*scale) + HCS_CenterBulge*HCS_CenterBulge))
    local foldScales = HCS_foldPreventionScales frames[1] crossRadii:crossRadii
    local positions = #()
    if item.generatorMode == #template then
    (
        if item.params.count != (HCS_LengthSegments+1)*item.templateProfilePoints.count then throw "自定义模板网格拓扑与参数不一致，请重建。"
        for rowIndex = 1 to rowParams.count do
        (
            local u = rowParams[rowIndex]
            local axes = HCS_rotatedAxes item frames[3][rowIndex] frames[4][rowIndex] u
            local profileScale = templateScale*widthScales[rowIndex]*foldScales[rowIndex]
            for point in item.templateProfilePoints do
                append positions (frames[1][rowIndex] + axes[1]*(point.x*profileScale) + axes[2]*(point.y*profileScale))
        )
    )
    else
    (
        for i = 1 to item.params.count do
        (
            local u = item.params[i]
            local rowIndex = (floor (u*HCS_LengthSegments + 0.5)) + 1
            rowIndex = amax #(1, amin #(frames[1].count, rowIndex))
            local widthCoord = amax #(-1.0, amin #(1.0, item.widthCoords[i]))
            local axes = HCS_rotatedAxes item frames[3][rowIndex] frames[4][rowIndex] u
            local safeScale = foldScales[rowIndex]
            local widthOffset = widthCoord * HCS_CardWidth * 0.5 * widthScales[rowIndex] * safeScale
            local bulgeProfile = cos ((abs widthCoord) * 90.0)
            append positions (frames[1][rowIndex] + axes[1]*widthOffset + axes[2]*(HCS_CenterBulge*bulgeProfile*safeScale))
        )
    )
    local verts = #{1..positions.count}
    with redraw off
    (
        in coordsys world polyop.setVert item.meshNode verts positions
        update item.meshNode
    )
    item.lastCurveState = HCS_captureCurveState item
    true
)

fn HCS_updateAll force:false requestRedraw:true =
(
    if not HCS_Active or HCS_IsUpdating then return false
    HCS_IsUpdating = true
    local ok = true
    local anyChanged = false
    try
    (
        for item in HCS_Items do
        (
            local state = HCS_captureCurveState item
            if force or not (HCE_curveStateEqual state item.lastCurveState) do
            (
                HCS_updateItem item
                anyChanged = true
            )
        )
        if requestRedraw and anyChanged do redrawViews()
    )
    catch
    (
        ok = false
        format "Spline Card live update error: %\n" (getCurrentException())
    )
    local selectedContexts = HCS_selectedItems()
    if selectedContexts.count > 0 do HCS_loadItemSettings selectedContexts[1]
    HCS_IsUpdating = false
    ok
)

fn HCS_setMeshesFrozen state =
(
    for item in HCS_Items where isValidNode item.meshNode do
        try (item.meshNode.isFrozen = state) catch()
    state
)

fn HCS_rebuildItems items =
(
    if not HCS_Active or items.count == 0 then return false
    for item in items where isValidNode item.curve do HCS_createGridMesh item
    local ok = HCS_updateAll force:true
    if ok do
    (
        for item in items do HCS_persistItem item
        HCS_setMeshesFrozen true
    )
    ok
)

fn HCS_rebuildAllMeshes = HCS_rebuildItems HCS_Items

fn HCS_removeHandlers =
(
    try (deleteAllChangeHandlers id:#HCS_LiveCard) catch()
    HCS_LiveDirty = false
)

fn HCS_liveChanged =
(
    -- Never write mesh vertices from inside a redraw callback. During an
    -- interactive knot drag Max can expose alternating preview/committed shape
    -- caches there, which made the card visibly jump between old and new poses.
    -- The rollout timer consumes this flag and performs one coalesced update.
    if HCS_Active and HCS_LiveEnabled and not HCS_IsUpdating do HCS_LiveDirty = true
)

fn HCS_flushLiveUpdate =
(
    if not HCS_Active or not HCS_LiveEnabled then return false
    if HCS_IsUpdating then
    (
        HCS_LiveDirty = true
        return false
    )
    local forceNow = HCS_LiveDirty
    HCS_LiveDirty = false
    local ok = HCS_updateAll force:forceNow
    if not ok do HCS_LiveDirty = true
    ok
)

fn HCS_installHandlers =
(
    HCS_removeHandlers()
    local curves = #()
    for item in HCS_Items where isValidNode item.curve do HCE_addUnique curves item.curve
    for curve in curves do
    (
        when geometry curve changes id:#HCS_LiveCard handleAt:#redrawViews do HCS_liveChanged()
        when transform curve changes id:#HCS_LiveCard handleAt:#redrawViews do HCS_liveChanged()
    )
)

fn HCS_generateFromSelection =
(
    local curves = for n in selection where HCS_isSplineNode n collect n
    if curves.count == 0 then throw "请选择一根或多根可编辑样条线。"
    local addedCount = 0
    local previousCount = HCS_Items.count
    local previousActive = HCS_Active
    try
    (
        for curve in curves do
        (
            for splineIndex = 1 to (numSplines curve) do
            (
                if HCS_findItem curve splineIndex == undefined do
                (
                    if (numKnots curve splineIndex) < 2 then throw "样条至少需要两个控制点。"
                    local firstTangent
                    in coordsys world firstTangent = lengthTangent curve splineIndex 0.0
                    firstTangent = HCE_safeNormalize firstTangent fallback:[0,1,0]
                    local seed = curve.objectTransform.row1
                    seed = seed - firstTangent*(dot seed firstTangent)
                    local fallbackSeed = if (abs (dot firstTangent [0,0,1])) < 0.95 then (cross [0,0,1] firstTangent) else (cross [1,0,0] firstTangent)
                    seed = HCE_safeNormalize seed fallback:(HCE_safeNormalize fallbackSeed fallback:[1,0,0])
                    local angles = for k = 1 to (numKnots curve splineIndex) collect 0.0
                    local widthScales = for k = 1 to (numKnots curve splineIndex) collect 1.0
                    local item = HCS_CardItem curve:curve splineIndex:splineIndex seedWidth:seed profileID:(HCS_newProfileID()) \
                        lengthSegments:HCS_LengthSegments widthSegments:HCS_WidthSegments cardWidth:HCS_CardWidth centerBulge:HCS_CenterBulge preventFolding:HCS_PreventFolding \
                        twistAngle:HCS_TwistAngle twistMode:HCS_TwistMode twistReverse:HCS_TwistReverse twistKnotRadius:HCS_TwistKnotRadius \
                        twistProfileMode:HCS_TwistProfileMode tailTwistAngle:HCS_TailTwistAngle wholeTwistAngle:HCS_WholeTwistAngle \
                        widthScale:HCS_WidthScale widthMode:HCS_WidthMode widthReverse:HCS_WidthReverse widthKnotRadius:HCS_WidthKnotRadius \
                        widthProfileMode:HCS_WidthProfileMode tailWidthScale:HCS_TailWidthScale wholeWidthScale:HCS_WholeWidthScale \
                        knotTwistAngles:angles knotWidthScales:widthScales
                    HCS_applyPendingGeneratorToItem item
                    append HCS_Items item
                    HCS_createGridMesh item
                    addedCount += 1
                )
            )
        )
        HCS_Active = HCS_Items.count > 0
        HCS_updateAll force:true
        HCS_setMeshesFrozen true
        HCS_persistAll()
        HCS_installHandlers()
        select curves
    )
    catch
    (
        -- Adding another spline must be transactional: a bad new source may be
        -- discarded, but cards that were already live stay intact and editable.
        while HCS_Items.count > previousCount do
        (
            local failedItem = HCS_Items[HCS_Items.count]
            if isValidNode failedItem.meshNode do delete failedItem.meshNode
            deleteItem HCS_Items HCS_Items.count
        )
        HCS_Active = previousActive and HCS_Items.count > 0
        if HCS_Active then
        (
            HCS_setMeshesFrozen true
            HCS_installHandlers()
        )
        else HCS_removeHandlers()
        throw()
    )
    addedCount
)

fn HCS_selectedKnotAngleInfo =
(
    local selectedCount = 0
    local firstAngle = undefined
    local mixedValues = false
    for item in HCS_Items where isValidNode item.curve and item.curve.isSelected do
    (
        HCS_ensureKnotAngles item
        local selectedKnots = getKnotSelection item.curve item.splineIndex
        for k = 1 to item.knotTwistAngles.count where (findItem selectedKnots k) != 0 do
        (
            local angle = item.knotTwistAngles[k]
            if firstAngle == undefined then firstAngle = angle
            else if (abs (angle - firstAngle)) > 0.0001 do mixedValues = true
            selectedCount += 1
        )
    )
    #(selectedCount, if firstAngle == undefined then 0.0 else firstAngle, mixedValues)
)

fn HCS_setSelectedKnotAngles angle =
(
    local changed = 0
    for item in HCS_Items where isValidNode item.curve and item.curve.isSelected do
    (
        HCS_ensureKnotAngles item
        local selectedKnots = getKnotSelection item.curve item.splineIndex
        for k = 1 to item.knotTwistAngles.count where (findItem selectedKnots k) != 0 do
        (
            item.knotTwistAngles[k] = angle
            changed += 1
        )
    )
    changed
)

fn HCS_selectedKnotWidthInfo =
(
    local selectedCount = 0
    local firstScale = undefined
    local mixedValues = false
    for item in HCS_Items where isValidNode item.curve and item.curve.isSelected do
    (
        HCS_ensureKnotWidthScales item
        local selectedKnots = getKnotSelection item.curve item.splineIndex
        for k = 1 to item.knotWidthScales.count where (findItem selectedKnots k) != 0 do
        (
            local scale = item.knotWidthScales[k]
            if firstScale == undefined then firstScale = scale
            else if (abs (scale - firstScale)) > 0.0001 do mixedValues = true
            selectedCount += 1
        )
    )
    #(selectedCount, if firstScale == undefined then 1.0 else firstScale, mixedValues)
)

fn HCS_setSelectedKnotWidthScales scale =
(
    local changed = 0
    scale = amax #(0.001, scale)
    for item in HCS_Items where isValidNode item.curve and item.curve.isSelected do
    (
        HCS_ensureKnotWidthScales item
        local selectedKnots = getKnotSelection item.curve item.splineIndex
        for k = 1 to item.knotWidthScales.count where (findItem selectedKnots k) != 0 do
        (
            item.knotWidthScales[k] = scale
            changed += 1
        )
    )
    changed
)

fn HCS_duplicateItems items =
(
    if not HCS_Active or items.count == 0 then return 0
    local previousCount = HCS_Items.count
    local sourceCurves = #()
    local clonedCurves = #()
    local clonedMeshes = #()
    try
    (
        for item in items where isValidNode item.curve and isValidNode item.meshNode do
        (
            local sourceIndex = findItem sourceCurves item.curve
            local newCurve
            if sourceIndex == 0 then
            (
                append sourceCurves item.curve
                newCurve = copy item.curve
                newCurve.name = uniqueName (item.curve.name + "_COPY")
                HCS_clearCurveProfileProps newCurve
                append clonedCurves newCurve
            )
            else newCurve = clonedCurves[sourceIndex]

            local newMesh = copy item.meshNode
            newMesh.name = uniqueName (item.meshNode.name + "_COPY")
            try (deleteUserProp newMesh HCS_MeshLinkKey) catch()
            append clonedMeshes newMesh

            local data = HCS_itemProfileData item
            data[2] = HCS_newProfileID()
            local newItem = HCS_itemFromProfileData newCurve item.splineIndex newMesh data
            if newItem == undefined then throw "复制参数档案失败。"
            if not (HCS_restoreCoordinatesFromUV newItem) then throw "复制面片的 UV/拓扑无法恢复。"
            append HCS_Items newItem
            HCS_persistItem newItem
        )
        HCS_updateAll force:true
        HCS_setMeshesFrozen true
        HCS_installHandlers()
        if clonedCurves.count > 0 do
        (
            select clonedCurves
            max modify mode
            subObjectLevel = 1
        )
    )
    catch
    (
        while HCS_Items.count > previousCount do deleteItem HCS_Items HCS_Items.count
        for node in clonedMeshes where isValidNode node do delete node
        for node in clonedCurves where isValidNode node do delete node
        HCS_installHandlers()
        throw()
    )
    HCS_Items.count - previousCount
)

fn HCS_finishItems items keepMeshes:true =
(
    if not HCS_Active or items.count == 0 then return 0
    if keepMeshes do HCS_updateAll force:true
    HCS_removeHandlers()
    for item in items do
    (
        HCS_clearItemPersistence item
        if isValidNode item.meshNode then
        (
            item.meshNode.isFrozen = false
            if not keepMeshes do delete item.meshNode
        )
    )
    local remaining = #()
    for item in HCS_Items where (findItem items item) == 0 do append remaining item
    HCS_Items = remaining
    HCS_Active = HCS_Items.count > 0
    if HCS_Active then
    (
        HCS_setMeshesFrozen true
        HCS_persistAll()
        HCS_installHandlers()
    )
    redrawViews()
    items.count
)

fn HCS_applyItems items = HCS_finishItems items keepMeshes:true
fn HCS_cancelItems items = HCS_finishItems items keepMeshes:false
fn HCS_applySession =
(
    local allItems = for item in HCS_Items collect item
    HCS_applyItems allItems
)
fn HCS_cancelSession =
(
    local allItems = for item in HCS_Items collect item
    HCS_cancelItems allItems
)

rollout HCS_TemplateRollout "自定义模板扫掠  v4.6.1 实验" width:350 height:292
(
    local syncing = false
    groupBox gbMode "生成模式" pos:[10,8] width:330 height:72
    radiobuttons rbGenerator labels:#("标准带状面片", "自定义模板扫掠") pos:[22,29] columns:2 default:1
    button btnApplyMode "把当前模式应用到选中实时面片" pos:[22,51] width:306 height:24

    groupBox gbTemplate "模板截面" pos:[10,88] width:330 height:154
    label lbHelp "模板长度方向必须沿其局部 X、Y 或 Z 轴。" pos:[22,109] width:306 height:18
    pickbutton pbTemplate "拾取几何模板" pos:[22,132] width:145 height:28 filter:HCS_isTemplateNode autoDisplay:false
    radiobuttons rbAxis labels:#("X 轴", "Y 轴", "Z 轴") pos:[178,136] columns:3 default:3
    button btnReadAgain "按当前轴重新读取模板" pos:[22,168] width:306 height:26
    label lbTemplateName "当前模板：未拾取" pos:[22,199] width:306 height:18
    label lbTemplateStats "截面：0 点 / 0 边" pos:[22,218] width:176 height:18
    checkbox chkCaps "闭合截面封口" pos:[207,216] width:121 height:20 checked:true

    label lbNote "模板只负责截面；长度段、宽度、旋转及局部点参数仍在主窗口调节。" pos:[12,251] width:326 height:34

    fn axisFromUI = case rbAxis.state of (1:#x; 2:#y; default:#z)

    fn updateInfo =
    (
        syncing = true
        rbGenerator.state = if HCS_GeneratorMode == #template then 2 else 1
        rbAxis.state = case HCS_TemplateAxis of (#x:1; #y:2; default:3)
        chkCaps.checked = HCS_TemplateCapEnds
        pbTemplate.text = if isValidNode HCS_TemplateNode then "重新拾取模板" else "拾取几何模板"
        lbTemplateName.text = "当前模板：" + (if HCS_TemplateName == "" then "未拾取" else HCS_TemplateName)
        lbTemplateStats.text = "截面：" + HCS_TemplateProfilePoints.count as string + " 点 / " + HCS_TemplateSpans.count as string + " 边"
        btnReadAgain.enabled = isValidNode HCS_TemplateNode
        syncing = false
    )

    fn readTemplate node =
    (
        local data = HCS_captureTemplateProfile node axis:(axisFromUI())
        HCS_setPendingTemplate data sourceNode:node
        rbGenerator.state = 2
        updateInfo()
        try (HCS_Rollout.syncGeneratorUI()) catch()
        data
    )

    on pbTemplate picked node do
    (
        try (readTemplate node)
        catch (messageBox ("无法读取模板：\n\n" + getCurrentException()) title:"自定义模板扫掠")
    )

    on rbAxis changed state do if not syncing and isValidNode HCS_TemplateNode do
    (
        try (readTemplate HCS_TemplateNode)
        catch (messageBox ("无法按所选轴读取：\n\n" + getCurrentException()) title:"自定义模板扫掠")
    )

    on btnReadAgain pressed do if isValidNode HCS_TemplateNode do
    (
        try (readTemplate HCS_TemplateNode)
        catch (messageBox ("无法重新读取模板：\n\n" + getCurrentException()) title:"自定义模板扫掠")
    )

    on rbGenerator changed state do if not syncing do
    (
        HCS_GeneratorMode = if state == 2 then #template else #ribbon
        try (HCS_Rollout.syncGeneratorUI()) catch()
    )

    on chkCaps changed state do if not syncing do HCS_TemplateCapEnds = state

    on btnApplyMode pressed do
    (
        try
        (
            HCS_GeneratorMode = if rbGenerator.state == 2 then #template else #ribbon
            if HCS_GeneratorMode == #template and (HCS_TemplateProfilePoints.count < 2 or HCS_TemplateSpans.count < 1) then
                throw "请先拾取一个有效模板。"
            local targets = HCS_selectedItems()
            if targets.count == 0 then
                messageBox "当前模式已作为新样条的生成模式保存。\n要转换已有实时面片，请先选中它的源样条。" title:"自定义模板扫掠"
            else
            (
                for item in targets do HCS_applyPendingGeneratorToItem item
                HCS_rebuildItems targets
            )
            try (HCS_Rollout.syncGeneratorUI()) catch()
        )
        catch (messageBox ("无法应用模板模式：\n\n" + getCurrentException()) title:"自定义模板扫掠")
    )

    on HCS_TemplateRollout open do
    (
        HCS_TemplateDialogOpen = true
        updateInfo()
    )
    on HCS_TemplateRollout close do HCS_TemplateDialogOpen = false
)

rollout HCS_Rollout "样条转多实时面片  v4.6.1 实验" width:370 height:870
(
    local syncing = false
    local widthSyncing = false
    local settingsSyncing = false
    local lastSelectionKey = ""
    groupBox gbSource "样条生成面片" pos:[10,8] width:350 height:112
    label lbSource1 "选择新样条生成；选择已有样条载入其独立参数。" pos:[22,29] width:326 height:18
    label lbLengthSegs "长度段（横线）：" pos:[22,54] width:106 height:18
    spinner spnLengthSegs "" pos:[130,51] width:97 height:18 range:[1,200,8] type:#integer
    label lbWidthSegs "宽度段（竖线）：" pos:[22,78] width:106 height:18
    spinner spnWidthSegs "" pos:[130,75] width:97 height:18 range:[1,20,1] type:#integer
    button btnGenerateCard "生成/重建选中" pos:[238,48] width:110 height:26
    button btnTemplateSettings "模板扫掠设置" pos:[238,78] width:110 height:26 toolTip:"实验功能：拾取圆管、方管、交叉面等模板截面"

    groupBox gbShape "面片参数" pos:[10,128] width:350 height:105
    label lbCardWidth "面片宽度：" pos:[22,154] width:80 height:18
    spinner spnWidth "" pos:[104,151] width:128 height:18 range:[0.001,100000.0,10.0] type:#worldunits scale:0.1
    label lbCenterBulge "中线凸起：" pos:[22,180] width:80 height:18
    spinner spnBulge "" pos:[104,177] width:128 height:18 range:[-100000.0,100000.0,0.0] type:#worldunits scale:0.1
    label lbBulge "宽度段 ≥ 2 时显示" pos:[238,179] width:110 height:18
    checkbox chkLive "实时跟随" pos:[22,205] width:100 height:18 checked:true
    checkbox chkPreventFold "防止急弯折叠" pos:[125,205] width:120 height:18 checked:true
    button btnRefresh "立即刷新" pos:[250,201] width:98 height:26

    groupBox gbCardTwist "面片旋转校正" pos:[10,241] width:350 height:170
    radiobuttons rbMode labels:#("尾部渐变", "整条统一", "选中点局部") pos:[22,265] columns:3 default:1
    label lbAngle "旋转角度：" pos:[22,296] width:80 height:18
    spinner spnAngle "" pos:[104,293] width:123 height:18 range:[-180.0,180.0,0.0] type:#float scale:1.0
    checkbutton btnReverse "首尾反向" pos:[238,291] width:110 height:26
    label lbRange "点影响范围：" pos:[22,326] width:80 height:18
    spinner spnRange "" pos:[104,323] width:123 height:18 range:[0.25,3.0,1.0] type:#float scale:0.25
    label lbRangeUnit "相邻间距倍率" pos:[238,326] width:110 height:18
    button btnReset "旋转归零" pos:[22,355] width:100 height:28
    label lbTwistInfo "尾部、整条和局部点会叠加生效。" pos:[132,355] width:216 height:42

    groupBox gbWidthChange "面片宽度变化" pos:[10,419] width:350 height:170
    radiobuttons rbWidthMode labels:#("尾部渐变", "整条倍率", "选中点局部") pos:[22,443] columns:3 default:1
    label lbWidthScale "宽度倍率：" pos:[22,474] width:80 height:18
    spinner spnWidthScale "" pos:[104,471] width:123 height:18 range:[0.01,10.0,1.0] type:#float scale:0.05
    checkbutton btnWidthReverse "首尾反向" pos:[238,469] width:110 height:26
    label lbWidthRange "点影响范围：" pos:[22,504] width:80 height:18
    spinner spnWidthRange "" pos:[104,501] width:123 height:18 range:[0.25,3.0,1.0] type:#float scale:0.25
    label lbWidthRangeUnit "相邻间距倍率" pos:[238,504] width:110 height:18
    button btnWidthReset "宽度归一" pos:[22,533] width:100 height:28
    label lbWidthInfo "尾部、整条和局部点会叠加生效。" pos:[132,533] width:216 height:42

    groupBox gbActions "完成 / 复制" pos:[10,597] width:350 height:174
    button btnDuplicate "复制选中样条 + 面片" pos:[22,622] width:326 height:30
    button btnSelectSpline "选择全部源样条" pos:[22,659] width:158 height:30
    button btnSelectMesh "解冻并选择面片" pos:[190,659] width:158 height:30
    button btnApplySelected "应用选中面片" pos:[22,696] width:158 height:30
    button btnCancelSelected "取消选中面片" pos:[190,696] width:158 height:30
    button btnApply "应用全部面片" pos:[22,733] width:158 height:30
    button btnCancel "取消全部面片" pos:[190,733] width:158 height:30

    label lbUV "UV：U=宽度 0–1，V=长度 0–1，自动拉直铺满。" pos:[12,785] width:346 height:20
    label lbStatus "状态：请选择样条并生成面片。" pos:[12,812] width:346 height:42
    timer liveTimer interval:50 active:false

    fn setActiveUI state =
    (
        btnApply.enabled = state
        btnCancel.enabled = state
        btnApplySelected.enabled = state
        btnCancelSelected.enabled = state
        btnDuplicate.enabled = state
        btnSelectSpline.enabled = state
        btnSelectMesh.enabled = state
        btnRefresh.enabled = state
        liveTimer.active = state
    )

    fn syncGeneratorUI =
    (
        local customMode = HCS_GeneratorMode == #template
        spnWidthSegs.enabled = not customMode
        spnBulge.enabled = not customMode
        lbBulge.text = if customMode then "模板模式不使用" else "宽度段 ≥ 2 时显示"
        btnTemplateSettings.text = if customMode then "模板扫掠（开）" else "模板扫掠设置"
        customMode
    )

    fn selectionContextKey targets =
    (
        if targets.count == 0 then return "none"
        local key = ""
        for item in targets do
        (
            local handle = try (getHandleByAnim item.curve) catch (0)
            key += handle as string + ":" + item.splineIndex as string + ";"
        )
        key
    )

    fn syncSettingsFromSelection force:false announce:true =
    (
        local targets = HCS_selectedItems()
        local key = selectionContextKey targets
        if targets.count > 0 then
        (
            -- While the template picker is open, keep its pending template
            -- intact. The 50 ms selection poll must not overwrite it with the
            -- currently selected item's old generator profile before Apply.
            if not HCS_TemplateDialogOpen do HCS_loadItemSettings targets[1]
            if force or key != lastSelectionKey do
            (
                settingsSyncing = true
                syncing = true
                widthSyncing = true
                spnLengthSegs.value = HCS_LengthSegments
                spnWidthSegs.value = HCS_WidthSegments
                spnWidth.value = HCS_CardWidth
                spnBulge.value = HCS_CenterBulge
                chkPreventFold.checked = HCS_PreventFolding
                rbMode.state = case HCS_TwistMode of (#tail:1; #whole:2; #knots:3; default:1)
                spnAngle.value = HCS_TwistAngle
                btnReverse.checked = HCS_TwistReverse
                spnRange.value = HCS_TwistKnotRadius
                rbWidthMode.state = case HCS_WidthMode of (#tail:1; #whole:2; #knots:3; default:1)
                spnWidthScale.value = HCS_WidthScale
                btnWidthReverse.checked = HCS_WidthReverse
                spnWidthRange.value = HCS_WidthKnotRadius
                widthSyncing = false
                syncing = false
                settingsSyncing = false
                lastSelectionKey = key
                btnReverse.enabled = rbMode.state == 1
                spnRange.enabled = rbMode.state == 3
                btnWidthReverse.enabled = rbWidthMode.state == 1
                spnWidthRange.enabled = rbWidthMode.state == 3
                syncGeneratorUI()
                if announce do
                (
                    if targets.count == 1 then
                        lbStatus.text = "状态：已载入 " + targets[1].curve.name + " 的独立面片参数。"
                    else
                        lbStatus.text = "状态：已选择 " + targets.count as string + " 个面片参数组；修改将批量应用。"
                )
            )
        )
        else if force or key != lastSelectionKey do
        (
            lastSelectionKey = key
            if announce and HCS_Active do lbStatus.text = "状态：请选择已有源样条，或选择新样条后点击生成。"
        )
        targets
    )

    fn syncKnotUI =
    (
        if HCS_Active and rbMode.state == 3 then
        (
            local info = HCS_selectedKnotAngleInfo()
            spnAngle.enabled = info[1] > 0
            btnReset.enabled = info[1] > 0
            btnReset.text = "选中点归零"
            if info[1] == 0 then lbTwistInfo.text = "请选择一个或多个样条控制点。"
            else if info[3] then lbTwistInfo.text = "已选 " + info[1] as string + " 点，数值不同；输入后统一赋值。"
            else
            (
                if (abs (spnAngle.value - info[2])) > 0.0001 do
                (
                    syncing = true
                    spnAngle.value = info[2]
                    syncing = false
                )
                lbTwistInfo.text = "已选 " + info[1] as string + " 点，当前 " + (formattedPrint info[2] format:".1f") + "°。"
            )
        )
        else
        (
            spnAngle.enabled = true
            btnReset.enabled = true
            btnReset.text = "旋转归零"
            if (abs (spnAngle.value - HCS_TwistAngle)) > 0.0001 do
            (
                syncing = true
                spnAngle.value = HCS_TwistAngle
                syncing = false
            )
            lbTwistInfo.text = "尾部、整条和局部点会叠加生效。"
        )
    )

    fn syncKnotWidthUI =
    (
        if HCS_Active and rbWidthMode.state == 3 then
        (
            local info = HCS_selectedKnotWidthInfo()
            spnWidthScale.enabled = info[1] > 0
            btnWidthReset.enabled = info[1] > 0
            btnWidthReset.text = "选中点归一"
            if info[1] == 0 then lbWidthInfo.text = "请选择一个或多个样条控制点。"
            else if info[3] then lbWidthInfo.text = "已选 " + info[1] as string + " 点，倍率不同；输入后统一赋值。"
            else
            (
                if (abs (spnWidthScale.value - info[2])) > 0.0001 do
                (
                    widthSyncing = true
                    spnWidthScale.value = info[2]
                    widthSyncing = false
                )
                lbWidthInfo.text = "已选 " + info[1] as string + " 点，当前倍率 " + (formattedPrint info[2] format:".2f") + "。"
            )
        )
        else
        (
            spnWidthScale.enabled = true
            btnWidthReset.enabled = true
            btnWidthReset.text = "宽度归一"
            if (abs (spnWidthScale.value - HCS_WidthScale)) > 0.0001 do
            (
                widthSyncing = true
                spnWidthScale.value = HCS_WidthScale
                widthSyncing = false
            )
            lbWidthInfo.text = "尾部、整条和局部点会叠加生效。"
        )
    )

    fn updateSettings rebuild:false writeAngle:false writeWidth:false field:#all =
    (
        if settingsSyncing then return false
        HCS_LengthSegments = spnLengthSegs.value
        HCS_WidthSegments = spnWidthSegs.value
        HCS_CardWidth = spnWidth.value
        HCS_CenterBulge = spnBulge.value
        HCS_PreventFolding = chkPreventFold.checked
        local twistEditMode = case rbMode.state of (1:#tail; 2:#whole; 3:#knots)
        HCS_setTwistEditMode twistEditMode
        HCS_TwistReverse = btnReverse.checked
        HCS_TwistKnotRadius = spnRange.value
        local widthEditMode = case rbWidthMode.state of (1:#tail; 2:#whole; 3:#knots)
        HCS_setWidthEditMode widthEditMode
        HCS_WidthReverse = btnWidthReverse.checked
        HCS_WidthKnotRadius = spnWidthRange.value
        if writeAngle and not syncing do
        (
            if HCS_TwistMode == #knots then HCS_setSelectedKnotAngles spnAngle.value
            else HCS_setCurrentTwistProfileAngle spnAngle.value
        )
        if writeWidth and not widthSyncing do
        (
            if HCS_WidthMode == #knots then HCS_setSelectedKnotWidthScales spnWidthScale.value
            else HCS_setCurrentWidthProfileScale spnWidthScale.value
        )
        local targets = HCS_selectedItems()
        for item in targets do
        (
            case field of
            (
                #lengthSegments: item.lengthSegments = HCS_LengthSegments
                #widthSegments: item.widthSegments = HCS_WidthSegments
                #cardWidth: item.cardWidth = HCS_CardWidth
                #centerBulge: item.centerBulge = HCS_CenterBulge
                #preventFolding: item.preventFolding = HCS_PreventFolding
                #twistMode:
                (
                    item.twistMode = twistEditMode
                    if twistEditMode == #tail then
                    (
                        item.twistProfileMode = #tail
                        item.twistAngle = item.tailTwistAngle
                    )
                    else if twistEditMode == #whole then
                    (
                        item.twistProfileMode = #whole
                        item.twistAngle = item.wholeTwistAngle
                    )
                )
                #twistAngle:
                (
                    item.twistMode = twistEditMode
                    if twistEditMode == #tail then
                    (
                        item.twistProfileMode = #tail
                        item.twistAngle = spnAngle.value
                        item.tailTwistAngle = spnAngle.value
                    )
                    else if twistEditMode == #whole then
                    (
                        item.twistProfileMode = #whole
                        item.twistAngle = spnAngle.value
                        item.wholeTwistAngle = spnAngle.value
                    )
                )
                #twistRange: item.twistKnotRadius = HCS_TwistKnotRadius
                #twistReverse: item.twistReverse = HCS_TwistReverse
                #widthMode:
                (
                    item.widthMode = widthEditMode
                    if widthEditMode == #tail then
                    (
                        item.widthProfileMode = #tail
                        item.widthScale = item.tailWidthScale
                    )
                    else if widthEditMode == #whole then
                    (
                        item.widthProfileMode = #whole
                        item.widthScale = item.wholeWidthScale
                    )
                )
                #widthScale:
                (
                    item.widthMode = widthEditMode
                    if widthEditMode == #tail then
                    (
                        item.widthProfileMode = #tail
                        item.widthScale = spnWidthScale.value
                        item.tailWidthScale = spnWidthScale.value
                    )
                    else if widthEditMode == #whole then
                    (
                        item.widthProfileMode = #whole
                        item.widthScale = spnWidthScale.value
                        item.wholeWidthScale = spnWidthScale.value
                    )
                )
                #widthRange: item.widthKnotRadius = HCS_WidthKnotRadius
                #widthReverse: item.widthReverse = HCS_WidthReverse
                default: HCS_saveSettingsToItem item
            )
        )
        btnReverse.enabled = rbMode.state == 1
        spnRange.enabled = rbMode.state == 3
        btnWidthReverse.enabled = rbWidthMode.state == 1
        spnWidthRange.enabled = rbWidthMode.state == 3
        if HCS_Active and targets.count > 0 do
        (
            if rebuild then HCS_rebuildItems targets else HCS_updateAll force:true
        )
        for item in targets do HCS_persistItem item
        syncKnotUI()
        syncKnotWidthUI()
        true
    )

    on btnGenerateCard pressed do
    (
        try
        (
            local existingTargets = HCS_selectedItems()
            if existingTargets.count > 0 then HCS_rebuildItems existingTargets else updateSettings()
            local addedCount = HCS_generateFromSelection()
            setActiveUI HCS_Active
            syncSettingsFromSelection force:true announce:false
            syncKnotUI()
            syncKnotWidthUI()
            if addedCount > 0 and existingTargets.count > 0 then
                lbStatus.text = "状态：新增 " + addedCount as string + " 根并重建 " + existingTargets.count as string + " 根面片。"
            else if addedCount > 0 then
                lbStatus.text = "状态：已新增并冻结 " + addedCount as string + " 根实时面片。"
            else
                lbStatus.text = "状态：已重建选中的 " + existingTargets.count as string + " 根实时面片。"
        )
        catch
        (
            messageBox ("无法生成面片：\n\n" + getCurrentException()) title:"样条转面片"
            lbStatus.text = "状态：生成失败。"
        )
    )

    on btnTemplateSettings pressed do
    (
        syncSettingsFromSelection force:true announce:false
        try (destroyDialog HCS_TemplateRollout) catch()
        createDialog HCS_TemplateRollout style:#(#style_titlebar, #style_sysmenu, #style_toolwindow)
    )

    on spnLengthSegs changed value do if not settingsSyncing and HCS_Active do updateSettings rebuild:true field:#lengthSegments
    on spnWidthSegs changed value do if not settingsSyncing and HCS_Active do updateSettings rebuild:true field:#widthSegments
    on spnWidth changed value do if not settingsSyncing do updateSettings field:#cardWidth
    on spnBulge changed value do if not settingsSyncing do updateSettings field:#centerBulge
    on rbMode changed state do if not settingsSyncing do updateSettings field:#twistMode
    on spnAngle changed value do if not settingsSyncing and not syncing do updateSettings writeAngle:true field:#twistAngle
    on spnRange changed value do if not settingsSyncing do updateSettings field:#twistRange
    on btnReverse changed state do if not settingsSyncing do updateSettings field:#twistReverse
    on rbWidthMode changed state do if not settingsSyncing do updateSettings field:#widthMode
    on spnWidthScale changed value do if not settingsSyncing and not widthSyncing do updateSettings writeWidth:true field:#widthScale
    on spnWidthRange changed value do if not settingsSyncing do updateSettings field:#widthRange
    on btnWidthReverse changed state do if not settingsSyncing do updateSettings field:#widthReverse

    on btnReset pressed do
    (
        syncing = true
        spnAngle.value = 0.0
        syncing = false
        updateSettings writeAngle:true field:#twistAngle
    )

    on btnWidthReset pressed do
    (
        widthSyncing = true
        spnWidthScale.value = 1.0
        widthSyncing = false
        updateSettings writeWidth:true field:#widthScale
    )

    on chkLive changed state do
    (
        HCS_LiveEnabled = state
        if state and HCS_Active do HCS_updateAll force:true
    )
    on chkPreventFold changed state do if not settingsSyncing do updateSettings field:#preventFolding
    on btnRefresh pressed do if HCS_Active do
    (
        HCS_LiveDirty = false
        HCS_updateAll force:true
    )
    on liveTimer tick do
    (
        if HCS_Active and chkLive.checked do HCS_flushLiveUpdate()
        if HCS_Active do
        (
            syncSettingsFromSelection()
            syncKnotUI()
            syncKnotWidthUI()
        )
    )
    on btnSelectSpline pressed do
    (
        HCS_setMeshesFrozen true
        local nodes = #()
        for item in HCS_Items where isValidNode item.curve do HCE_addUnique nodes item.curve
        if nodes.count > 0 do
        (
            select nodes
            max modify mode
            subObjectLevel = 1
            syncSettingsFromSelection force:true announce:false
            syncKnotUI()
            syncKnotWidthUI()
            lbStatus.text = "状态：面片已重新冻结，正在编辑源样条。"
        )
    )
    on btnSelectMesh pressed do
    (
        HCS_setMeshesFrozen false
        local nodes = for item in HCS_Items where isValidNode item.meshNode collect item.meshNode
        if nodes.count > 0 do
        (
            select nodes
            lbStatus.text = "状态：生成面片已解冻并选中。"
        )
    )

    on btnDuplicate pressed do
    (
        try
        (
            local targets = HCS_selectedItems includeMeshes:true
            if targets.count == 0 then lbStatus.text = "状态：请先选择要复制的源样条。"
            else
            (
                local count = HCS_duplicateItems targets
                syncSettingsFromSelection force:true announce:false
                lbStatus.text = "状态：已复制 " + count as string + " 组样条与实时面片，全部参数已保留。"
            )
        )
        catch
        (
            messageBox ("无法复制：\n\n" + getCurrentException()) title:"复制样条与面片"
            lbStatus.text = "状态：复制失败，原有面片未改变。"
        )
    )

    on btnApplySelected pressed do
    (
        local targets = HCS_selectedItems includeMeshes:true
        if targets.count == 0 then lbStatus.text = "状态：请先选择要应用的源样条或面片。"
        else
        (
            local count = HCS_applyItems targets
            setActiveUI HCS_Active
            lastSelectionKey = ""
            if HCS_Active then syncSettingsFromSelection force:true announce:false
            lbStatus.text = "状态：已单独应用并解冻 " + count as string + " 根面片；其他面片继续实时编辑。"
        )
    )

    on btnCancelSelected pressed do
    (
        local targets = HCS_selectedItems includeMeshes:true
        if targets.count == 0 then lbStatus.text = "状态：请先选择要取消的源样条或面片。"
        else
        (
            local count = HCS_cancelItems targets
            setActiveUI HCS_Active
            lastSelectionKey = ""
            if HCS_Active then syncSettingsFromSelection force:true announce:false
            lbStatus.text = "状态：已单独取消并删除 " + count as string + " 根面片；其他面片继续实时编辑。"
        )
    )

    on btnApply pressed do
    (
        local count = HCS_applySession()
        setActiveUI false
        lbStatus.text = "状态：已应用并解冻 " + count as string + " 根面片。"
    )
    on btnCancel pressed do
    (
        HCS_cancelSession()
        setActiveUI false
        lbStatus.text = "状态：已取消并删除生成面片。"
    )
    on HCS_Rollout open do
    (
        local restoredCount = if HCS_Active then HCS_Items.count else HCS_restorePersistentSession()
        if HCS_Active do HCS_installHandlers()
        setActiveUI HCS_Active
        if HCS_Active do
        (
            HCS_updateAll force:true
            syncSettingsFromSelection force:true
            syncKnotUI()
            syncKnotWidthUI()
            if (HCS_selectedItems()).count == 0 do lbStatus.text = "状态：已从 MAX 场景恢复 " + restoredCount as string + " 根实时面片，请选择源样条继续。"
        )
        syncGeneratorUI()
    )
    on HCS_Rollout close do
    (
        liveTimer.active = false
        try (destroyDialog HCS_TemplateRollout) catch()
        if HCS_Active do HCS_persistAll()
        HCS_removeHandlers()
    )
)

rollout HCE_V4Launcher "头发插件  v4.6.2 实验" width:300 height:150
(
    label lbTitle "请选择工作模式" pos:[20,16] width:260 height:22 align:#center
    button btnCardToSpline "面片 → 样条控制 / 顺线工具" pos:[20,46] width:260 height:36
    button btnSplineToCard "样条 → 实时面片生成" pos:[20,92] width:260 height:36
    on btnCardToSpline pressed do
    (
        try (destroyDialog HCS_TemplateRollout) catch()
        try (destroyDialog HCE_Rollout) catch()
        createDialog HCE_Rollout style:#(#style_titlebar, #style_sysmenu, #style_toolwindow)
    )
    on btnSplineToCard pressed do
    (
        try (destroyDialog HCE_GuideRollout) catch()
        try (destroyDialog HCS_Rollout) catch()
        HCS_restorePersistentSession force:true
        createDialog HCS_Rollout style:#(#style_titlebar, #style_sysmenu, #style_toolwindow)
    )
)

fn HCT_Open =
(
    try (destroyDialog HCE_V4Launcher) catch()
    createDialog HCE_V4Launcher style:#(#style_titlebar, #style_sysmenu, #style_toolwindow)
)

macroScript HairCardToolkit
category:"JXTools"
toolTip:"头发插件"
buttonText:"头发插件"
(
    on execute do HCT_Open()
)
