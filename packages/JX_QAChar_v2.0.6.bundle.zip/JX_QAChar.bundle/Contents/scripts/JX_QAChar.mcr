/*
	JX QA Character Tool
	Version 2.0.6

	Character model naming, unit, pivot, scale, normal, UV and vertex alpha checks for 3ds Max.
*/

global JX_QACharVersion = "2.0.6"
global JXCharQATool
global ModelCheckerTool
global JX_SkinnedRepairCore
global JX_QACharCoreLoadError
global JX_QAPearlCountDialog
global JX_QAPearlExpectedCount
global JX_QAPearlMapAppDataID = 1247305026
global JX_QAChar_CreateHiddenBackup

JX_QACharCoreLoadError = undefined
if JX_SkinnedRepairCore == undefined do
(
	local sourcePath = try (getSourceFileName()) catch (undefined)
	local scriptRoot = if sourcePath == undefined then "" else getFilenamePath sourcePath
	local corePath = scriptRoot + "JX_SkinnedRepairCore.ms"

	if scriptRoot == "" then
		JX_QACharCoreLoadError = "无法确定插件脚本目录"
	else if not doesFileExist corePath then
		JX_QACharCoreLoadError = "缺少核心脚本：" + corePath
	else
	(
		try
			(fileIn corePath quiet:false)
		catch
			(JX_QACharCoreLoadError = getCurrentException())
	)

	if JX_SkinnedRepairCore == undefined and JX_QACharCoreLoadError == undefined do
		JX_QACharCoreLoadError = "核心脚本执行后未完成初始化"
)

struct JX_QAPearlMapMarker
(
	valid = false,
	schemaVersion = 0,
	algorithmVersion = 0,
	state = #unknown,
	uvChannel = 4,
	collapseEpsilon = 0.001,
	materialIDs = #(),
	vertexCount = 0,
	faceCount = 0,
	topologySignature = "",
	source = "",
	splitVertexCount = 0,
	raw = ""
)

struct JX_QAPearlMapInspection
(
	node,
	status = #none,
	message = "",
	repairable = false,
	baseKind = #unsupported,
	baseObject,
	target,
	uvChannel = 4,
	collapseEpsilon = 0.001,
	materialIDs = #(),
	targetFaces = #{},
	elements = #(),
	elementStates = #(),
	offsetsByVertex = #(),
	processedElementCount = 0,
	restoredElementCount = 0,
	sharedBoundaryVertexCount = 0,
	marker,
	elapsedMs = 0
)

struct JX_QATransformInspection
(
	node,
	status = #blocked,
	skinCount = 0,
	needsScale = false,
	needsRotation = false,
	needsPivot = false,
	needsFlip = false,
	hasLegacyHelpers = false,
	businessModifiers = #(),
	blockers = #(),
	warnings = #(),
	detailReport = "",
	coreAnalysis,
	skinReferenceFrame = 0,
	skinVertexCount = 0,
	skinBoneCount = 0,
	instanceCount = 1,
	bindTransformSignature = ""
)

struct JX_QATransformCacheEntry
(
	nodeHandle = "",
	forceFlip = false,
	signature = "",
	inspection
)

try (destroyDialog JX_QAPearlCountDialog) catch ()

rollout JX_QAPearlCountDialog "珍珠数量确认" width:330 height:132
(
	label lbl_prompt "当前选择中应该有几个使用 _MBB 材质的模型？" pos:[16,14] width:298 height:18
	radiobuttons rb_expected labels:#("0", "1", "2", "3", "4", "5", "6") columns:7 default:1 pos:[22,44]
	button btn_confirm "确认" pos:[76,86] width:80 height:28
	button btn_cancel "取消" pos:[174,86] width:80 height:28

	on btn_confirm pressed do
	(
		JX_QAPearlExpectedCount = rb_expected.state - 1
		destroyDialog JX_QAPearlCountDialog
	)

	on btn_cancel pressed do
	(
		JX_QAPearlExpectedCount = undefined
		destroyDialog JX_QAPearlCountDialog
	)
)

fn JX_QAChar_RequestExpectedPearlCount =
(
	JX_QAPearlExpectedCount = undefined
	try (destroyDialog JX_QAPearlCountDialog) catch ()
	createDialog JX_QAPearlCountDialog 330 132 modal:true
	JX_QAPearlExpectedCount
)

struct JXCharQA
(
	-- 首字母大写函数
	fn capitalizeFirstLetter str =
	(
		if str.count > 0 then
		(
			local firstChar = toUpper str[1]
			local restChars = if str.count > 1 then substring str 2 -1 else ""
			return firstChar + restChars
		)
		else
		(
			return str
		)
	),
	-- 处理下划线后的大写转换
	fn formatUnderscoreString str =
	(
		local parts = filterString str "_"
		local result = ""
		
		for i = 1 to parts.count do
		(
			if i == 1 then
			(
				result += parts[i]
			)
			else
			(
				result += "_" + capitalizeFirstLetter parts[i]
			)
		)
		return result
	),
	fn lowercase instring = (
		local upper, lower, outstring
		upper = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
		lower = "abcdefghijklmnopqrstuvwxyz"
		outstring = copy instring
		for i = 1 to outstring.count do 
		(
			j = findString upper outstring[i]
			if (j != undefined) do outstring[i] = lower[j]
		)
		return outstring
	),

	namingBacks = #("_body", "_hair", "_head", "_skin")
)

JXCharQATool = JXCharQA()

-- 将三角面索引转换为普通数组
fn JX_QAChar_Point3IndicesToArray indices =
(
	#((indices.x as integer), (indices.y as integer), (indices.z as integer))
)

-- 返回 #(#poly|#mesh|#unsupported, baseObject, meshCopy)
fn JX_QAChar_GetAlphaBaseData obj =
(
	local baseObj = try (obj.baseObject) catch (undefined)
	if baseObj == undefined then return #(#unsupported, undefined, undefined)

	if isKindOf baseObj Editable_Poly then
		#(#poly, baseObj, undefined)
	else if isKindOf baseObj Editable_mesh then
		#(#mesh, baseObj, baseObj.mesh)
	else
		#(#unsupported, baseObj, undefined)
)

-- 分析结果：
-- #(#unsupported|#none|#valid|#shared|#invalid,
--   Alpha顶点数, 跨点共享Alpha数, 受影响几何点数, 说明)
fn JX_QAChar_AnalyzeAlphaObject obj =
(
	local baseData = JX_QAChar_GetAlphaBaseData obj
	local baseKind = baseData[1]
	if baseKind == #unsupported then
		return #(#unsupported, 0, 0, 0, "底层对象不是可编辑多边形或可编辑网格")

	local target = if baseKind == #poly then baseData[2] else baseData[3]
	local hasAlpha = try
	(
		if baseKind == #poly then
			polyop.getMapSupport target -2
		else
			meshop.getMapSupport target -2
	)
	catch (false)

	if not hasAlpha then return #(#none, 0, 0, 0, "未使用 -2:Alpha 通道")

	local geomFaceCount = if baseKind == #poly then
		polyop.getNumFaces target
	else
		target.numfaces
	local alphaVertCount = if baseKind == #poly then
		polyop.getNumMapVerts target -2
	else
		meshop.getNumMapVerts target -2
	local alphaFaceCount = if baseKind == #poly then
		polyop.getNumMapFaces target -2
	else
		meshop.getNumMapFaces target -2

	if alphaVertCount == 0 then return #(#none, 0, 0, 0, "-2:Alpha 通道为空")
	if alphaFaceCount != geomFaceCount then
		return #(#invalid, alphaVertCount, 0, 0,
			("Alpha面数 " + alphaFaceCount as string + " 与几何面数 " + geomFaceCount as string + " 不一致"))

	local ownerByAlpha = for i = 1 to alphaVertCount collect 0
	local sharedAlpha = #{}
	local affectedGeomVerts = #{}

	for faceIndex = 1 to geomFaceCount do
	(
		local geomFace = try
		(
			if baseKind == #poly then
				polyop.getFaceVerts target faceIndex
			else
				JX_QAChar_Point3IndicesToArray (getFace target faceIndex)
		)
		catch (undefined)
		local alphaFace = try
		(
			if baseKind == #poly then
				polyop.getMapFace target -2 faceIndex
			else
				JX_QAChar_Point3IndicesToArray (meshop.getMapFace target -2 faceIndex)
		)
		catch (undefined)

		if geomFace == undefined or alphaFace == undefined then
			return #(#invalid, alphaVertCount, 0, 0, ("无法读取第 " + faceIndex as string + " 个面的Alpha数据"))
		if geomFace.count != alphaFace.count then
			return #(#invalid, alphaVertCount, 0, 0, ("第 " + faceIndex as string + " 个面的Alpha面角数不一致"))

		for cornerIndex = 1 to geomFace.count do
		(
			local geomVertID = geomFace[cornerIndex] as integer
			local alphaVertID = alphaFace[cornerIndex] as integer

			if alphaVertID < 1 or alphaVertID > alphaVertCount then
				return #(#invalid, alphaVertCount, 0, 0,
					("第 " + faceIndex as string + " 个面包含越界Alpha索引 " + alphaVertID as string))

			if ownerByAlpha[alphaVertID] == 0 then
				ownerByAlpha[alphaVertID] = geomVertID
			else if ownerByAlpha[alphaVertID] != geomVertID then
			(
				sharedAlpha[alphaVertID] = true
				affectedGeomVerts[ownerByAlpha[alphaVertID]] = true
				affectedGeomVerts[geomVertID] = true
			)
		)
	)

	if sharedAlpha.numberSet > 0 then
		#(#shared, alphaVertCount, sharedAlpha.numberSet, affectedGeomVerts.numberSet, "存在跨几何顶点共享")
	else
		#(#valid, alphaVertCount, 0, 0, "Alpha索引关系正常")
)

fn JX_QAChar_WriteAlphaChannelData baseKind target alphaValues alphaFaces =
(
	if baseKind == #poly then
	(
		polyop.setNumMapVerts target -2 alphaValues.count keep:false
		for alphaIndex = 1 to alphaValues.count do
			polyop.setMapVert target -2 alphaIndex alphaValues[alphaIndex]
		for faceIndex = 1 to alphaFaces.count do
			polyop.setMapFace target -2 faceIndex alphaFaces[faceIndex]
	)
	else
	(
		meshop.setNumMapVerts target -2 alphaValues.count keep:false
		for alphaIndex = 1 to alphaValues.count do
			meshop.setMapVert target -2 alphaIndex alphaValues[alphaIndex]
		for faceIndex = 1 to alphaFaces.count do
		(
			local alphaFace = alphaFaces[faceIndex]
			meshop.setMapFace target -2 faceIndex [alphaFace[1], alphaFace[2], alphaFace[3]]
		)
		update target
	)
)

-- 将指定对象的 -2:Alpha 按“旧Alpha索引 + 几何顶点索引”最小拆分。
-- 返回 #(成功, 旧Alpha顶点数, 新Alpha顶点数, 说明)
fn JX_QAChar_RepairAlphaObject obj =
(
	local analysis = JX_QAChar_AnalyzeAlphaObject obj
	if analysis[1] == #unsupported then return #(false, 0, 0, analysis[5])
	if analysis[1] == #none then return #(true, 0, 0, "未使用Alpha通道，无需修复")
	if analysis[1] == #valid then return #(true, analysis[2], analysis[2], "索引关系正常，无需修复")
	if analysis[1] == #invalid then return #(false, analysis[2], analysis[2], ("结构损坏，未自动处理: " + analysis[5]))

	local baseData = JX_QAChar_GetAlphaBaseData obj
	local baseKind = baseData[1]
	local baseObj = baseData[2]
	local target = if baseKind == #poly then baseObj else baseData[3]
	local faceCount = if baseKind == #poly then polyop.getNumFaces target else target.numfaces
	local oldAlphaVertCount = analysis[2]
	local ownerLists = for i = 1 to oldAlphaVertCount collect #()
	local ownerNewIDs = for i = 1 to oldAlphaVertCount collect #()
	local oldAlphaValues = for i = 1 to oldAlphaVertCount collect
		(if baseKind == #poly then polyop.getMapVert target -2 i else meshop.getMapVert target -2 i)
	local oldAlphaFaces = #()
	local newAlphaValues = #()
	local newAlphaFaces = #()
	local originalMesh = if baseKind == #mesh then copy target else undefined

	for faceIndex = 1 to faceCount do
	(
		local geomFace = if baseKind == #poly then
			polyop.getFaceVerts target faceIndex
		else
			JX_QAChar_Point3IndicesToArray (getFace target faceIndex)
		local oldAlphaFace = if baseKind == #poly then
			polyop.getMapFace target -2 faceIndex
		else
			JX_QAChar_Point3IndicesToArray (meshop.getMapFace target -2 faceIndex)
		local newAlphaFace = #()
		append oldAlphaFaces oldAlphaFace

		for cornerIndex = 1 to geomFace.count do
		(
			local geomVertID = geomFace[cornerIndex] as integer
			local oldAlphaVertID = oldAlphaFace[cornerIndex] as integer
			local ownerPos = findItem ownerLists[oldAlphaVertID] geomVertID
			local newAlphaVertID = 0

			if ownerPos == 0 then
			(
				append ownerLists[oldAlphaVertID] geomVertID
				newAlphaVertID = newAlphaValues.count + 1
				append ownerNewIDs[oldAlphaVertID] newAlphaVertID
				append newAlphaValues oldAlphaValues[oldAlphaVertID]
			)
			else
				newAlphaVertID = ownerNewIDs[oldAlphaVertID][ownerPos]

			append newAlphaFace newAlphaVertID
		)

		append newAlphaFaces newAlphaFace
	)

	local repairSucceeded = false
	local repairMessage = ""

	try
	(
		undo "安全修复顶点Alpha" on
		(
			JX_QAChar_WriteAlphaChannelData baseKind target newAlphaValues newAlphaFaces
			if baseKind == #mesh then baseObj.mesh = target
			update obj
		)

		local verifyResult = JX_QAChar_AnalyzeAlphaObject obj
		if verifyResult[1] == #valid then
		(
			repairSucceeded = true
			repairMessage = "跨点共享已解除"
		)
		else
		(
			repairMessage = ("修复后复查未通过: " + verifyResult[5])
			if baseKind == #poly then
				JX_QAChar_WriteAlphaChannelData baseKind target oldAlphaValues oldAlphaFaces
			else
				baseObj.mesh = originalMesh
			update obj
		)
	)
	catch
	(
		try
		(
			if baseKind == #poly then
				JX_QAChar_WriteAlphaChannelData baseKind target oldAlphaValues oldAlphaFaces
			else
				baseObj.mesh = originalMesh
			update obj
		)
		catch ()
		repairMessage = ("修复异常，已尝试恢复原通道: " + ((getCurrentException()) as string))
	)

	#(repairSucceeded, oldAlphaVertCount, newAlphaValues.count, repairMessage)
)


fn JX_QAChar_GetMaterialNamesBySuffix mat suffix:"_MBB" =
(
	local result = #()
	if mat == undefined do return result

	local matName = try (mat.name as string) catch ("")
	if (matName != "") and (matchPattern matName pattern:("*" + suffix) ignoreCase:true) do
		append result matName

	if isProperty mat #materialList do
	(
		local subMaterials = try (mat.materialList) catch (#())
		for subMat in subMaterials where subMat != undefined do
		(
			local childNames = JX_QAChar_GetMaterialNamesBySuffix subMat suffix:suffix
			for childName in childNames where (findItem result childName) == 0 do append result childName
		)
	)
	result
)


fn JX_QAChar_StringArrayToText values separator:"," =
(
	local result = ""
	if values == undefined do return result
	for value in values do
	(
		if result != "" do result += separator
		result += (value as string)
	)
	result
)


-- 返回 #(#poly|#mesh|#unsupported, baseObject, faceTarget, faceMaterialIDs)
fn JX_QAChar_GetFaceMaterialData obj =
(
	local baseData = JX_QAChar_GetAlphaBaseData obj
	local baseKind = baseData[1]
	local baseObj = baseData[2]
	local target = baseData[3]
	if baseKind == #unsupported do return #(#unsupported, baseObj, undefined, #())
	if baseKind == #poly do target = baseObj

	local faceCount = if baseKind == #poly then
		(try (polyop.getNumFaces target) catch (0))
	else
		(try (target.numfaces) catch (0))
	if faceCount <= 0 do return #(#unsupported, baseObj, target, #())

	local faceIDs = #()
	for faceIndex = 1 to faceCount do
	(
		local faceID = if baseKind == #poly then
			(try (polyop.getFaceMatID target faceIndex) catch (undefined))
		else
			(try (getFaceMatID target faceIndex) catch (undefined))
		if faceID == undefined do return #(#unsupported, baseObj, target, #())
		append faceIDs (faceID as integer)
	)
	#(baseKind, baseObj, target, faceIDs)
)


fn JX_QAChar_WriteFaceMaterialIDs baseKind baseObj target faceIDs =
(
	try
	(
		if baseKind == #poly then
		(
			if (polyop.getNumFaces baseObj) != faceIDs.count do throw "面数量发生变化"
			for faceIndex = 1 to faceIDs.count do
				polyop.setFaceMatID baseObj faceIndex faceIDs[faceIndex]
		)
		else if baseKind == #mesh then
		(
			if target == undefined do target = baseObj.mesh
			if target.numfaces != faceIDs.count do throw "面数量发生变化"
			for faceIndex = 1 to faceIDs.count do
				setFaceMatID target faceIndex faceIDs[faceIndex]
			update target
			baseObj.mesh = target
		)
		else
			throw "不支持的底层对象类型"
		try (notifyDependents baseObj partID:#display) catch ()
		true
	)
	catch (false)
)


-- 珍珠分析结果：
-- #(状态, 说明, 底层类型, 底层对象, 面目标, 原面ID数组, 原材质, 是否Multi/Sub,
--   珍珠槽位, 珍珠当前ID, 命中材质名, 珍珠面数, ID1对应槽位, 修复方式)
-- 状态：#unsupported|#none|#unused|#valid|#wrong|#ambiguous
-- 修复方式：#none|#single|#move|#swap
fn JX_QAChar_AnalyzePearlMaterialID obj suffix:"_MBB" =
(
	local faceData = JX_QAChar_GetFaceMaterialData obj
	local baseKind = faceData[1]
	if baseKind == #unsupported then
		return #(#unsupported, "底层对象不是可编辑多边形/网格，或没有可检查面", baseKind,
			faceData[2], faceData[3], faceData[4], undefined, false, 0, 0, #(), 0, 0, #none)

	local faceIDs = faceData[4]
	local objMat = try (obj.material) catch (undefined)
	if objMat == undefined then
		return #(#none, "没有材质", baseKind, faceData[2], faceData[3], faceIDs,
			objMat, false, 0, 0, #(), 0, 0, #none)

	local isMultiMaterial = (isProperty objMat #materialList) and (isProperty objMat #materialIDList)
	if not isMultiMaterial then
	(
		local matchedNames = JX_QAChar_GetMaterialNamesBySuffix objMat suffix:suffix
		if matchedNames.count == 0 then
			return #(#none, "未匹配 _MBB 材质", baseKind, faceData[2], faceData[3], faceIDs,
				objMat, false, 0, 0, matchedNames, 0, 0, #none)

		local wrongFaceCount = 0
		for faceID in faceIDs where faceID != 1 do wrongFaceCount += 1
		if wrongFaceCount == 0 then
			return #(#valid, "单材质珍珠面的 Material ID 均为 1", baseKind, faceData[2], faceData[3],
				faceIDs, objMat, false, 0, 1, matchedNames, faceIDs.count, 0, #none)
		else
			return #(#wrong, "单材质珍珠面存在非 1 的 Material ID", baseKind, faceData[2], faceData[3],
				faceIDs, objMat, false, 0, 0, matchedNames, faceIDs.count, 0, #single)
	)

	local subMaterials = try (objMat.materialList) catch (#())
	local materialIDs = try (objMat.materialIDList) catch (#())
	local slotIDs = #()
	local pearlSlots = #()
	local pearlNamesBySlot = #()

	for slotIndex = 1 to subMaterials.count do
	(
		local slotID = if slotIndex <= materialIDs.count then
			(try (materialIDs[slotIndex] as integer) catch (0))
		else
			slotIndex
		append slotIDs slotID

		local slotNames = JX_QAChar_GetMaterialNamesBySuffix subMaterials[slotIndex] suffix:suffix
		if slotNames.count > 0 do
		(
			append pearlSlots slotIndex
			append pearlNamesBySlot slotNames
		)
	)

	if pearlSlots.count == 0 then
		return #(#none, "未匹配 _MBB 材质", baseKind, faceData[2], faceData[3], faceIDs,
			objMat, true, 0, 0, #(), 0, 0, #none)
	if pearlSlots.count > 1 then
		return #(#ambiguous, "存在多个 _MBB 材质槽位，无法无损合并为 ID 1", baseKind,
			faceData[2], faceData[3], faceIDs, objMat, true, 0, 0, #(), 0, 0, #none)

	local pearlSlot = pearlSlots[1]
	local pearlNames = pearlNamesBySlot[1]
	local pearlID = slotIDs[pearlSlot]
	if pearlID <= 0 then
		return #(#ambiguous, "_MBB 材质槽位的 Material ID 无效", baseKind, faceData[2],
			faceData[3], faceIDs, objMat, true, pearlSlot, pearlID, pearlNames, 0, 0, #none)

	local pearlIDSlotCount = 0
	local targetOneSlots = #()
	for slotIndex = 1 to slotIDs.count do
	(
		if slotIDs[slotIndex] == pearlID do pearlIDSlotCount += 1
		if slotIDs[slotIndex] == 1 do append targetOneSlots slotIndex
	)
	if pearlIDSlotCount > 1 then
		return #(#ambiguous, "_MBB 当前 ID 同时映射到多个材质槽位", baseKind, faceData[2],
			faceData[3], faceIDs, objMat, true, pearlSlot, pearlID, pearlNames, 0, 0, #none)

	local pearlFaceCount = 0
	local targetOneFaceCount = 0
	for faceID in faceIDs do
	(
		if faceID == pearlID do pearlFaceCount += 1
		if faceID == 1 do targetOneFaceCount += 1
	)

	if pearlFaceCount == 0 then
		return #(#unused, "_MBB 材质存在，但没有面使用其 Material ID", baseKind, faceData[2],
			faceData[3], faceIDs, objMat, true, pearlSlot, pearlID, pearlNames, 0, 0, #none)

	if pearlID == 1 then
	(
		if targetOneSlots.count > 1 then
			return #(#ambiguous, "Material ID 1 同时映射到多个材质槽位", baseKind, faceData[2],
				faceData[3], faceIDs, objMat, true, pearlSlot, pearlID, pearlNames, pearlFaceCount, 0, #none)
		return #(#valid, "_MBB 材质及对应面均使用 Material ID 1", baseKind, faceData[2],
			faceData[3], faceIDs, objMat, true, pearlSlot, pearlID, pearlNames, pearlFaceCount, 0, #none)
	)

	if targetOneSlots.count == 0 then
	(
		if targetOneFaceCount > 0 then
			return #(#ambiguous, "存在 ID 1 的面，但 Multi/Sub 中没有对应材质，无法保证外观不变",
				baseKind, faceData[2], faceData[3], faceIDs, objMat, true, pearlSlot, pearlID,
				pearlNames, pearlFaceCount, 0, #none)
		return #(#wrong, "_MBB 材质及对应面需要重映射为 Material ID 1", baseKind, faceData[2],
			faceData[3], faceIDs, objMat, true, pearlSlot, pearlID, pearlNames, pearlFaceCount, 0, #move)
	)

	if targetOneSlots.count > 1 then
		return #(#ambiguous, "Material ID 1 同时映射到多个材质槽位", baseKind, faceData[2],
			faceData[3], faceIDs, objMat, true, pearlSlot, pearlID, pearlNames, pearlFaceCount, 0, #none)

	#(#wrong, "_MBB 材质与 ID 1 材质需要无损交换", baseKind, faceData[2], faceData[3],
		faceIDs, objMat, true, pearlSlot, pearlID, pearlNames, pearlFaceCount, targetOneSlots[1], #swap)
)


-- 返回 #(成功, 是否修改, 说明, 修改面数)
fn JX_QAChar_RepairPearlMaterialID obj =
(
	local analysis = JX_QAChar_AnalyzePearlMaterialID obj
	local status = analysis[1]
	if status == #valid then return #(true, false, analysis[2], 0)
	if status == #none or status == #unused then return #(true, false, analysis[2], 0)
	if status != #wrong then return #(false, false, analysis[2], 0)

	local baseKind = analysis[3]
	local baseObj = analysis[4]
	local faceTarget = analysis[5]
	local originalFaceIDs = for faceID in analysis[6] collect faceID
	local originalMaterial = analysis[7]
	local isMultiMaterial = analysis[8]
	local pearlSlot = analysis[9]
	local pearlID = analysis[10]
	local otherSlot = analysis[13]
	local repairMode = analysis[14]
	local newFaceIDs = for faceID in originalFaceIDs collect faceID
	local newMaterial = originalMaterial
	local changedFaceCount = 0
	local repairSucceeded = false
	local repairMessage = ""

	try
	(
		undo "安全修复珍珠材质ID" on
		(
			with redraw off
			(
				if repairMode == #single then
				(
					for faceIndex = 1 to newFaceIDs.count where newFaceIDs[faceIndex] != 1 do
					(
						newFaceIDs[faceIndex] = 1
						changedFaceCount += 1
					)
				)
				else
				(
					newMaterial = copy originalMaterial
					local newMaterialIDs = for materialID in newMaterial.materialIDList collect (materialID as integer)
					while newMaterialIDs.count < newMaterial.materialList.count do
						append newMaterialIDs (newMaterialIDs.count + 1)

					newMaterialIDs[pearlSlot] = 1
					if repairMode == #swap do newMaterialIDs[otherSlot] = pearlID
					newMaterial.materialIDList = newMaterialIDs
					obj.material = newMaterial

					for faceIndex = 1 to newFaceIDs.count do
					(
						local oldFaceID = newFaceIDs[faceIndex]
						if oldFaceID == pearlID then
						(
							newFaceIDs[faceIndex] = 1
							changedFaceCount += 1
						)
						else if repairMode == #swap and oldFaceID == 1 then
						(
							newFaceIDs[faceIndex] = pearlID
							changedFaceCount += 1
						)
					)
				)

				if not (JX_QAChar_WriteFaceMaterialIDs baseKind baseObj faceTarget newFaceIDs) do
					throw "写入面 Material ID 失败"

				local verifyResult = JX_QAChar_AnalyzePearlMaterialID obj
				if verifyResult[1] != #valid do throw ("修复后验证失败：" + verifyResult[2])
				repairSucceeded = true
				repairMessage = if isMultiMaterial then
					(if repairMode == #swap then "已交换珍珠材质与原 ID 1 材质，外观映射保持不变"
					else "已将珍珠材质及对应面重映射为 ID 1")
				else
					"已将单材质珍珠面的 Material ID 统一为 1"
			)
		)
	)
	catch
	(
		repairMessage = try (getCurrentException() as string) catch ("未知错误")
		try
		(
			obj.material = originalMaterial
			local restoreTarget = if baseKind == #mesh then baseObj.mesh else baseObj
			JX_QAChar_WriteFaceMaterialIDs baseKind baseObj restoreTarget originalFaceIDs
		)
		catch ()
		repairSucceeded = false
	)

	#(repairSucceeded, repairSucceeded, repairMessage, changedFaceCount)
)


fn JX_QAChar_ParseIntegerList value =
(
	local result = #()
	if value == undefined or value == "" do return result
	for token in (filterString value ",") do
	(
		local parsedValue = try (token as integer) catch (0)
		if parsedValue > 0 and (findItem result parsedValue) == 0 do append result parsedValue
	)
	result
)


fn JX_QAChar_PearlMapStateFromString value =
(
	case value of
	(
		"processed": #processed
		"restored": #restored
		"damaged": #damaged
		default: #unknown
	)
)


fn JX_QAChar_PearlMapStateToString value =
(
	case value of
	(
		#processed: "processed"
		#restored: "restored"
		#damaged: "damaged"
		default: "unknown"
	)
)


fn JX_QAChar_ReadPearlMapMarker obj =
(
	local marker = JX_QAPearlMapMarker()
	local rawValue = try (getAppData obj JX_QAPearlMapAppDataID) catch (undefined)
	if rawValue == undefined or rawValue == "" do return marker

	marker.raw = rawValue
	local parts = filterString rawValue "|"
	if parts.count < 12 or parts[1] != "JX_MBB_STATE" do return marker

	try
	(
		marker.schemaVersion = parts[2] as integer
		marker.algorithmVersion = parts[3] as integer
		marker.state = JX_QAChar_PearlMapStateFromString parts[4]
		marker.uvChannel = parts[5] as integer
		marker.collapseEpsilon = parts[6] as float
		marker.materialIDs = JX_QAChar_ParseIntegerList parts[7]
		marker.vertexCount = parts[8] as integer
		marker.faceCount = parts[9] as integer
		marker.topologySignature = parts[10]
		marker.source = parts[11]
		marker.splitVertexCount = parts[12] as integer
		marker.valid = marker.schemaVersion == 1 and marker.algorithmVersion == 1 and
			(marker.state == #processed or marker.state == #restored or marker.state == #damaged) and
			marker.uvChannel > 0 and marker.collapseEpsilon > 0
	)
	catch
	(
		marker.valid = false
	)
	marker
)


fn JX_QAChar_GetGeomVertexCount baseKind target =
(
	if baseKind == #poly then
		(try (polyop.getNumVerts target) catch (0))
	else if baseKind == #mesh then
		(try (target.numverts) catch (0))
	else
		0
)


fn JX_QAChar_GetGeomFaceVertices baseKind target faceIndex =
(
	if baseKind == #poly then
		(try (polyop.getFaceVerts target faceIndex) catch (undefined))
	else if baseKind == #mesh then
		(try (JX_QAChar_Point3IndicesToArray (getFace target faceIndex)) catch (undefined))
	else
		undefined
)


fn JX_QAChar_GetGeomVertex baseKind target vertexIndex =
(
	if baseKind == #poly then
		(polyop.getVert target vertexIndex)
	else
		(getVert target vertexIndex)
)


fn JX_QAChar_SetGeomVertex baseKind target vertexIndex positionValue =
(
	if baseKind == #poly then
		polyop.setVert target vertexIndex positionValue
	else
		setVert target vertexIndex positionValue
)


fn JX_QAChar_GetMapSupport baseKind target mapChannel =
(
	try
	(
		if baseKind == #poly then
			polyop.getMapSupport target mapChannel
		else
			meshop.getMapSupport target mapChannel
	)
	catch (false)
)


fn JX_QAChar_GetMapFaceCount baseKind target mapChannel =
(
	try
	(
		if baseKind == #poly then
			polyop.getNumMapFaces target mapChannel
		else
			meshop.getNumMapFaces target mapChannel
	)
	catch (0)
)


fn JX_QAChar_GetMapVertexCount baseKind target mapChannel =
(
	try
	(
		if baseKind == #poly then
			polyop.getNumMapVerts target mapChannel
		else
			meshop.getNumMapVerts target mapChannel
	)
	catch (0)
)


fn JX_QAChar_GetMapFaceVertices baseKind target mapChannel faceIndex =
(
	if baseKind == #poly then
		(try (polyop.getMapFace target mapChannel faceIndex) catch (undefined))
	else if baseKind == #mesh then
		(try (JX_QAChar_Point3IndicesToArray (meshop.getMapFace target mapChannel faceIndex)) catch (undefined))
	else
		undefined
)


fn JX_QAChar_GetMapVertex baseKind target mapChannel vertexIndex =
(
	if baseKind == #poly then
		(polyop.getMapVert target mapChannel vertexIndex)
	else
		(meshop.getMapVert target mapChannel vertexIndex)
)


fn JX_QAChar_DecodePearlMapOffset mapValue =
(
	[-mapValue.x, mapValue.z, mapValue.y] * 100.0
)


fn JX_QAChar_PearlMapDirection offsetValue =
(
	local offsetLength = length offsetValue
	if offsetLength > 0.000001 then offsetValue / offsetLength else [1,0,0]
)


fn JX_QAChar_GetTopologySignature baseKind target =
(
	local vertexCount = JX_QAChar_GetGeomVertexCount baseKind target
	local faceCount = if baseKind == #poly then
		(try (polyop.getNumFaces target) catch (0))
	else
		(try (target.numfaces) catch (0))
	local sumA = 0.0
	local sumB = 0.0
	local cornerCount = 0

	for faceIndex = 1 to faceCount do
	(
		local faceVerts = JX_QAChar_GetGeomFaceVertices baseKind target faceIndex
		if faceVerts == undefined do return ""
		for cornerIndex = 1 to faceVerts.count do
		(
			local vertexID = faceVerts[cornerIndex] as integer
			sumA += vertexID
			sumB += (faceIndex as float) * 131.0 + (cornerIndex as float) * 17.0 + (vertexID as float) * 1009.0
			cornerCount += 1
		)
	)
	(vertexCount as string) + ":" + (faceCount as string) + ":" + (cornerCount as string) +
		":" + (sumA as string) + ":" + (sumB as string)
)


fn JX_QAChar_WritePearlMapMarker obj state baseKind target materialIDs uvChannel:4 collapseEpsilon:0.001 splitVertexCount:0 =
(
	local stateText = JX_QAChar_PearlMapStateToString state
	local topologySignature = JX_QAChar_GetTopologySignature baseKind target
	local vertexCount = JX_QAChar_GetGeomVertexCount baseKind target
	local faceCount = if baseKind == #poly then polyop.getNumFaces target else target.numfaces
	local rawValue = "JX_MBB_STATE|1|1|" + stateText + "|" + uvChannel as string + "|" +
		collapseEpsilon as string + "|" + JX_QAChar_StringArrayToText materialIDs + "|" +
		vertexCount as string + "|" + faceCount as string + "|" + topologySignature +
		"|JX_QAChar_" + JX_QACharVersion + "|" + splitVertexCount as string
	try
	(
		setAppData obj JX_QAPearlMapAppDataID rawValue
		true
	)
	catch (false)
)


-- 返回 #(成功, 说明, 底层类型, 底层对象, 几何目标, 面ID, 目标面, 目标Material ID, 是否问题)
fn JX_QAChar_GetPearlMapTarget obj marker:undefined =
(
	local pearlAnalysis = JX_QAChar_AnalyzePearlMaterialID obj
	local baseKind = pearlAnalysis[3]
	local baseObj = pearlAnalysis[4]
	local target = pearlAnalysis[5]
	local faceIDs = pearlAnalysis[6]
	if baseKind == #unsupported do
		return #(false, "底层对象不是可编辑多边形/网格", baseKind, baseObj, target, faceIDs, #{}, #(), false)

	local materialIDs = #()
	local targetFaces = #{}
	local hasPearlMaterial = pearlAnalysis[1] != #none and pearlAnalysis[1] != #unsupported

	if hasPearlMaterial and not pearlAnalysis[8] then
	(
		for faceID in faceIDs where (findItem materialIDs faceID) == 0 do append materialIDs faceID
		targetFaces = #{1..faceIDs.count}
	)
	else if hasPearlMaterial and pearlAnalysis[10] > 0 then
	(
		append materialIDs pearlAnalysis[10]
		for faceIndex = 1 to faceIDs.count where faceIDs[faceIndex] == pearlAnalysis[10] do
			targetFaces[faceIndex] = true
	)
	else if marker != undefined and marker.valid and marker.materialIDs.count > 0 then
	(
		materialIDs = for materialID in marker.materialIDs collect materialID
		for faceIndex = 1 to faceIDs.count where (findItem materialIDs faceIDs[faceIndex]) > 0 do
			targetFaces[faceIndex] = true
	)

	if targetFaces.numberSet == 0 then
	(
		local reason = if marker != undefined and marker.valid then
			"存在珍珠映射标记，但当前材质ID没有命中任何面"
		else if pearlAnalysis[1] == #ambiguous then
			("存在 _MBB 材质，但无法唯一确定珍珠面：" + pearlAnalysis[2])
		else
			"未找到可检查的 _MBB 珍珠面"
		local isProblem = (marker != undefined and marker.valid) or pearlAnalysis[1] == #ambiguous
		return #(false, reason, baseKind, baseObj, target, faceIDs, targetFaces, materialIDs, isProblem)
	)

	#(true, "", baseKind, baseObj, target, faceIDs, targetFaces, materialIDs, false)
)


fn JX_QAChar_GetPearlFaceElements baseKind target targetFaces vertexCount =
(
	local faceCount = if baseKind == #poly then polyop.getNumFaces target else target.numfaces
	local faceVertsCache = for i = 1 to faceCount collect undefined
	local targetFacesByVertex = for i = 1 to vertexCount collect #()

	for faceIndex in targetFaces do
	(
		local faceVerts = JX_QAChar_GetGeomFaceVertices baseKind target faceIndex
		if faceVerts == undefined do return #()
		faceVertsCache[faceIndex] = faceVerts
		for vertexID in faceVerts do append targetFacesByVertex[vertexID as integer] faceIndex
	)

	local elements = #()
	local remaining = copy targetFaces
	while remaining.numberSet > 0 do
	(
		local seedFace = (remaining as array)[1]
		local queue = #(seedFace)
		local queueIndex = 1
		local elementFaces = #{}
		local elementVerts = #{}

		while queueIndex <= queue.count do
		(
			local currentFace = queue[queueIndex]
			queueIndex += 1
			if not elementFaces[currentFace] do
			(
				elementFaces[currentFace] = true
				remaining[currentFace] = false
				local faceVerts = faceVertsCache[currentFace]
				for vertexIDValue in faceVerts do
				(
					local vertexID = vertexIDValue as integer
					elementVerts[vertexID] = true
					for neighborFace in targetFacesByVertex[vertexID] where not elementFaces[neighborFace] do
						append queue neighborFace
				)
			)
		)
		append elements #(elementFaces, elementVerts)
	)
	elements
)


fn JX_QAChar_AnalyzePearlMapState obj =
(
	local startedAt = timestamp()
	local marker = JX_QAChar_ReadPearlMapMarker obj
	local inspection = JX_QAPearlMapInspection node:obj marker:marker
	local targetData = JX_QAChar_GetPearlMapTarget obj marker:marker
	inspection.baseKind = targetData[3]
	inspection.baseObject = targetData[4]
	inspection.target = targetData[5]
	inspection.targetFaces = targetData[7]
	inspection.materialIDs = targetData[8]

	if marker.raw != "" and not marker.valid then
	(
		inspection.status = #damaged
		inspection.message = "珍珠映射 AppData 格式损坏或版本不受支持"
		inspection.elapsedMs = timestamp() - startedAt
		return inspection
	)

	if not targetData[1] then
	(
		inspection.status = if targetData[9] then #damaged else #none
		inspection.message = targetData[2]
		inspection.elapsedMs = timestamp() - startedAt
		return inspection
	)

	local baseKind = inspection.baseKind
	local target = inspection.target
	local vertexCount = JX_QAChar_GetGeomVertexCount baseKind target
	local faceCount = if baseKind == #poly then polyop.getNumFaces target else target.numfaces
	local uvChannel = if marker.valid then marker.uvChannel else 4
	local collapseEpsilon = if marker.valid then marker.collapseEpsilon else 0.001
	inspection.uvChannel = uvChannel
	inspection.collapseEpsilon = collapseEpsilon

	if marker.valid then
	(
		local currentSignature = JX_QAChar_GetTopologySignature baseKind target
		if marker.vertexCount != vertexCount or marker.faceCount != faceCount or
			(marker.topologySignature != "" and marker.topologySignature != currentSignature) then
		(
			inspection.status = #damaged
			inspection.message = "AppData记录与当前拓扑不一致，模型在映射处理后可能被修改"
			inspection.elapsedMs = timestamp() - startedAt
			return inspection
		)
	)

	if not (JX_QAChar_GetMapSupport baseKind target uvChannel) then
	(
		inspection.status = if marker.valid and marker.state != #restored then #damaged else #unprocessed
		inspection.message = if inspection.status == #damaged then
			("AppData显示模型已运行，但 UV" + uvChannel as string + " 不存在")
		else
			("未发现珍珠映射数据（UV" + uvChannel as string + " 不存在）")
		inspection.elapsedMs = timestamp() - startedAt
		return inspection
	)

	local mapFaceCount = JX_QAChar_GetMapFaceCount baseKind target uvChannel
	local mapVertexCount = JX_QAChar_GetMapVertexCount baseKind target uvChannel
	if mapFaceCount != faceCount or mapVertexCount <= 0 then
	(
		inspection.status = if marker.valid then #damaged else #unprocessed
		inspection.message = "UV通道结构与几何面不一致，不能确认为珍珠映射数据"
		inspection.elapsedMs = timestamp() - startedAt
		return inspection
	)

	local offsetsByVertex = for i = 1 to vertexCount collect undefined
	local targetVertexBits = #{}
	local mapConflict = false

	for faceIndex in inspection.targetFaces while not mapConflict do
	(
		local geomFace = JX_QAChar_GetGeomFaceVertices baseKind target faceIndex
		local mapFace = JX_QAChar_GetMapFaceVertices baseKind target uvChannel faceIndex
		if geomFace == undefined or mapFace == undefined or geomFace.count != mapFace.count then
			mapConflict = true
		else
		(
			for cornerIndex = 1 to geomFace.count while not mapConflict do
			(
				local geomVertexID = geomFace[cornerIndex] as integer
				local mapVertexID = mapFace[cornerIndex] as integer
				if mapVertexID < 1 or mapVertexID > mapVertexCount then
					mapConflict = true
				else
				(
					local decodedOffset = JX_QAChar_DecodePearlMapOffset \
						(JX_QAChar_GetMapVertex baseKind target uvChannel mapVertexID)
					targetVertexBits[geomVertexID] = true
					if offsetsByVertex[geomVertexID] == undefined then
						offsetsByVertex[geomVertexID] = decodedOffset
					else if distance offsetsByVertex[geomVertexID] decodedOffset > 0.00001 then
						mapConflict = true
				)
			)
		)
	)

	if mapConflict then
	(
		inspection.status = if marker.valid then #damaged else #unprocessed
		inspection.message = "同一几何顶点对应的UV4偏移不一致，不能安全识别或复原"
		inspection.elapsedMs = timestamp() - startedAt
		return inspection
	)

	local elements = JX_QAChar_GetPearlFaceElements baseKind target inspection.targetFaces vertexCount
	if elements.count == 0 then
	(
		inspection.status = #damaged
		inspection.message = "无法建立珍珠面元素"
		inspection.elapsedMs = timestamp() - startedAt
		return inspection
	)

	local sharedBoundaryVerts = #{}
	for faceIndex = 1 to faceCount where not inspection.targetFaces[faceIndex] do
	(
		local faceVerts = JX_QAChar_GetGeomFaceVertices baseKind target faceIndex
		if faceVerts != undefined do
			for vertexIDValue in faceVerts do
			(
				local vertexID = vertexIDValue as integer
				if targetVertexBits[vertexID] do sharedBoundaryVerts[vertexID] = true
			)
	)

	inspection.elements = for elementData in elements collect elementData[2]
	inspection.offsetsByVertex = offsetsByVertex
	inspection.sharedBoundaryVertexCount = sharedBoundaryVerts.numberSet

	local foreignCount = 0
	local ambiguousCount = 0
	local damagedCount = 0

	for elementData in elements do
	(
		local elementVerts = elementData[2]
		local vertexAmount = elementVerts.numberSet
		local meanOffset = [0,0,0]
		local maxOffset = 0.0
		local processedCenter = [0,0,0]
		local restoredCenter = [0,0,0]
		local elementState = #unknown
		local elementInvalid = false

		if vertexAmount <= 0 then
		(
			damagedCount += 1
			append inspection.elementStates elementState
			continue
		)

		for vertexID in elementVerts do
		(
			local offsetValue = offsetsByVertex[vertexID]
			if offsetValue == undefined then
			(
				elementInvalid = true
				exit
			)
			local positionValue = JX_QAChar_GetGeomVertex baseKind target vertexID
			meanOffset += offsetValue
			maxOffset = amax maxOffset (length offsetValue)
			processedCenter += positionValue - (JX_QAChar_PearlMapDirection offsetValue) * collapseEpsilon
			restoredCenter += positionValue - offsetValue
		)

		if elementInvalid then
		(
			damagedCount += 1
			elementState = #damaged
			append inspection.elementStates elementState
			continue
		)

		if maxOffset == 0.0 then
		(
			foreignCount += 1
			elementState = #foreign
			append inspection.elementStates elementState
			continue
		)

		meanOffset /= vertexAmount
		processedCenter /= vertexAmount
		restoredCenter /= vertexAmount
		local tolerance = amax 0.00005 (maxOffset * 0.0001)
		local offsetTolerance = amax 0.00001 (maxOffset * 0.001)

		if maxOffset <= 0.000001 or length meanOffset > offsetTolerance then
		(
			foreignCount += 1
			elementState = #foreign
		)
		else
		(
			local processedResidual = 0.0
			local restoredResidual = 0.0
			for vertexID in elementVerts do
			(
				local offsetValue = offsetsByVertex[vertexID]
				local positionValue = JX_QAChar_GetGeomVertex baseKind target vertexID
				local processedCandidate = positionValue -
					(JX_QAChar_PearlMapDirection offsetValue) * collapseEpsilon
				local restoredCandidate = positionValue - offsetValue
				processedResidual = amax processedResidual (distance processedCandidate processedCenter)
				restoredResidual = amax restoredResidual (distance restoredCandidate restoredCenter)
			)

			local processedMatch = processedResidual <= tolerance
			local restoredMatch = restoredResidual <= tolerance
			if processedMatch and not restoredMatch then
			(
				elementState = #processed
				inspection.processedElementCount += 1
			)
			else if restoredMatch and not processedMatch then
			(
				elementState = #restored
				inspection.restoredElementCount += 1
			)
			else if processedMatch and restoredMatch then
			(
				elementState = #ambiguous
				ambiguousCount += 1
			)
			else
			(
				elementState = #foreign
				foreignCount += 1
			)
		)
		append inspection.elementStates elementState
	)

	if damagedCount > 0 or ambiguousCount > 0 then
	(
		inspection.status = #damaged
		inspection.message = "部分珍珠元素的映射状态不明确，已阻止自动复原"
	)
	else if inspection.processedElementCount > 0 and foreignCount > 0 then
	(
		inspection.status = #damaged
		inspection.message = "只识别到部分已运行元素，其余UV4数据不符合算法，已阻止自动复原"
	)
	else if inspection.processedElementCount > 0 then
	(
		inspection.status = if inspection.restoredElementCount > 0 then #partial else #processed
		inspection.repairable = inspection.sharedBoundaryVertexCount == 0
		inspection.message = if inspection.status == #partial then
			("检测到 " + inspection.processedElementCount as string + " 个已运行元素、" +
				inspection.restoredElementCount as string + " 个已复原元素")
		else
			("检测到 " + inspection.processedElementCount as string + " 个已运行珍珠元素")
		if inspection.sharedBoundaryVertexCount > 0 do
		(
			inspection.message += "；目标顶点仍与非珍珠面共享，不能安全自动复原"
			inspection.repairable = false
		)
	)
	else if inspection.restoredElementCount > 0 and foreignCount == 0 then
	(
		inspection.status = #restored
		inspection.message = "珍珠映射数据存在，但模型几何已经复原"
	)
	else
	(
		inspection.status = if marker.valid then #damaged else #unprocessed
		inspection.message = if marker.valid then
			"AppData存在，但UV4和几何不符合记录的珍珠映射状态"
		else
			"UV4不符合珍珠映射算法，按未运行处理"
	)

	if marker.valid and inspection.status == #processed and marker.state == #restored do
		inspection.message += "；AppData状态过期，将在成功复原后更新"
	if marker.valid and inspection.status == #restored and marker.state == #processed do
	(
		inspection.status = #markerStale
		inspection.repairable = true
		inspection.message = "几何已经复原，但AppData仍标记为已运行"
	)

	inspection.elapsedMs = timestamp() - startedAt
	inspection
)


-- 返回 #(成功, 是否修改, 说明, 备份名称, 复原元素数)
fn JX_QAChar_RepairPearlMapState obj createBackup:true =
(
	local inspection = JX_QAChar_AnalyzePearlMapState obj
	if inspection.status == #restored or inspection.status == #markerStale then
	(
		local markerUpdated = JX_QAChar_WritePearlMapMarker obj #restored inspection.baseKind \
			inspection.target inspection.materialIDs uvChannel:inspection.uvChannel \
			collapseEpsilon:inspection.collapseEpsilon
		return #(markerUpdated, markerUpdated, if markerUpdated then "几何已复原，已更新AppData状态" else
			"几何已复原，但AppData写入失败", "", 0)
	)
	if inspection.status == #none or inspection.status == #unprocessed then
		return #(true, false, inspection.message, "", 0)
	if not inspection.repairable then
		return #(false, false, inspection.message, "", 0)

	local baseKind = inspection.baseKind
	local target = inspection.target
	local originalAppData = try (getAppData obj JX_QAPearlMapAppDataID) catch (undefined)
	local changedVerts = #{}
	for elementIndex = 1 to inspection.elements.count where inspection.elementStates[elementIndex] == #processed do
		changedVerts += inspection.elements[elementIndex]
	local originalPositions = #()
	local changedVertIDs = changedVerts as array
	for vertexID in changedVertIDs do append originalPositions (JX_QAChar_GetGeomVertex baseKind target vertexID)

	local backupNode = undefined
	local repairSucceeded = false
	local repairMessage = ""
	local restoredElements = 0

	try
	(
		undo "安全复原珍珠映射" on
		(
			with redraw off
			(
				if createBackup do backupNode = JX_QAChar_CreateHiddenBackup obj
				-- cloneNodes 可能让先前取得的 baseObject 包装器失效，备份后重新获取。
				target = if baseKind == #poly then obj.baseObject else obj.baseObject.mesh
				inspection.target = target
				inspection.baseObject = obj.baseObject

				for elementIndex = 1 to inspection.elements.count where inspection.elementStates[elementIndex] == #processed do
				(
					local elementVerts = inspection.elements[elementIndex]
					local centerPosition = [0,0,0]
					for vertexID in elementVerts do
					(
						local offsetValue = inspection.offsetsByVertex[vertexID]
						local positionValue = JX_QAChar_GetGeomVertex baseKind target vertexID
						centerPosition += positionValue -
							(JX_QAChar_PearlMapDirection offsetValue) * inspection.collapseEpsilon
					)
					centerPosition /= elementVerts.numberSet
					for vertexID in elementVerts do
						JX_QAChar_SetGeomVertex baseKind target vertexID \
							(centerPosition + inspection.offsetsByVertex[vertexID])
					restoredElements += 1
				)

				if baseKind == #mesh do inspection.baseObject.mesh = target
				update obj
				if not (JX_QAChar_WritePearlMapMarker obj #restored baseKind target \
					inspection.materialIDs uvChannel:inspection.uvChannel \
					collapseEpsilon:inspection.collapseEpsilon) do throw "AppData状态写入失败"

				local verifyResult = JX_QAChar_AnalyzePearlMapState obj
				if verifyResult.status != #restored do
					throw ("复原后验证失败：" + verifyResult.message)

				repairSucceeded = true
				repairMessage = "已按UV4映射复原 " + restoredElements as string + " 个珍珠元素"
				if backupNode != undefined do repairMessage += "；隐藏备份：" + backupNode.name
			)
		)
	)
	catch
	(
		repairMessage = try (getCurrentException() as string) catch ("未知错误")
		try
		(
			for positionIndex = 1 to changedVertIDs.count do
				JX_QAChar_SetGeomVertex baseKind target changedVertIDs[positionIndex] originalPositions[positionIndex]
			if baseKind == #mesh do inspection.baseObject.mesh = target
			if originalAppData == undefined then
				deleteAppData obj JX_QAPearlMapAppDataID
			else
				setAppData obj JX_QAPearlMapAppDataID originalAppData
			update obj
		)
		catch ()
		repairSucceeded = false
	)

	#(repairSucceeded, repairSucceeded, repairMessage,
		if backupNode != undefined then backupNode.name else "", restoredElements)
)


fn JX_QAChar_MatrixDifference firstMatrix secondMatrix =
(
	local difference = 0.0
	difference = amax difference (distance firstMatrix.row1 secondMatrix.row1)
	difference = amax difference (distance firstMatrix.row2 secondMatrix.row2)
	difference = amax difference (distance firstMatrix.row3 secondMatrix.row3)
	difference = amax difference (distance firstMatrix.row4 secondMatrix.row4)
	difference
)


fn JX_QAChar_GetRotationAngle rotationValue =
(
	local angleValue = try (abs ((rotationValue as angleaxis).angle)) catch (360.0)
	if angleValue > 180.0 do angleValue = 360.0 - angleValue
	abs angleValue
)


fn JX_QAChar_GetSkinModifiers obj =
(
	for modifierItem in obj.modifiers where classof modifierItem == Skin collect modifierItem
)


fn JX_QAChar_GetInstanceCount obj =
(
	local instanceNodes = #()
	try
	(
		InstanceMgr.GetInstances obj &instanceNodes
		instanceNodes.count
	)
	catch (1)
)


fn JX_QAChar_TransformIsAnimated obj =
(
	local sampleTimes = #(animationRange.start, currentTime, animationRange.end)
	local firstTransform = undefined
	for sampleTime in sampleTimes do
	(
		local sampledTransform = at time sampleTime obj.transform
		if firstTransform == undefined then
			firstTransform = sampledTransform
		else if JX_QAChar_MatrixDifference firstTransform sampledTransform > 0.00001 do return true
	)
	false
)


fn JX_QAChar_IsTemporaryModifier modifierItem =
(
	if modifierItem == undefined then return false
	modifierItem.name == "JXQA - Preserve Face Orientation" or
	modifierItem.name == "JXQA - Reset XForm"
)


fn JX_QAChar_GetBusinessModifierNames obj =
(
	for modifierItem in obj.modifiers where not (JX_QAChar_IsTemporaryModifier modifierItem) collect modifierItem.name
)


fn JX_QAChar_HasTemporaryModifiers obj =
(
	for modifierItem in obj.modifiers do
		if JX_QAChar_IsTemporaryModifier modifierItem do return true
	false
)


fn JX_QAChar_GetAnimHandleString animValue =
(
	if animValue == undefined then return "0"
	try ((getHandleByAnim animValue) as string) catch ("0")
)


-- 用于判断“全部检查”之后模型是否发生了会影响变换/Skin 修复安全性的变化。
-- 检查结果可直接提供 Skin 元数据，避免生成缓存时再次读取 SkinOps。
fn JX_QAChar_BuildTransformStateSignature obj forceFlip:false inspection:undefined preserveSelection:true =
(
	if obj == undefined or not isValidNode obj then return ""

	local parts = #()
	local skins = JX_QAChar_GetSkinModifiers obj
	local referenceFrame = 0
	local skinVertexCount = 0
	local skinBoneCount = 0
	local instanceCount = 1
	local bindTransformSignature = ""

	append parts ("version=" + JX_QACharVersion)
	append parts ("node=" + JX_QAChar_GetAnimHandleString obj)
	append parts ("base=" + JX_QAChar_GetAnimHandleString obj.baseObject)
	append parts ("baseClass=" + ((classof obj.baseObject) as string))
	append parts ("parent=" + JX_QAChar_GetAnimHandleString obj.parent)
	append parts ("forceFlip=" + forceFlip as string)
	append parts ("units=" + units.SystemType as string + "/" + units.DisplayType as string + "/" + units.SystemScale as string)
	append parts ("pivot=" + obj.pivot as string)
	append parts ("offsetPos=" + obj.objectOffsetPos as string)
	append parts ("offsetRot=" + obj.objectOffsetRot as string)
	append parts ("offsetScale=" + obj.objectOffsetScale as string)
	append parts ("currentTM=" + obj.transform as string)
	append parts ("animationRange=" + animationRange.start as string + "/" + animationRange.end as string)
	append parts ("skinCount=" + skins.count as string)

	local baseVertexCount = try (polyop.getNumVerts obj.baseObject) catch (try (getNumVerts obj) catch (-1))
	local baseFaceCount = try (polyop.getNumFaces obj.baseObject) catch (try (getNumFaces obj) catch (-1))
	append parts ("baseCounts=" + baseVertexCount as string + "/" + baseFaceCount as string)

	for modifierIndex = 1 to obj.modifiers.count do
	(
		local modifierItem = obj.modifiers[modifierIndex]
		local enabledState = try (modifierItem.enabled as string) catch ("?")
		append parts ("modifier=" + modifierIndex as string + "/" +
			((classof modifierItem) as string) + "/" +
			JX_QAChar_GetAnimHandleString modifierItem + "/" + enabledState)
	)

	if inspection != undefined then
	(
		referenceFrame = inspection.skinReferenceFrame
		skinVertexCount = inspection.skinVertexCount
		skinBoneCount = inspection.skinBoneCount
		instanceCount = inspection.instanceCount
		bindTransformSignature = inspection.bindTransformSignature
	)
	else
	(
		instanceCount = JX_QAChar_GetInstanceCount obj
		if skins.count == 1 and JX_SkinnedRepairCore != undefined do
		(
			local skinModifier = skins[1]
			referenceFrame = try (skinModifier.ref_frame) catch (0)
			local skinCounts = JX_SkinnedRepairCore.getSkinCountsReliable obj skinModifier restoreSelection:preserveSelection
			skinVertexCount = skinCounts[1]
			skinBoneCount = skinCounts[2]

			if not JX_SkinnedRepairCore.hasExistingRepairStack obj do
			(
				local originalTime = currentTime
				local meshBindTM = undefined
				sliderTime = referenceFrame
				meshBindTM = try (skinUtils.GetMeshBindTM obj) catch (undefined)
				sliderTime = originalTime
				if meshBindTM != undefined do bindTransformSignature = meshBindTM as string
			)
		)
	)

	append parts ("skinReferenceFrame=" + referenceFrame as string)
	append parts ("skinCounts=" + skinVertexCount as string + "/" + skinBoneCount as string)
	append parts ("instances=" + instanceCount as string)
	append parts ("bindTM=" + bindTransformSignature)

	local sampleTimes = #()
	for sampleTime in #(animationRange.start, referenceFrame, animationRange.end) do
		if findItem sampleTimes sampleTime == 0 do append sampleTimes sampleTime
	for sampleTime in sampleTimes do
	(
		at time sampleTime
		(
			local localTM = try (JX_SkinnedRepairCore.getLocalTM obj) catch (obj.transform)
			append parts ("sample=" + sampleTime as string + "/" + obj.transform as string + "/" + localTM as string)
		)
	)

	JX_QAChar_StringArrayToText parts separator:"|"
)


fn JX_QAChar_CreateHiddenBackup obj =
(
	local clonedNodes = #()
	maxOps.cloneNodes #(obj) cloneType:#copy newNodes:&clonedNodes
	if clonedNodes.count != 1 then throw "无法创建安全备份副本"
	local backupNode = clonedNodes[1]
	backupNode.name = uniqueName (obj.name + "_JXQA_BACKUP")
	backupNode.renderable = false
	hide backupNode
	freeze backupNode
	backupNode
)


-- 统一的变换检查结果。带 Skin 时以 ResetSkinnedXForm 1.3.2 核心为准。
fn JX_QAChar_InspectTransformObject obj forceFlip:false preserveSelection:true =
(
	local inspection = JX_QATransformInspection node:obj
	if obj == undefined or not isValidNode obj then
	(
		inspection.blockers = #("对象无效")
		inspection.detailReport = "未选择有效对象。\r\n"
		return inspection
	)
	if superclassof obj != GeometryClass then
	(
		inspection.blockers = #("不是几何体")
		inspection.detailReport = "对象：" + obj.name + "\r\n状态：已阻止\r\n原因：不是几何体。\r\n"
		return inspection
	)

	inspection.skinCount = (JX_QAChar_GetSkinModifiers obj).count
	inspection.needsScale = distance obj.scale [1,1,1] > 0.00001
	inspection.needsRotation = JX_QAChar_GetRotationAngle obj.rotation > 0.00001
	inspection.needsPivot = distance obj.pivot [0,0,0] > 0.001
	inspection.hasLegacyHelpers = JX_QAChar_HasTemporaryModifiers obj
	inspection.businessModifiers = JX_QAChar_GetBusinessModifierNames obj

	if inspection.skinCount == 0 then
	(
		local parity = try (obj.transform.determinantsign) catch (0)
		-- “强制整体翻面”只用于 Skin；无 Skin 仅按真实负变换奇偶性处理。
		inspection.needsFlip = parity < 0
		local needsRepair = inspection.needsScale or inspection.needsRotation or inspection.needsPivot or
			inspection.needsFlip or inspection.hasLegacyHelpers

		if needsRepair do
		(
			if JX_QAChar_TransformIsAnimated obj do append inspection.blockers "节点或父级变换带动画"
			if JX_QAChar_GetInstanceCount obj > 1 do append inspection.blockers "对象存在实例"
			if parity == 0 do append inspection.blockers "变换矩阵为奇异矩阵"
			if obj.parent != undefined and (try (obj.parent.transform.determinantsign) catch (1)) < 0 do
				append inspection.blockers "负奇偶性继承自父节点"
		)
		if needsRepair and inspection.businessModifiers.count > 0 do
			append inspection.warnings "继续修复会把现有业务修改器烘焙为可编辑多边形"

		inspection.status = if inspection.blockers.count > 0 then #blocked else if needsRepair then #needsRepair else #clean
		inspection.detailReport = "对象：" + obj.name + "\r\n" +
			"Skin 修改器数量：0\r\n" +
			"节点缩放：" + obj.scale as string + "；需要归一：" + inspection.needsScale as string + "\r\n" +
			"轴心坐标：" + obj.pivot as string + "；需要归零：" + inspection.needsPivot as string + "\r\n" +
			"节点旋转：" + (obj.rotation as eulerAngles) as string + "；需要归零：" + inspection.needsRotation as string + "\r\n" +
			"世界变换奇偶性：" + parity as string + "\r\n" +
			"处理时翻面：" + inspection.needsFlip as string + "\r\n" +
			"状态：" + inspection.status as string + "\r\n"
	)
	else
	(
		if JX_SkinnedRepairCore == undefined then
		(
			local coreFailure = "蒙皮安全修复核心没有加载"
			if JX_QACharCoreLoadError != undefined do
				coreFailure += "：" + JX_QACharCoreLoadError as string
			inspection.blockers = #(coreFailure)
			inspection.status = #blocked
			inspection.detailReport = "对象：" + obj.name + "\r\n状态：已阻止\r\n原因：" + coreFailure + "。\r\n"
			return inspection
		)

		local rawAnalysis = JX_SkinnedRepairCore.analyze obj forceFlip:forceFlip restoreSelection:preserveSelection
		inspection.coreAnalysis = rawAnalysis
		if rawAnalysis.count >= 5 do
		(
			inspection.skinReferenceFrame = rawAnalysis[5][1]
			inspection.instanceCount = rawAnalysis[5][2]
			inspection.skinVertexCount = rawAnalysis[5][3]
			inspection.skinBoneCount = rawAnalysis[5][4]
			inspection.bindTransformSignature = rawAnalysis[5][5]
		)
		local cleanOnlyBlocker = "缩放、轴心、旋转和面朝向均未检测到需要修复的问题。"
		for blockerText in rawAnalysis[2] where blockerText != cleanOnlyBlocker do append inspection.blockers blockerText
		inspection.warnings = rawAnalysis[3]
		inspection.needsFlip = JX_SkinnedRepairCore.shouldFlipFaces obj forceFlip:forceFlip
		local hasExistingRepair = JX_SkinnedRepairCore.hasExistingRepairStack obj
		local needsRepair = inspection.needsScale or inspection.needsRotation or inspection.needsPivot or
			inspection.needsFlip or hasExistingRepair
		inspection.status = if inspection.blockers.count > 0 then #blocked else if needsRepair then #needsRepair else #clean
		inspection.detailReport = rawAnalysis[4]
	)
	inspection
)


fn JX_QAChar_GetDirectChildrenWorldTransforms obj =
(
	for childNode in obj.children collect #(childNode, childNode.transform)
)


fn JX_QAChar_RestoreDirectChildrenWorldTransforms childData =
(
	for item in childData where isValidNode item[1] do
		try (item[1].transform = item[2]) catch ()
)


-- snapshotAsMesh 返回求值后的世界空间网格。
fn JX_QAChar_CaptureWorldMeshSample obj sampleLimit:128 =
(
	local meshValue = snapshotAsMesh obj
	local vertexCount = meshValue.numverts
	local faceCount = meshValue.numfaces
	local sampleIndices = #()
	local samplePoints = #()
	local stepSize = 1
	if vertexCount > sampleLimit do stepSize = amax 1 (floor (vertexCount as float / sampleLimit))
	for vertexIndex = 1 to vertexCount by stepSize do
	(
		append sampleIndices vertexIndex
		append samplePoints (getVert meshValue vertexIndex)
		if samplePoints.count >= sampleLimit do exit
	)
	meshValue = undefined
	#(vertexCount, faceCount, sampleIndices, samplePoints)
)


fn JX_QAChar_CompareWorldMeshSample obj savedSample =
(
	local meshValue = snapshotAsMesh obj
	if meshValue.numverts != savedSample[1] or meshValue.numfaces != savedSample[2] then
	(
		meshValue = undefined
		return #(false, 1e9)
	)

	local maximumError = 0.0
	for sampleIndex = 1 to savedSample[3].count do
	(
		local vertexIndex = savedSample[3][sampleIndex]
		maximumError = amax maximumError (distance savedSample[4][sampleIndex] (getVert meshValue vertexIndex))
	)
	meshValue = undefined
	#(maximumError <= 0.001, maximumError)
)


fn JX_QAChar_CaptureTransformSamples obj referenceFrame =
(
	local originalTime = currentTime
	local sampleTimes = #()
	for sampleTime in #(referenceFrame, originalTime, animationRange.start,
		((animationRange.start + animationRange.end) / 2), animationRange.end) do
	(
		if (findItem sampleTimes sampleTime) == 0 do append sampleTimes sampleTime
	)

	local samples = #()
	for sampleTime in sampleTimes do
	(
		sliderTime = sampleTime
		append samples #(sampleTime, JX_QAChar_CaptureWorldMeshSample obj)
	)
	sliderTime = originalTime
	samples
)


fn JX_QAChar_ValidateTransformSamples obj samples =
(
	local originalTime = currentTime
	local maximumError = 0.0
	local valid = true
	for sampleData in samples while valid do
	(
		sliderTime = sampleData[1]
		local comparison = JX_QAChar_CompareWorldMeshSample obj sampleData[2]
		maximumError = amax maximumError comparison[2]
		if not comparison[1] do valid = false
	)
	sliderTime = originalTime
	#(valid, maximumError)
)


-- 无 Skin 安全修复：临时修改器只用于过程，成功后烘焙为干净的 Editable Poly。
fn JX_QAChar_RepairUnskinnedTransformObject obj allowBusinessModifierBake:false =
(
	-- 无 Skin 始终使用可撤销的干净烘焙流程，不创建隐藏备份，也不接受强制翻面。
	local inspection = JX_QAChar_InspectTransformObject obj forceFlip:false
	if inspection.skinCount != 0 then return #(false, false, "该对象不是无 Skin 模型", 0.0)
	if inspection.status == #blocked then
		return #(false, false, "已阻止：" + JX_QAChar_StringArrayToText inspection.blockers separator:"；", 0.0)
	if inspection.status == #clean then return #(true, false, "变换和修改器堆栈已经规范", 0.0)
	if inspection.businessModifiers.count > 0 and not allowBusinessModifierBake then
		return #(false, false, "存在其他修改器，需要用户允许烘焙整个堆栈", 0.0)

	local originalTime = currentTime
	local originalParity = try (obj.transform.determinantsign) catch (1)
	local childWorldTransforms = JX_QAChar_GetDirectChildrenWorldTransforms obj
	local savedSamples = JX_QAChar_CaptureTransformSamples obj currentTime
	local renderedNormalSamples = if JX_SkinnedRepairCore != undefined then
		JX_SkinnedRepairCore.captureRenderedNormalSamples obj
	else undefined
	local maximumError = 0.0
	local succeeded = false
	local failureMessage = ""

	try
	(
		undo "JX QA 无 Skin 安全变换修复" on
		(
			if inspection.needsScale or inspection.needsRotation or inspection.needsFlip do
			(
				local oldModifiers = for modifierItem in obj.modifiers collect modifierItem
				resetXForm obj
				local resetModifier = undefined
				for modifierItem in obj.modifiers do
					if findItem oldModifiers modifierItem == 0 and resetModifier == undefined do resetModifier = modifierItem
				if resetModifier == undefined or classof resetModifier != XForm do
					throw "原生 Reset XForm 没有创建预期的 XForm 修改器"
				resetModifier.name = "JXQA - Reset XForm"
				JX_QAChar_RestoreDirectChildrenWorldTransforms childWorldTransforms

				if originalParity < 0 do
				(
					local flipModifier = normalModifier flip:true unify:false
					flipModifier.name = "JXQA - Preserve Face Orientation"
					addModifier obj flipModifier
					if JX_SkinnedRepairCore != undefined do
						renderedNormalSamples = JX_SkinnedRepairCore.captureRenderedNormalSamples obj
				)
			)

			resetPivot obj
			obj.pivot = [0,0,0]
			obj.rotation = (quat 0 0 0 1)
			JX_QAChar_RestoreDirectChildrenWorldTransforms childWorldTransforms

			convertToPoly obj
			if classof obj.baseObject != Editable_Poly do throw "烘焙后的基础对象不是可编辑多边形"
			if obj.modifiers.count != 0 do throw "修复后仍残留修改器"

			completeRedraw()
			local sampleValidation = JX_QAChar_ValidateTransformSamples obj savedSamples
			maximumError = sampleValidation[2]
			if not sampleValidation[1] do throw ("世界空间顶点验证失败，最大误差：" + maximumError as string)
			if renderedNormalSamples != undefined do
			(
				local normalValidation = JX_SkinnedRepairCore.validateRenderedNormalSamples obj renderedNormalSamples
				if not normalValidation[1] do throw "烘焙时渲染面朝向发生变化"
			)
			if distance obj.scale [1,1,1] > 0.00001 do throw "修复后缩放仍未归一"
			if JX_QAChar_GetRotationAngle obj.rotation > 0.00001 do throw "修复后旋转仍未归零"
			if distance obj.pivot [0,0,0] > 0.001 do throw "修复后轴心坐标仍未归零"
			succeeded = true
		)
	)
	catch
	(
		failureMessage = try (getCurrentException() as string) catch ("未知错误")
		try (max undo) catch ()
		succeeded = false
	)

	sliderTime = originalTime
	completeRedraw()
	if succeeded then
		#(true, true, "已安全烘焙为干净的 Editable Poly", maximumError)
	else
		#(false, false, failureMessage, maximumError)
)


fn JX_QAChar_RepairTransformObject obj createBackup:true allowBusinessModifierBake:false forceFlip:false preInspection:undefined =
(
	local hasSkin = (JX_QAChar_GetSkinModifiers obj).count > 0
	local effectiveForceFlip = forceFlip and hasSkin
	local inspection = preInspection
	if inspection == undefined do
		inspection = JX_QAChar_InspectTransformObject obj forceFlip:effectiveForceFlip
	if inspection.status == #blocked then
		return #(false, false, "已阻止：" + JX_QAChar_StringArrayToText inspection.blockers separator:"；", 0.0)
	if inspection.status == #clean then return #(true, false, "无需修复", 0.0)

	if inspection.skinCount == 0 then
		JX_QAChar_RepairUnskinnedTransformObject obj allowBusinessModifierBake:allowBusinessModifierBake
	else
	(
		local repairResult = JX_SkinnedRepairCore.repair obj createBackup:createBackup forceFlip:forceFlip analysisResult:inspection.coreAnalysis
		if repairResult[1] then #(true, true, "带 Skin 安全修复完成；最终堆栈为 Skin + Editable Poly", 0.0)
		else #(false, false, repairResult[2], 0.0)
	)
)


-- 兼容旧调用入口；统一转发到无 Skin/严格 Skin 修复路由。
-- 返回 #(成功, 是否修改, 说明, 最大世界顶点误差)
fn JX_QAChar_ResetXFormObject obj =
(
	JX_QAChar_RepairTransformObject obj createBackup:true allowBusinessModifierBake:false forceFlip:false
)

rollout ModelCheckerTool "MAX 模型检查工具 v2.0.6" width:540 height:970
(
	local logText = ""
	local logMessages = #()
	local logLevels = #()
	local logNormalColor = undefined
	local logProblemColor = undefined
	local logSuccessColor = undefined
	local logBackgroundColor = undefined
	local transformCheckCache = #()
	
	-- UI 控件
	group "1. 命名规范"
	(
		button btn_fix_naming "修复命名" width:100 height:28 align:#left
	)
	
	group "2. 模型单位设置"
	(
		checkbox chk_units "检查单位设置(厘米)" checked:true
		button btn_fix_units "修复" width:50 height:20 align:#right offset:[0,-25]
		progressbar pb_units width:400 height:4 color:blue value:0
		
		label lbl_current_unit "当前单位: " offset:[0,5]
		label lbl_unit_value "" offset:[80,-17] style_sunkenedge:true
	)
	
	group "3. 模型变换、Skin 与面朝向"
	(
		checkbox chk_transform "检查轴心、旋转、缩放和负变换" checked:true
		progressbar pb_transform width:400 height:4 color:blue value:0
		checkbox chk_backup "创建隐藏安全备份（Skin）" checked:true
		checkbox chk_force_flip "正变换时强制整体翻面（Skin）" checked:false
		button btn_analyze_transform "详细分析" width:100 height:28 align:#left across:2
		button btn_fix_normals "修复" width:70 height:28 align:#right
	)
	
	group "4. UV 通道检查"
	(
		checkbox chk_uv "UV通道不多于3个" checked:true
		button btn_fix_uv "修复" width:50 height:20 align:#right offset:[0,-25]
		progressbar pb_uv width:400 height:4 color:blue value:0
	)

	group "5. 顶点 Alpha 通道"
	(
		checkbox chk_alpha "检查 -2:Alpha 跨几何顶点共享" checked:true
		button btn_fix_alpha "修复" width:50 height:20 align:#right offset:[0,-25]
		progressbar pb_alpha width:400 height:4 color:blue value:0
	)

	group "6. 珍珠检查"
	(
		checkbox chk_pearl_id "检查 _MBB 珍珠面及对应材质的 ID 为 1" checked:true
		button btn_fix_pearl_id "修复" width:50 height:20 align:#right offset:[0,-25]
		progressbar pb_pearl_id width:400 height:4 color:blue value:0
		checkbox chk_pearl_map "检查是否已经执行珍珠映射" checked:false
		button btn_fix_pearl_map "复原" width:50 height:20 align:#right offset:[0,-25]
		progressbar pb_pearl_map width:400 height:4 color:blue value:0
		checkbox chk_pearl_count_prompt "全部检查时确认 _MBB 模型数量" checked:false
	)
	
	-- 主要操作按钮
	group "操作"
	(
		button btn_check_all "全部检查" width:112 height:30 color:(color 70 130 180) across:4
		button btn_fix_all "全部修复" width:112 height:30 color:(color 60 179 113)
		button btn_clear_log "清除日志" width:112 height:30
		button btn_refresh "刷新" width:112 height:30
	)
	
	-- RichTextBox 必须直接属于 Rollout；Max 2020 中放在 group 内可能得到空 .NET 控件。
	label lbl_log_title "检查日志" pos:[16,605] width:508 height:18
	dotNetControl log_display "System.Windows.Forms.RichTextBox" pos:[16,625] width:508 height:325
	
	-- 获取当前单位设置
	fn getCurrentUnit =
	(
		case units.SystemType of
		(
			#kilometers: "千米"
			#meters: "米"
			#centimeters: "厘米"
			#millimeters: "毫米"
			#inches: "英寸"
			#feet: "英尺"
			default: "未知"
		)
	)
	
	-- 添加日志
	fn resolveLogLevel msg requestedLevel =
	(
		if requestedLevel != #auto then return requestedLevel
		-- v1.x 日志调用没有等级参数；只在追加该行时兼容它们的固定前缀。
		if matchPattern msg pattern:"✗*" or matchPattern msg pattern:"轴心错误:*" or
			matchPattern msg pattern:"缩放错误:*" or matchPattern msg pattern:"UV错误:*" or
			matchPattern msg pattern:"珍珠ID提示:*" then #problem
		else if matchPattern msg pattern:"✓*" then #success
		else #info
	)

	fn renderLog =
	(
		logText = ""
		for messageText in logMessages do logText += messageText + "\r\n"
		try (log_display.Text = logText) catch ()

		try
		(
			for messageIndex = 1 to logMessages.count do
			(
				local targetColor = case logLevels[messageIndex] of
				(
					#problem: logProblemColor
					#blocked: logProblemColor
					#success: logSuccessColor
					default: logNormalColor
				)
				local lineStart = log_display.GetFirstCharIndexFromLine (messageIndex - 1)
				log_display.Select lineStart logMessages[messageIndex].count
				log_display.SelectionColor = targetColor
			)
			log_display.Select log_display.Text.count 0
		)
		catch ()
	)

	fn addLog msg level:#auto =
	(
		append logMessages msg
		append logLevels (resolveLogLevel msg level)
		renderLog()
	)
	
	-- 清除日志
	fn clearLog =
	(
		logText = ""
		logMessages = #()
		logLevels = #()
		try (log_display.Text = "") catch ()
	)
	
	-- 重置进度条
	fn resetProgressBars =
	(
		pb_units.value = 0
		pb_transform.value = 0
		pb_uv.value = 0
		pb_alpha.value = 0
		pb_pearl_id.value = 0
		pb_pearl_map.value = 0
	)

	fn clearTransformCheckCache =
	(
		transformCheckCache = #()
	)

	fn findTransformCacheIndex obj forceFlip:false =
	(
		if obj == undefined or not isValidNode obj then return 0
		local nodeHandle = JX_QAChar_GetAnimHandleString obj
		for cacheIndex = 1 to transformCheckCache.count do
		(
			local cacheEntry = transformCheckCache[cacheIndex]
			if cacheEntry.nodeHandle == nodeHandle and cacheEntry.forceFlip == forceFlip do return cacheIndex
		)
		0
	)

	fn invalidateTransformCache obj =
	(
		if obj == undefined then return false
		local nodeHandle = JX_QAChar_GetAnimHandleString obj
		for cacheIndex = transformCheckCache.count to 1 by -1 do
			if transformCheckCache[cacheIndex].nodeHandle == nodeHandle do deleteItem transformCheckCache cacheIndex
		true
	)

	fn storeTransformInspection inspection forceFlip:false =
	(
		if inspection == undefined or inspection.node == undefined or not isValidNode inspection.node then return false
		local cacheEntry = JX_QATransformCacheEntry()
		cacheEntry.nodeHandle = JX_QAChar_GetAnimHandleString inspection.node
		cacheEntry.forceFlip = forceFlip
		cacheEntry.signature = JX_QAChar_BuildTransformStateSignature inspection.node forceFlip:forceFlip inspection:inspection preserveSelection:false
		cacheEntry.inspection = inspection
		local existingIndex = findTransformCacheIndex inspection.node forceFlip:forceFlip
		if existingIndex > 0 then transformCheckCache[existingIndex] = cacheEntry
		else append transformCheckCache cacheEntry
		true
	)

	fn getCachedTransformInspection obj forceFlip:false preserveSelection:true =
	(
		local cacheIndex = findTransformCacheIndex obj forceFlip:forceFlip
		if cacheIndex == 0 then return undefined
		local cacheEntry = transformCheckCache[cacheIndex]
		local currentSignature = JX_QAChar_BuildTransformStateSignature obj forceFlip:forceFlip preserveSelection:preserveSelection
		if currentSignature == cacheEntry.signature then
			cacheEntry.inspection
		else
		(
			deleteItem transformCheckCache cacheIndex
			undefined
		)
	)

	fn addTransformInspectionSummary inspection =
	(
		local objName = if inspection.node != undefined and isValidNode inspection.node then inspection.node.name else "<无效对象>"
		local hasProblem = inspection.status == #needsRepair or inspection.status == #blocked
		addLog objName level:(if hasProblem then #problem else #success)

		if inspection.skinCount == 0 then
			addLog "  · 无 Skin：使用干净 Editable Poly 修复流程"
		else
			addLog ("  · Skin 修改器数量：" + inspection.skinCount as string) level:(if inspection.skinCount == 1 then #info else #problem)

		if inspection.needsScale do addLog ("  ✗ 节点缩放：" + inspection.node.scale as string) level:#problem
		if inspection.needsRotation do addLog ("  ✗ 节点旋转需要归零：" + (inspection.node.rotation as eulerAngles) as string) level:#problem
		if inspection.needsPivot do addLog ("  ✗ 轴心坐标需要归零：" + inspection.node.pivot as string) level:#problem
		if inspection.needsFlip do addLog "  ✗ 负变换奇偶性：修复时需要整体翻面" level:#problem
		if inspection.hasLegacyHelpers do addLog "  ✗ 存在 JXQA 临时修改器：需要烘焙清理" level:#problem
		if inspection.businessModifiers.count > 0 and inspection.skinCount == 0 do
			addLog ("  ✗ 修复将烘焙业务修改器：" +
				JX_QAChar_StringArrayToText inspection.businessModifiers separator:", ") level:#problem

		for warningText in inspection.warnings do addLog ("  ✗ 警告：" + warningText) level:#problem
		for blockerText in inspection.blockers do addLog ("  ✗ 阻止原因：" + blockerText) level:#blocked

		case inspection.status of
		(
			#clean: addLog "  ✓ 状态：检查正常" level:#success
			#needsRepair: addLog "  ✗ 状态：可以安全修复" level:#problem
			default: addLog "  ✗ 状态：已阻止" level:#blocked
		)
	)

	fn checkTransforms showDetails:false =
	(
		local objs = for obj in selection collect obj
		if objs.count == 0 then
		(
			addLog "✗ 请先选择要检查的对象" level:#problem
			return false
		)

		local allClean = true
		addLog ("=== 变换、Skin 与面朝向检查：" + objs.count as string + " 个对象 ===")
		for obj in objs do
		(
			local inspection = JX_QAChar_InspectTransformObject obj forceFlip:chk_force_flip.checked preserveSelection:false
			storeTransformInspection inspection forceFlip:chk_force_flip.checked
			addTransformInspectionSummary inspection
			if inspection.status != #clean do allClean = false
			if showDetails do
			(
				addLog "  -- 严格分析报告 --"
				local reportLines = filterString inspection.detailReport "\r\n"
				for reportLine in reportLines where reportLine != "" do
				(
					local problemLine = findString reportLine "需要归一：true" != undefined or
						findString reportLine "需要归零：true" != undefined or
						findString reportLine "处理时翻面：true" != undefined or
						findString reportLine "奇偶性：-1" != undefined or
						findString reportLine "状态：已阻止" != undefined or
						findString reportLine "原因：" == 1
					addLog ("    " + reportLine) level:(if problemLine then #problem else #info)
				)
			)
		)
		try (select objs) catch ()
		pb_transform.value = 100
		allClean
	)

	fn buildBusinessModifierPrompt inspections =
	(
		local text = "检测到以下无 Skin 模型包含其他业务修改器：\n\n"
		for inspection in inspections do
		(
			text += inspection.node.name + "\n"
			text += "  · " + (JX_QAChar_StringArrayToText inspection.businessModifiers separator:", ") + "\n"
		)
		text += "\n继续会创建隐藏备份，并把整个修改器堆栈烘焙为 Editable Poly。"
		text += "\n\n选择“是”：创建备份并继续\n选择“否”：终止本次操作"
		text
	)

	fn repairTransformsBatch =
	(
		local objs = for obj in selection collect obj
		if objs.count == 0 then
		(
			addLog "✗ 请先选择要修复的对象" level:#problem
			return #aborted
		)

		local riskyInspections = #()
		for obj in objs do
		(
			-- 这里只为无 Skin 业务修改器收集一次确认信息。
			-- Skin 的严格分析留到实际处理该对象时执行，避免整批重复分析。
			if (JX_QAChar_GetSkinModifiers obj).count == 0 do
			(
				local unskinnedInspection = getCachedTransformInspection obj forceFlip:false preserveSelection:false
				if unskinnedInspection == undefined do
				(
					unskinnedInspection = JX_QAChar_InspectTransformObject obj forceFlip:false preserveSelection:false
					storeTransformInspection unskinnedInspection forceFlip:false
				)
				if unskinnedInspection.status == #needsRepair and unskinnedInspection.businessModifiers.count > 0 do
					append riskyInspections unskinnedInspection
			)
		)

		local allowBusinessModifierBake = false
		if riskyInspections.count > 0 then
		(
			local confirmation = queryBox (buildBusinessModifierPrompt riskyInspections) title:"JX 模型安全修复"
			if not confirmation then
			(
				addLog "✗ 用户终止操作：没有修改任何模型" level:#blocked
				return #aborted
			)
			allowBusinessModifierBake = true
		)

		local repairedCount = 0
		local skippedCount = 0
		local blockedCount = 0
		local failedCount = 0
		local reusedInspectionCount = 0
		local freshInspectionCount = 0
		addLog ("=== 开始批量变换修复：" + objs.count as string + " 个对象 ===")

		for objectIndex = 1 to objs.count do
		(
			local obj = objs[objectIndex]
			local inspection = getCachedTransformInspection obj forceFlip:chk_force_flip.checked preserveSelection:false
			if inspection == undefined then
			(
				freshInspectionCount += 1
				inspection = JX_QAChar_InspectTransformObject obj forceFlip:chk_force_flip.checked preserveSelection:false
				storeTransformInspection inspection forceFlip:chk_force_flip.checked
			)
			else
				reusedInspectionCount += 1
			pb_transform.value = ((100.0 * (objectIndex - 1)) / objs.count) as integer
			if inspection.status == #blocked then
			(
				blockedCount += 1
				addLog ("✗ 已阻止：" + obj.name + " - " +
					JX_QAChar_StringArrayToText inspection.blockers separator:"；") level:#blocked
			)
			else if inspection.status == #clean then
			(
				skippedCount += 1
				addLog ("✓ 无需修复：" + obj.name) level:#success
			)
			else
			(
				local result = JX_QAChar_RepairTransformObject obj createBackup:chk_backup.checked allowBusinessModifierBake:allowBusinessModifierBake forceFlip:chk_force_flip.checked preInspection:inspection
				invalidateTransformCache obj
				if result[1] then
				(
					repairedCount += 1
					addLog ("✓ 变换修复：" + obj.name + " - " + result[3]) level:#success
				)
				else
				(
					local preflightBlocked = findString result[3] "已阻止：" == 1 or
						findString result[3] "状态：已阻止" != undefined
					if preflightBlocked then
					(
						blockedCount += 1
						addLog ("✗ 状态变化，未执行修复：" + obj.name + " - " + result[3]) level:#blocked
					)
					else
					(
						failedCount += 1
						addLog ("✗ 修复失败并已回滚：" + obj.name + " - " + result[3]) level:#problem
					)
				)
			)
		)

		try (select objs) catch ()
		pb_transform.value = 100
		addLog ("变换检查结果：复用 " + reusedInspectionCount as string +
			"，现场检查 " + freshInspectionCount as string)
		addLog ("变换修复汇总：成功 " + repairedCount as string +
			"，无需处理 " + skippedCount as string +
			"，已阻止 " + blockedCount as string +
			"，失败并回滚 " + failedCount as string) level:(if failedCount > 0 or blockedCount > 0 then #problem else #success)
		if failedCount == 0 then #completed else #failed
	)
	
	
	-- 检查单位设置
	fn checkUnits =
	(
		local result = false
		local failureText = ""
		if JX_SkinnedRepairCore == undefined then
		(
			failureText = "单位检查核心没有加载"
			if JX_QACharCoreLoadError != undefined do
				failureText += "：" + JX_QACharCoreLoadError as string
		)
		else
		(
			try
				(result = JX_SkinnedRepairCore.unitsAreCentimeters())
			catch
				(failureText = try (getCurrentException() as string) catch ("未知错误"))
		)
		pb_units.value = 100
		if result then
			addLog "✓ 单位设置正确（SystemScale=1，SystemType=#centimeters，DisplayType=#Metric，MetricType=#centimeters）"
		else
		(
			local metricTypeText = try (units.MetricType as string) catch ("不可用")
			addLog ("✗ 单位设置错误：SystemType=" + units.SystemType as string +
				"，SystemScale=" + units.SystemScale as string +
				"，DisplayType=" + units.DisplayType as string +
				"，MetricType=" + metricTypeText)
			if failureText != "" do addLog ("单位检查失败：" + failureText)
			addLog "应该设置为：SystemScale=1，SystemType=#centimeters，DisplayType=#Metric，MetricType=#centimeters"
		)
		
		return result
	)
	
	-- 检查UV通道
	fn checkUV =
	(
		local errorCount = 0
		local checkedCount = 0
		
		for obj in selection do
		(
			if isKindOf obj Editable_mesh or isKindOf obj Editable_Poly then
			(
				checkedCount += 1
				-- 检查UV通道数量
				local uvChannels = meshop.getNumMaps obj.mesh
				if uvChannels > 3 then
				(
					errorCount += 1
					addLog ("UV错误: " + obj.name + " - UV通道数: " + uvChannels as string)
				)
			)
		)
		
		pb_uv.value = 100
		
		if checkedCount == 0 then
		(
			addLog "请先选择网格对象进行检查"
			return false
		)
		
		if errorCount == 0 then
			addLog "✓ UV通道检查通过"
		else
			addLog ("✗ 发现 " + errorCount as string + " 个UV问题")
			
		return (errorCount == 0)
	)

	fn checkAlpha =
	(
		local errorCount = 0
		local checkedCount = 0

		for obj in selection do
		(
			local result = JX_QAChar_AnalyzeAlphaObject obj
			case result[1] of
			(
				#unsupported:
				addLog ("跳过Alpha检查: " + obj.name + " - " + result[5])
				#none:
				(
					checkedCount += 1
					addLog ("✓ Alpha检查: " + obj.name + " - " + result[5])
				)
				#valid:
				(
					checkedCount += 1
					addLog ("✓ Alpha检查: " + obj.name + " - 数据顶点 " + result[2] as string + "，索引关系正常")
				)
				#shared:
				(
					checkedCount += 1
					errorCount += 1
					addLog ("✗ Alpha错误: " + obj.name + " - 数据顶点 " + result[2] as string +
						"，跨点共享索引 " + result[3] as string + " 个，影响几何点 " + result[4] as string + " 个")
				)
				#invalid:
				(
					checkedCount += 1
					errorCount += 1
					addLog ("✗ Alpha结构错误: " + obj.name + " - " + result[5])
				)
			)
		)

		pb_alpha.value = 100

		if checkedCount == 0 then
		(
			addLog "请先选择底层为可编辑多边形或可编辑网格的对象"
			return false
		)

		if errorCount == 0 then
			addLog "✓ 顶点 Alpha 通道检查通过"
		else
			addLog ("✗ 发现 " + errorCount as string + " 个顶点 Alpha 通道问题")

		return (errorCount == 0)
	)

	fn fixAlpha =
	(
		local repairedCount = 0
		local skippedCount = 0
		local failedCount = 0

		for obj in selection do
		(
			local beforeResult = JX_QAChar_AnalyzeAlphaObject obj
			if beforeResult[1] == #unsupported then
			(
				skippedCount += 1
				addLog ("跳过Alpha修复: " + obj.name + " - " + beforeResult[5])
			)
			else
			(
				local result = JX_QAChar_RepairAlphaObject obj
				if result[1] then
				(
					if beforeResult[1] == #shared then
					(
						repairedCount += 1
						addLog ("✓ Alpha修复: " + obj.name + " - 数据顶点 " +
							result[2] as string + " → " + result[3] as string)
					)
					else
					(
						skippedCount += 1
						addLog ("✓ Alpha修复: " + obj.name + " - " + result[4])
					)
				)
				else
				(
					failedCount += 1
					addLog ("✗ Alpha修复失败: " + obj.name + " - " + result[4])
				)
			)
		)

		pb_alpha.value = 100
		addLog ("Alpha修复汇总: 已修复 " + repairedCount as string +
			"，无需处理/跳过 " + skippedCount as string + "，失败 " + failedCount as string)
		return (failedCount == 0)
	)

	fn checkPearlMaterialID expectedCount:undefined =
	(
		local errorCount = 0
		local pearlCount = 0
		local unsupportedCount = 0
		local countMismatch = false

		if selection.count == 0 then
		(
			pb_pearl_id.value = 100
			addLog "请先选择要检查的对象"
			return false
		)

		for obj in selection do
		(
			local result = JX_QAChar_AnalyzePearlMaterialID obj
			local status = result[1]
			case status of
			(
				#unsupported:
					unsupportedCount += 1
				#none:
					()
				#unused:
				(
					pearlCount += 1
					addLog ("珍珠ID提示: " + obj.name + " - " + result[2])
				)
				#valid:
				(
					pearlCount += 1
					addLog ("✓ 珍珠ID检查: " + obj.name + " - " +
						JX_QAChar_StringArrayToText result[11] + "，Material ID=1，命中 " +
						result[12] as string + " 个面")
				)
				#wrong:
				(
					pearlCount += 1
					errorCount += 1
					addLog ("✗ 珍珠ID错误: " + obj.name + " - " +
						JX_QAChar_StringArrayToText result[11] + "，当前 ID=" +
						result[10] as string + "，命中 " + result[12] as string +
						" 个面；要求材质及对应面 ID=1")
				)
				#ambiguous:
				(
					pearlCount += 1
					errorCount += 1
					addLog ("✗ 珍珠ID无法无损修复: " + obj.name + " - " + result[2])
				)
			)
		)

		pb_pearl_id.value = 100
		if expectedCount != undefined then
		(
			countMismatch = pearlCount != expectedCount
			if countMismatch then
			(
				errorCount += 1
				addLog ("✗ 珍珠数量不匹配：用户确认 " + expectedCount as string +
					" 个，实际识别到 " + pearlCount as string +
					" 个使用 _MBB 材质的模型；请修改珍珠材质球命名后缀为 _MBB") level:#problem
			)
			else
				addLog ("✓ 珍珠数量校验通过：" + pearlCount as string + " 个 _MBB 模型") level:#success
		)

		if pearlCount == 0 and not countMismatch then
			addLog "✓ 当前选择中未发现使用 _MBB 材质的珍珠模型"
		else if errorCount == 0 then
			addLog ("✓ 珍珠材质 ID 检查通过，共 " + pearlCount as string + " 个对象")
		else if not countMismatch or errorCount > 1 then
			addLog ("✗ 发现 " + errorCount as string + " 个珍珠材质 ID 问题")

		if unsupportedCount > 0 do
			addLog ("珍珠ID检查跳过 " + unsupportedCount as string + " 个不支持的对象")
		return (errorCount == 0)
	)

	fn fixPearlMaterialID =
	(
		local repairedCount = 0
		local skippedCount = 0
		local failedCount = 0

		if selection.count == 0 then
		(
			pb_pearl_id.value = 100
			addLog "请先选择要修复的对象"
			return false
		)

		for obj in selection do
		(
			local beforeResult = JX_QAChar_AnalyzePearlMaterialID obj
			case beforeResult[1] of
			(
				#wrong:
				(
					local repairResult = JX_QAChar_RepairPearlMaterialID obj
					if repairResult[1] then
					(
						repairedCount += 1
						addLog ("✓ 珍珠ID修复: " + obj.name + " - " + repairResult[3] +
							"，修改 " + repairResult[4] as string + " 个面的 ID")
					)
					else
					(
						failedCount += 1
						addLog ("✗ 珍珠ID修复失败: " + obj.name + " - " + repairResult[3])
					)
				)
				#ambiguous:
				(
					failedCount += 1
					addLog ("✗ 跳过珍珠ID修复: " + obj.name + " - " + beforeResult[2])
				)
				default:
					skippedCount += 1
			)
		)

		pb_pearl_id.value = 100
		addLog ("珍珠ID修复汇总: 已修复 " + repairedCount as string +
			"，无需处理/跳过 " + skippedCount as string + "，失败 " + failedCount as string)
		redrawViews()
		return (failedCount == 0)
	)

	fn checkPearlMapState =
	(
		local errorCount = 0
		local checkedCount = 0
		local skippedCount = 0

		if selection.count == 0 then
		(
			pb_pearl_map.value = 100
			addLog "请先选择要检查的对象"
			return false
		)

		for obj in selection do
		(
			local inspection = JX_QAChar_AnalyzePearlMapState obj
			case inspection.status of
			(
				#none:
					skippedCount += 1
				#unprocessed:
				(
					checkedCount += 1
					addLog ("✓ 珍珠映射检查: " + obj.name + " - 未执行；" +
						inspection.message + "（" + inspection.elapsedMs as string + " ms）")
				)
				#restored:
				(
					checkedCount += 1
					addLog ("✓ 珍珠映射检查: " + obj.name + " - 已复原（" +
						inspection.elapsedMs as string + " ms）")
				)
				#processed:
				(
					checkedCount += 1
					errorCount += 1
					addLog ("✗ 珍珠映射已运行: " + obj.name + " - " + inspection.message +
						(if inspection.repairable then "；可以安全复原" else "；无法自动复原") +
						"（" + inspection.elapsedMs as string + " ms）") level:#problem
				)
				#partial:
				(
					checkedCount += 1
					errorCount += 1
					addLog ("✗ 珍珠映射部分运行: " + obj.name + " - " + inspection.message +
						(if inspection.repairable then "；可以安全复原" else "；无法自动复原") +
						"（" + inspection.elapsedMs as string + " ms）") level:#problem
				)
				default:
				(
					checkedCount += 1
					errorCount += 1
					addLog ("✗ 珍珠映射状态异常: " + obj.name + " - " + inspection.message +
						"（" + inspection.elapsedMs as string + " ms）") level:#problem
				)
			)
		)

		pb_pearl_map.value = 100
		if checkedCount == 0 then
			addLog "✓ 当前选择中未发现可检查的 _MBB 珍珠模型"
		else if errorCount == 0 then
			addLog ("✓ 珍珠映射状态检查通过，共 " + checkedCount as string + " 个对象")
		else
			addLog ("✗ 发现 " + errorCount as string + " 个珍珠映射状态问题")
		if skippedCount > 0 do
			addLog ("珍珠映射检查跳过 " + skippedCount as string + " 个非珍珠/不支持对象")
		return (errorCount == 0)
	)

	fn fixPearlMapState =
	(
		local repairedCount = 0
		local skippedCount = 0
		local failedCount = 0

		if selection.count == 0 then
		(
			pb_pearl_map.value = 100
			addLog "请先选择要复原的对象"
			return false
		)

		for obj in selection do
		(
			local inspection = JX_QAChar_AnalyzePearlMapState obj
			if inspection.status == #processed or inspection.status == #partial then
			(
				local result = JX_QAChar_RepairPearlMapState obj createBackup:true
				if result[1] then
				(
					repairedCount += 1
					addLog ("✓ 珍珠映射复原: " + obj.name + " - " + result[3])
				)
				else
				(
					failedCount += 1
					addLog ("✗ 珍珠映射复原失败: " + obj.name + " - " + result[3]) level:#problem
				)
			)
			else if inspection.status == #markerStale then
			(
				local result = JX_QAChar_RepairPearlMapState obj createBackup:false
				if result[1] then
				(
					repairedCount += 1
					addLog ("✓ 珍珠映射标记修正: " + obj.name + " - " + result[3])
				)
				else
				(
					failedCount += 1
					addLog ("✗ 珍珠映射标记修正失败: " + obj.name + " - " + result[3]) level:#problem
				)
			)
			else if inspection.status == #damaged then
			(
				failedCount += 1
				addLog ("✗ 跳过珍珠映射复原: " + obj.name + " - " + inspection.message) level:#problem
			)
			else
				skippedCount += 1
		)

		pb_pearl_map.value = 100
		addLog ("珍珠映射复原汇总: 已复原/更新 " + repairedCount as string +
			"，无需处理/跳过 " + skippedCount as string + "，失败 " + failedCount as string)
		redrawViews()
		return (failedCount == 0)
	)
	
	-- 修复函数
	fn fixNormals = (
		repairTransformsBatch()
	)

	fn fixNames = 
	(
		for obj in selection do
		(
			local objName = JXCharQATool.lowercase obj.name
			local checkResult = false
			local fileNameStr = substring maxfilename 1 (maxfilename.count - 4)

			for namingBack in JXCharQATool.namingBacks do 
			(
				local backPos = findString objName namingBack
				if (backPos != undefined) then 
				(
					checkResult = true
					obj.name = JXCharQATool.formatUnderscoreString objName
					obj.name = fileNameStr + (substring obj.name backPos objName.count)
					exit
				)
				
			)
			if(checkResult == false) then 
			(
				addLog ("✗命名规范： " + obj.name + " 为未知 命名 物体，注意筛查")
			)
		)
	)

	fn fixUnits =
	(
		if JX_SkinnedRepairCore == undefined then
		(
			local failureText = "✗ 单位修复失败：单位修复核心没有加载"
			if JX_QACharCoreLoadError != undefined do
				failureText += "：" + JX_QACharCoreLoadError as string
			addLog failureText
			return false
		)

		local failureText = ""
		try
			(JX_SkinnedRepairCore.setUnitsToCentimeters())
		catch
			(failureText = try (getCurrentException() as string) catch ("未知错误"))
		lbl_unit_value.text = getCurrentUnit()
		if failureText != "" then
		(
			addLog ("✗ 单位修复失败：" + failureText)
			false
		)
		else
			checkUnits()
	)

	fn fixUvs = 
	(
		local objs = for obj in selection collect obj
		for obj in objs do
		(
			local uvChannels = meshop.getNumMaps obj.mesh
			if (uvChannels <= 3) then continue

			if (JX_QAChar_GetSkinModifiers obj).count > 0 then
			(
				addLog ("✗ 跳过带 Skin 的 UV 自动修复：" + obj.name +
					" - 当前版本不会冒险塌陷蒙皮堆栈") level:#blocked
				continue
			)

			max modify mode
			undo on (
				for i = uvChannels to 3 by -1 do 
				(
					channelInfo.ClearChannel obj i
					modPanel.setCurrentObject obj.baseObject
					modPanel.addModToSelection(UVW_Mapping_Clear())
					deleteModifier obj 1
					if(obj.modifiers[#Skin] != undefined) then 
					(
						maxOps.CollapseNodeTo obj 2 true
					)else(
						maxOps.CollapseNodeTo obj 1 true
					)
					
				)
			)
			addLog ("✓ 已删除 " + obj.name + "的多余通道")
		)

	)
	
	-- 界面初始化
	on ModelCheckerTool open do
	(
		local colorClass = dotNetClass "System.Drawing.Color"
		local borderStyleClass = dotNetClass "System.Windows.Forms.BorderStyle"
		local scrollBarsClass = dotNetClass "System.Windows.Forms.RichTextBoxScrollBars"
		logNormalColor = colorClass.Gainsboro
		logProblemColor = colorClass.FromArgb 255 96 96
		logSuccessColor = colorClass.FromArgb 120 220 150
		logBackgroundColor = colorClass.FromArgb 64 64 64
		log_display.ReadOnly = true
		log_display.BackColor = logBackgroundColor
		log_display.ForeColor = logNormalColor
		log_display.BorderStyle = borderStyleClass.FixedSingle
		log_display.ScrollBars = scrollBarsClass.Both
		log_display.WordWrap = false
		log_display.DetectUrls = false
		lbl_unit_value.text = getCurrentUnit()
		addLog "=== MAX 模型检查工具已启动 ==="
		addLog "请选择要检查的对象，然后点击相应的检查按钮"
	)
	
	-- 事件处理
	on btn_check_all pressed do
	(
		local expectedPearlCount = undefined
		if chk_pearl_id.checked and chk_pearl_count_prompt.checked then
		(
			expectedPearlCount = JX_QAChar_RequestExpectedPearlCount()
			if expectedPearlCount == undefined then return false
		)

		clearLog()
		resetProgressBars()
		addLog "=== 开始全部检查 ==="
		
		if chk_units.checked then checkUnits()
		if chk_transform.checked then checkTransforms()
		if chk_uv.checked then checkUV()
		if chk_alpha.checked then checkAlpha()
		if chk_pearl_id.checked then checkPearlMaterialID expectedCount:expectedPearlCount
		if chk_pearl_map.checked then checkPearlMapState()
		
		addLog "=== 检查完成 ==="
	)
	
	on btn_fix_all pressed do
	(
		addLog "=== 开始全部修复 ==="

		fixNames()
		if chk_units.checked then fixUnits()
		if chk_transform.checked then
		(
			local transformRepairStatus = repairTransformsBatch()
			if transformRepairStatus == #aborted then return false
		)
		if chk_uv.checked then fixUvs()
		if chk_alpha.checked then fixAlpha()
		if chk_pearl_map.checked then fixPearlMapState()
		if chk_pearl_id.checked then fixPearlMaterialID()
		addLog "=== 修复完成，开始自动复检 ==="
		if chk_units.checked then checkUnits()
		if chk_transform.checked then checkTransforms()
		if chk_uv.checked then checkUV()
		if chk_alpha.checked then checkAlpha()
		if chk_pearl_id.checked then checkPearlMaterialID()
		if chk_pearl_map.checked then checkPearlMapState()
		addLog "=== 自动复检完成 ==="
	)
	

	on btn_fix_naming pressed do fixNames()
	on btn_fix_units pressed do fixUnits()
	on btn_fix_normals pressed do fixNormals()
	on btn_analyze_transform pressed do
	(
		addLog "=== 详细变换分析 ==="
		checkTransforms showDetails:true
	)
	on btn_fix_uv pressed do fixUvs()
	on btn_fix_alpha pressed do fixAlpha()
	on btn_fix_pearl_id pressed do fixPearlMaterialID()
	on btn_fix_pearl_map pressed do fixPearlMapState()

	on btn_clear_log pressed do clearLog()

	on btn_refresh pressed do
	(
		clearTransformCheckCache()
		lbl_unit_value.text = getCurrentUnit()
		resetProgressBars()
		addLog "界面已刷新"
	)
)

global JX_QAChar_Show

function JX_QAChar_Show =
(
	try (destroyDialog ModelCheckerTool) catch ()
	createDialog ModelCheckerTool 540 970
)


macroScript JX_QAChar
category:"JXTools"
toolTip:"角色模型规范检查 v2.0.6"
buttonText:"角色模型规范检查"
(
	on execute do JX_QAChar_Show()
)
