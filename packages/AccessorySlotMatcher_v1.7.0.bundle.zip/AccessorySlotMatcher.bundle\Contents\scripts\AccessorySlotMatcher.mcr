/*
    挂件匹配插槽坐标 v1.7.0
    CompanyPluginManager Bundle entry point.
    Author: 毛老师
*/
global HAM_DragDrop_Rollout
global HAM_DD_GetTM
global HAM_DD_DetectBody
global HAM_DD_RotatePivotOnly
global HAM_DD_GetPivotRotation
global HAM_DD_Apply

fn HAM_DD_GetTM bodyType slotType =
(
    case (bodyType + "_" + slotType) of
    (
        "F1_earL":       (matrix3 [1,0,0] [0,0,1] [0,-1,0] [-5.83556,-2.32326,110.676])
        "F1_earR":       (matrix3 [1,0,0] [0,0,1] [0,-1,0] [5.83474,-2.32325,110.676])
        "F1_MaskL_bone": (matrix3 [1,0,0] [0,0,1] [0,-1,0] [-0.0004071,-8.66582,106.725])
        "F1_MaskU_bone": (matrix3 [1,0,0] [0,0,1] [0,-1,0] [0.00000953674,-10.4345,127.067])
        "F1_neck":       (matrix3 [1,0,0] [0,0,1] [0,-1,0] [-0.00000965595,-1.02124,103.166])
        "F1_neckChest":  (matrix3 [0.000001351,0.025803435,0.999667036] [-1,0.000001402,0.000001315] [-0.000001367,-0.999667036,0.025803435] [0.0000199114,-4.58655168,84.42435264])

        "F2_earL":       (matrix3 [1,0,0] [0,0,1] [0,-1,0] [-5.83501,-0.784576,156.004])
        "F2_earR":       (matrix3 [1,0,0] [0,0,1] [0,-1,0] [5.83529,-0.784574,156.004])
        "F2_MaskL_bone": (matrix3 [1,0,0] [0,0,1] [0,-1,0] [0.000135183,-8.63398,150.367])
        "F2_MaskU_bone": (matrix3 [1,0,0] [0,0,1] [0,-1,0] [0.150999,-8.88899,176.486])
        "F2_neck":       (matrix3 [1,0,0] [0,0,1] [0,-1,0] [-0.00000159605,1.01543,145.936])
        "F2_neckChest":  (matrix3 [0.000001257,0.090305769,0.995914087] [-1,0.000001391,0.000001136] [-0.000001283,-0.995914087,0.090305769] [0.000569775,-5.00867177,123.63580149])

        "M2_earL":       (matrix3 [1,0,0] [0,0,1] [0,-1,0] [-5.83555,-0.00457883,171.444])
        "M2_earR":       (matrix3 [1,0,0] [0,0,1] [0,-1,0] [5.83475,-0.00457597,171.444])
        "M2_MaskL_bone": (matrix3 [1,0,0] [0,0,1] [0,-1,0] [-0.000403106,-6.74653,166.034])
        "M2_MaskU_bone": (matrix3 [1,0,0] [0,0,1] [0,-1,0] [0.00000572205,-7.20999,192.151])
        "M2_neck":       (matrix3 [1,0,0] [0,0,1] [0,-1,0] [-0.000000539348,3.16376,161.489])
        "M2_neckChest":  (matrix3 [0.000001257,0.090306099,0.995914057] [-1,0.000001391,0.000001136] [-0.000001283,-0.995914057,0.090306099] [0.0000337166,-3.27254990,134.70088241])
        "M2_behind":     (matrix3 [1,0,0] [0,0,1] [0,-1,0] [-0.0000400543,25.7361,148.282])
        default: undefined
    )
)

fn HAM_DD_DetectBody nodes fallback =
(
    for n in nodes do
    (
        local upperName = toUpper n.name
        if (matchPattern upperName pattern:"*_F1*") or (matchPattern upperName pattern:"F1_*") do return "F1"
        if (matchPattern upperName pattern:"*_F2*") or (matchPattern upperName pattern:"F2_*") do return "F2"
        if (matchPattern upperName pattern:"*_M2*") or (matchPattern upperName pattern:"M2_*") do return "M2"
    )
    fallback
)

fn HAM_DD_RotatePivotOnly obj rotation =
(
    local rotValInv = inverse (rotation as quat)
    animate off in coordsys local obj.rotation *= rotValInv
    obj.objectOffsetPos *= rotValInv
    obj.objectOffsetRot *= rotValInv
)

fn HAM_DD_GetPivotRotation bodyType slotType targetTM =
(
    if slotType == "neckChest" then
    (
        case bodyType of
        (
            "F1": (EulerAngles 90 -88.521408 90)
            "F2": (EulerAngles 90 -84.818802 90)
            "M2": (EulerAngles 90 -84.818783 90)
            default: (inverse targetTM.rotationPart)
        )
    )
    else
    (
        inverse targetTM.rotationPart
    )
)

fn HAM_DD_Apply bodyType slotType =
(
    local nodes = selection as array
    if nodes.count == 0 then
    (
        messageBox "请先选择需要匹配的挂件模型。" title:"挂件匹配插槽坐标"
        return false
    )

    local targetTM = HAM_DD_GetTM bodyType slotType
    if targetTM == undefined then return false

    undo "挂件匹配插槽坐标" on
    (
        for n in nodes do
        (
            n.pivot = targetTM.translationPart
            WorldAlignPivot n
            HAM_DD_RotatePivotOnly n (HAM_DD_GetPivotRotation bodyType slotType targetTM)
        )
    )
    redrawViews()
    true
)

try(destroyDialog HAM_DragDrop_Rollout)catch()
rollout HAM_DragDrop_Rollout "挂件匹配插槽坐标 v1.7.0" width:356 height:422
(
    groupBox gbBody "1. 选择体型" pos:[10,10] width:336 height:62
    radioButtons rbBody labels:#("F1", "F2", "M2") default:1 columns:3 pos:[54,35]
    checkbox chkAuto "根据所选模型名称自动识别 F1/F2/M2" checked:false pos:[24,82]

    groupBox gbSlot "2. 一键匹配插槽" pos:[10,108] width:336 height:224
    button btnEarL "earL：耳饰（画面左）" pos:[22,132] width:154 height:32
    button btnEarR "earR：耳饰（画面右）" pos:[182,132] width:154 height:32
    button btnMaskL "MaskL：面具" pos:[22,170] width:154 height:32
    button btnMaskU "MaskU：头饰" pos:[182,170] width:154 height:32
    button btnNeck "neck：项链" pos:[22,208] width:154 height:32
    button btnBehind "behind：背挂M2" pos:[182,208] width:154 height:32
    button btnNeckChest "neck：项链（胸）" pos:[22,246] width:314 height:32
    label lblBehind "提示：behind 固定使用 M2 坐标" pos:[22,292] width:300 height:18

    label lblMode "仅修改轴心坐标，模型保持在原位不移动。" pos:[22,344] width:320 height:18
    label lblHint "选择模型后点击上方按钮；所有操作均可 Ctrl+Z 撤销。" pos:[22,372] width:320 height:18
    label lblStatus "就绪：已内置 19 个插槽坐标" pos:[22,394] width:320 height:18

    fn currentBody =
    (
        local body = #("F1","F2","M2")[rbBody.state]
        if chkAuto.checked and selection.count > 0 do body = HAM_DD_DetectBody (selection as array) body
        body
    )

    fn applySlot slotName displayName forceM2:false =
    (
        local body = if forceM2 then "M2" else currentBody()
        if HAM_DD_Apply body slotName do lblStatus.text = ("匹配完成：" + displayName + " / " + body)
    )

    on btnEarL pressed do applySlot "earL" "耳饰（画面左）"
    on btnEarR pressed do applySlot "earR" "耳饰（画面右）"
    on btnMaskL pressed do applySlot "MaskL_bone" "面具"
    on btnMaskU pressed do applySlot "MaskU_bone" "头饰"
    on btnNeck pressed do applySlot "neck" "项链"
    on btnBehind pressed do applySlot "behind" "背挂M2" forceM2:true
    on btnNeckChest pressed do applySlot "neckChest" "项链（胸）"
)

macroScript AccessorySlotMatcher
category:"JXTools"
toolTip:"挂件匹配插槽坐标 v1.7.0"
buttonText:"挂件匹配插槽坐标"
(
    on execute do
    (
        try(destroyDialog HAM_DragDrop_Rollout)catch()
        createDialog HAM_DragDrop_Rollout style:#(#style_titlebar, #style_sysmenu, #style_toolwindow)
    )
)
