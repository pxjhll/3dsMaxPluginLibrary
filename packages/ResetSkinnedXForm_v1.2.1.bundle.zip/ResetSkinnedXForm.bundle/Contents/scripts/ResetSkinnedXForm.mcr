﻿/*
    Reset Skinned XForm
    Version 1.2.1

    Safely resets the transform of a skinned geometry node and flips all faces
    without removing or rebuilding its Skin modifier.

    Designed for 3ds Max 2020+.
*/

global RSXF_Core
global RSXF_Rollout

struct RSXF_CoreStruct
(
    version = "1.2.1",
    positionTolerance = 0.001,
    weightTolerance = 0.000001,

    fn appendLine text value =
    (
        text + value + "\r\n"
    ),

    fn matrixDifference a b =
    (
        local d = 0.0
        d = amax d (distance a.row1 b.row1)
        d = amax d (distance a.row2 b.row2)
        d = amax d (distance a.row3 b.row3)
        d = amax d (distance a.row4 b.row4)
        d
    ),

    fn getLocalTM node =
    (
        if node.parent == undefined then node.transform
        else node.transform * (inverse node.parent.transform)
    ),

    fn getParity tm =
    (
        try (tm.determinantsign) catch (0)
    ),

    fn getSkinModifiers node =
    (
        for modifierItem in node.modifiers where (classof modifierItem == Skin) collect modifierItem
    ),

    fn hasEditNormals node =
    (
        for modifierItem in node.modifiers do
        (
            if classof modifierItem == Edit_Normals do return true
        )
        false
    ),

    fn transformIsAnimated node referenceFrame =
    (
        local originalTime = currentTime
        local sampleTimes = #(animationRange.start, referenceFrame, animationRange.end)
        local firstTM = undefined
        local animatedTransform = false

        for sampleTime in sampleTimes while not animatedTransform do
        (
            at time sampleTime
            (
                local sampledTM = getLocalTM node
                if firstTM == undefined then firstTM = sampledTM
                else if matrixDifference firstTM sampledTM > 0.00001 do animatedTransform = true
            )
        )
        sliderTime = originalTime
        animatedTransform
    ),

    fn getInstanceCount node =
    (
        local instanceNodes = #()
        try
        (
            InstanceMgr.GetInstances node &instanceNodes
            instanceNodes.count
        )
        catch
        (
            1
        )
    ),

    fn getDirectChildrenWorldTMs node =
    (
        local childData = #()
        for childNode in node.children do append childData #(childNode, childNode.transform)
        childData
    ),

    fn restoreDirectChildrenWorldTMs childData =
    (
        for item in childData do
        (
            if isValidNode item[1] do
            (
                try (item[1].transform = item[2]) catch ()
            )
        )
    ),

    fn getEvaluatedMeshInfo node sampleLimit:64 =
    (
        local meshValue = snapshotAsMesh node
        local vertexCount = meshValue.numverts
        local faceCount = meshValue.numfaces
        local points = #()
        local stepSize = 1

        if vertexCount > sampleLimit do stepSize = amax 1 (floor (vertexCount as float / sampleLimit))
        for vertexIndex = 1 to vertexCount by stepSize do
        (
            -- snapshotAsMesh returns the evaluated world-state geometry.
            append points (getVert meshValue vertexIndex)
            if points.count >= sampleLimit do exit
        )
        meshValue = undefined
        #(vertexCount, faceCount, points)
    ),

    fn maxPointDifference firstPoints secondPoints =
    (
        if firstPoints.count != secondPoints.count then return 1e9
        local maximumDifference = 0.0
        for pointIndex = 1 to firstPoints.count do
        (
            maximumDifference = amax maximumDifference (distance firstPoints[pointIndex] secondPoints[pointIndex])
        )
        maximumDifference
    ),

    fn capturePoseSamples node referenceFrame extraFrame =
    (
        local originalTime = currentTime
        local sampleTimes = #()
        local result = #()
        local middleFrame = (animationRange.start + animationRange.end) / 2

        for sampleTime in #(referenceFrame, extraFrame, animationRange.start, middleFrame, animationRange.end) do
        (
            if findItem sampleTimes sampleTime == 0 do append sampleTimes sampleTime
        )

        for sampleTime in sampleTimes do
        (
            sliderTime = sampleTime
            append result #(sampleTime, getEvaluatedMeshInfo node)
        )
        sliderTime = originalTime
        result
    ),

    fn validatePoseSamples node savedSamples =
    (
        local originalTime = currentTime
        local maximumError = 0.0
        local countsMatch = true

        for sampleItem in savedSamples while countsMatch do
        (
            sliderTime = sampleItem[1]
            local currentInfo = getEvaluatedMeshInfo node
            local savedInfo = sampleItem[2]
            if currentInfo[1] != savedInfo[1] or currentInfo[2] != savedInfo[2] then
                countsMatch = false
            else
                maximumError = amax maximumError (maxPointDifference savedInfo[3] currentInfo[3])
        )
        sliderTime = originalTime
        #(countsMatch, maximumError)
    ),

    fn captureSkinWeights skinModifier =
    (
        local vertexCount = skinOps.GetNumberVertices skinModifier
        local result = #()
        progressStart "蒙皮模型变换修复：正在记录 Skin 权重……"
        for vertexIndex = 1 to vertexCount do
        (
            local influenceCount = skinOps.GetVertexWeightCount skinModifier vertexIndex
            local boneIDs = #()
            local weights = #()
            local dqWeight = undefined

            for influenceIndex = 1 to influenceCount do
            (
                append boneIDs (skinOps.GetVertexWeightBoneID skinModifier vertexIndex influenceIndex)
                append weights (skinOps.GetVertexWeight skinModifier vertexIndex influenceIndex)
            )
            dqWeight = try (skinOps.getVertexDQWeight skinModifier vertexIndex) catch (undefined)
            append result #(boneIDs, weights, dqWeight)

            if mod vertexIndex 250 == 0 do progressUpdate (100.0 * vertexIndex / vertexCount)
        )
        progressEnd()
        result
    ),

    fn skinWeightsMatch skinModifier savedWeights =
    (
        local vertexCount = skinOps.GetNumberVertices skinModifier
        if vertexCount != savedWeights.count then return false

        local matches = true
        for vertexIndex = 1 to vertexCount while matches do
        (
            local savedVertex = savedWeights[vertexIndex]
            local influenceCount = skinOps.GetVertexWeightCount skinModifier vertexIndex
            if influenceCount != savedVertex[1].count then
            (
                matches = false
            )
            else
            (
                for influenceIndex = 1 to influenceCount while matches do
                (
                    local currentBoneID = skinOps.GetVertexWeightBoneID skinModifier vertexIndex influenceIndex
                    local currentWeight = skinOps.GetVertexWeight skinModifier vertexIndex influenceIndex
                    if currentBoneID != savedVertex[1][influenceIndex] do matches = false
                    if abs (currentWeight - savedVertex[2][influenceIndex]) > weightTolerance do matches = false
                )

                if matches and savedVertex[3] != undefined do
                (
                    local currentDQ = try (skinOps.getVertexDQWeight skinModifier vertexIndex) catch (undefined)
                    if currentDQ == undefined then matches = false
                    else if abs (currentDQ - savedVertex[3]) > weightTolerance do matches = false
                )
            )
        )
        matches
    ),

    fn captureBindSummary node skinModifier =
    (
        local meshBindTM = try (skinUtils.GetMeshBindTM node) catch (undefined)
        local boneCount = try (skinOps.GetNumberBones skinModifier) catch (0)
        local boneData = #()
        for boneIndex = 1 to boneCount do
        (
            local boneNode = try (skinOps.GetBoneNode skinModifier boneIndex) catch (undefined)
            local bindTM = if boneNode != undefined then (try (skinUtils.GetBoneBindTM node boneNode) catch (undefined)) else undefined
            append boneData #(boneNode, bindTM)
        )
        #(meshBindTM, boneData)
    ),

    fn getNamedModifier node modifierName modifierClass =
    (
        for modifierItem in node.modifiers do
        (
            if modifierItem.name == modifierName and classof modifierItem == modifierClass do return modifierItem
        )
        undefined
    ),

    fn hasExistingRepairStack node =
    (
        if node == undefined or not isValidNode node then return false
        local skins = getSkinModifiers node
        if skins.count != 1 or node.modifiers.count != 3 then return false
        local faceFlip = getNamedModifier node "RSXF - Flip Faces" Normalmodifier
        local resetTransform = getNamedModifier node "RSXF - Reset XForm" XForm
        if faceFlip == undefined or resetTransform == undefined then return false
        local flipIndex = modPanel.getModifierIndex node faceFlip
        local skinIndex = modPanel.getModifierIndex node skins[1]
        local resetIndex = modPanel.getModifierIndex node resetTransform
        flipIndex < skinIndex and skinIndex < resetIndex
    ),

    fn captureRenderedNormalSamples node sampleLimit:64 =
    (
        local meshValue = snapshotAsMesh node
        local faceCount = meshValue.numfaces
        local stepSize = 1
        local samples = #()
        if faceCount > sampleLimit do stepSize = amax 1 (floor (faceCount as float / sampleLimit))

        for faceIndex = 1 to faceCount by stepSize do
        (
            local renderNormals = meshop.getFaceRNormals meshValue faceIndex
            local averageNormal = normalize (renderNormals[1] + renderNormals[2] + renderNormals[3])
            append samples #(faceIndex, meshop.getFaceCenter meshValue faceIndex, averageNormal)
            if samples.count >= sampleLimit do exit
        )
        meshValue = undefined
        #(faceCount, samples)
    ),

    fn validateRenderedNormalSamples node savedInfo =
    (
        local meshValue = snapshotAsMesh node
        if meshValue.numfaces != savedInfo[1] then
        (
            meshValue = undefined
            return #(false, -1.0, 1e9)
        )

        local minimumDot = 1.0
        local maximumCenterError = 0.0
        for sampleItem in savedInfo[2] do
        (
            local faceIndex = sampleItem[1]
            local renderNormals = meshop.getFaceRNormals meshValue faceIndex
            local averageNormal = normalize (renderNormals[1] + renderNormals[2] + renderNormals[3])
            local currentCenter = meshop.getFaceCenter meshValue faceIndex
            minimumDot = amin minimumDot (dot sampleItem[3] averageNormal)
            maximumCenterError = amax maximumCenterError (distance sampleItem[2] currentCenter)
        )
        meshValue = undefined
        #(minimumDot > 0.999 and maximumCenterError <= positionTolerance, minimumDot, maximumCenterError)
    ),

    fn bakeRepairStack node =
    (
        local skins = getSkinModifiers node
        if skins.count != 1 do throw "烘焙时必须且只能有一个 Skin 修改器。"
        local skinModifier = skins[1]
        local faceFlip = getNamedModifier node "RSXF - Flip Faces" Normalmodifier
        local resetTransform = getNamedModifier node "RSXF - Reset XForm" XForm
        if faceFlip == undefined or resetTransform == undefined do throw "没有找到预期的 RSXF 修复修改器。"

        local bakedFlip = copy faceFlip
        deleteModifier node (modPanel.getModifierIndex node faceFlip)
        skinModifier = (getSkinModifiers node)[1]
        local skinIndex = modPanel.getModifierIndex node skinModifier
        addModifier node bakedFlip before:skinIndex

        skinModifier = (getSkinModifiers node)[1]
        skinIndex = modPanel.getModifierIndex node skinModifier
        local editablePolyOutput = Edit_Poly()
        editablePolyOutput.name = "RSXF - Bake To Editable Poly"
        addModifier node editablePolyOutput before:skinIndex
        local bakeIndex = modPanel.getModifierIndex node editablePolyOutput
        if not maxOps.CollapseNodeTo node bakeIndex true do throw "无法将修复修改器烘焙到基础对象。"

        if classof node.baseObject != Editable_Poly do throw "烘焙后的基础对象不是可编辑多边形。"
        skins = getSkinModifiers node
        if skins.count != 1 or node.modifiers.count != 1 do throw "最终堆栈不是仅包含 Skin 和可编辑多边形。"
        if classof node.modifiers[1] != Skin do throw "Skin 不是唯一保留的修改器。"
        skins[1]
    ),

    fn createBackupCopy node =
    (
        local clonedNodes = #()
        maxOps.cloneNodes #(node) cloneType:#copy newNodes:&clonedNodes
        if clonedNodes.count != 1 then throw "无法创建安全备份副本。"

        local backupNode = clonedNodes[1]
        backupNode.name = uniqueName (node.name + "_RSXF_BACKUP")
        backupNode.renderable = false
        hide backupNode
        freeze backupNode
        backupNode
    ),

    fn analyze node forceFlip:false =
    (
        local report = ""
        local blockers = #()
        local warnings = #()

        if node == undefined or not isValidNode node then
        (
            append blockers "请选择一个有效的场景节点。"
            return #(false, blockers, warnings, "未选择有效节点。\r\n")
        )

        report = appendLine report ("对象：" + node.name)
        report = appendLine report ("工具版本：" + version)

        if superclassof node != GeometryClass do append blockers "所选节点不是几何体。"
        if isGroupHead node do append blockers "不支持组头节点，请打开组并选择网格节点。"

        local skins = getSkinModifiers node
        local existingRepair = hasExistingRepairStack node
        report = appendLine report ("Skin 修改器数量：" + skins.count as string)
        report = appendLine report ("已有 RSXF 修复堆栈：" + existingRepair as string)
        if skins.count != 1 do append blockers "必须且只能有一个 Skin 修改器。"
        if skins.count == 1 and not existingRepair and node.modifiers.count != 1 do append blockers "为保持最终堆栈干净，修复前除 Skin 外不能有其他修改器。"

        local worldParity = getParity node.transform
        local localParity = getParity (getLocalTM node)
        local parentParity = if node.parent == undefined then 1 else getParity node.parent.transform
        report = appendLine report ("世界变换奇偶性：" + worldParity as string)
        report = appendLine report ("本地变换奇偶性：" + localParity as string)
        report = appendLine report ("父级变换奇偶性：" + parentParity as string)

        if parentParity < 0 do append blockers "负奇偶性继承自父级；当前版本不会修改层级变换。"
        if localParity == 0 or worldParity == 0 do append blockers "变换矩阵为奇异矩阵，无法安全重置。"
        if worldParity >= 0 and not forceFlip and not existingRepair do append blockers "未检测到负变换。仅在确认基础面朝向反转时启用“强制翻面”。"

        local referenceFrame = if skins.count == 1 then (try (skins[1].ref_frame) catch (0)) else 0
        report = appendLine report ("Skin 参考帧：" + referenceFrame as string)
        if transformIsAnimated node referenceFrame do append blockers "网格节点变换带有动画，或继承自动画父级。"

        local instanceCount = getInstanceCount node
        report = appendLine report ("共享该对象的实例数量：" + instanceCount as string)
        if instanceCount > 1 do append blockers "该对象存在实例，请转为唯一对象后再修复。"

        if hasEditNormals node do append blockers "检测到“编辑法线”修改器；当前版本不支持保留显式法线。"

        if node.children.count > 0 and not existingRepair do append warnings ((node.children.count as string) + " 个直接子节点将在重置变换后恢复世界变换。")
        if skins.count == 1 do
        (
            local vertexCount = try (skinOps.GetNumberVertices skins[1]) catch (0)
            local boneCount = try (skinOps.GetNumberBones skins[1]) catch (0)
            report = appendLine report ("Skin 顶点数：" + vertexCount as string)
            report = appendLine report ("Skin 骨骼数：" + boneCount as string)
            if vertexCount < 1 do append blockers "Skin 中没有顶点。"
            if boneCount < 1 do append blockers "Skin 中没有骨骼。"
            local gizmoCount = try (skinOps.getNumberOfGizmos skins[1]) catch (0)
            report = appendLine report ("Skin Gizmo 数量：" + gizmoCount as string)
            if gizmoCount > 0 do append warnings "Skin 中存在 Gizmo；它们会被保留，但修复后必须测试全部驱动姿势。"
        )

        if blockers.count == 0 then report = appendLine report "状态：可以安全处理"
        else report = appendLine report "状态：已阻止"

        if warnings.count > 0 do
        (
            report = appendLine report ""
            report = appendLine report "警告："
            for warningText in warnings do report = appendLine report ("- " + warningText)
        )

        if blockers.count > 0 do
        (
            report = appendLine report ""
            report = appendLine report "阻止原因："
            for blockerText in blockers do report = appendLine report ("- " + blockerText)
        )

        #(blockers.count == 0, blockers, warnings, report)
    ),

    fn bakeExistingRepair node =
    (
        local analysisResult = analyze node
        if not analysisResult[1] do return #(false, analysisResult[4])
        if not hasExistingRepairStack node do return #(false, analysisResult[4] + "\r\n未检测到完整的 RSXF v1.1 修复堆栈。\r\n")

        local skinModifier = (getSkinModifiers node)[1]
        local referenceFrame = try (skinModifier.ref_frame) catch (0)
        local originalTime = currentTime
        local originalAlwaysDeform = try (skinModifier.always_deform) catch (true)
        local poseSamples = capturePoseSamples node referenceFrame originalTime
        sliderTime = referenceFrame
        local preMeshInfo = getEvaluatedMeshInfo node
        local savedWeights = captureSkinWeights skinModifier
        local renderedNormalSamples = captureRenderedNormalSamples node
        local resultReport = analysisResult[4]
        local currentStage = "准备已有修复堆栈"
        local succeeded = false
        local positionError = 0.0
        local normalDot = -1.0
        local normalCenterError = 1e9

        try
        (
            undo "Bake Reset Skinned XForm" on
            (
                currentStage = "将 RSXF 修改器烘焙为可编辑多边形"
                skinModifier = bakeRepairStack node
                completeRedraw()

                currentStage = "验证烘焙后的参考姿势和动画姿势"
                local poseValidation = validatePoseSamples node poseSamples
                positionError = poseValidation[2]
                if not poseValidation[1] do throw "验证烘焙姿势时顶点数或面数发生变化。"
                if positionError > positionTolerance do throw ("烘焙后的世界空间顶点验证失败，最大误差：" + positionError as string)

                sliderTime = referenceFrame
                currentStage = "验证烘焙后的面朝向"
                local normalValidation = validateRenderedNormalSamples node renderedNormalSamples
                normalDot = normalValidation[2]
                normalCenterError = normalValidation[3]
                if not normalValidation[1] do throw "烘焙修复堆栈时渲染面朝向发生变化。"
                if getParity node.transform < 0 do throw "烘焙后节点的世界变换仍为负奇偶性。"
                if classof node.baseObject != Editable_Poly do throw "最终基础对象不是可编辑多边形。"
            )

            currentStage = "验证烘焙后的 Skin 权重"
            skinModifier = (getSkinModifiers node)[1]
            select node
            max modify mode
            modPanel.setCurrentObject skinModifier node:node ui:true
            try (windows.processPostedMessages()) catch ()
            if not skinWeightsMatch skinModifier savedWeights do throw "烘焙时 Skin 顶点权重或 DQ 权重发生变化。"

            resultReport = appendLine resultReport ""
            resultReport = appendLine resultReport "烘焙结果：成功"
            resultReport = appendLine resultReport ("已验证顶点数：" + preMeshInfo[1] as string)
            resultReport = appendLine resultReport ("已验证面数：" + preMeshInfo[2] as string)
            resultReport = appendLine resultReport ("已验证姿势数：" + poseSamples.count as string)
            resultReport = appendLine resultReport ("最大采样位置误差：" + positionError as string)
            resultReport = appendLine resultReport ("最小采样渲染法线点积：" + normalDot as string)
            resultReport = appendLine resultReport ("最大采样面中心误差：" + normalCenterError as string)
            resultReport = appendLine resultReport "Skin 权重：未改变"
            resultReport = appendLine resultReport "最终堆栈：Skin + 可编辑多边形"
            resultReport = appendLine resultReport "已有隐藏备份：已保留"
            succeeded = true
        )
        catch
        (
            local failureMessage = getCurrentException()
            try (max undo) catch ()
            resultReport = appendLine resultReport ""
            resultReport = appendLine resultReport "烘焙结果：失败，已回滚更改"
            resultReport = appendLine resultReport ("阶段：" + currentStage)
            resultReport = appendLine resultReport ("原因：" + failureMessage)
        )

        sliderTime = originalTime
        try (((getSkinModifiers node)[1]).always_deform = originalAlwaysDeform) catch ()
        completeRedraw()
        #(succeeded, resultReport)
    ),

    fn repair node createBackup:true forceFlip:false =
    (
        local analysisResult = analyze node forceFlip:forceFlip
        if not analysisResult[1] do return #(false, analysisResult[4])
        if hasExistingRepairStack node do return bakeExistingRepair node

        local skins = getSkinModifiers node
        local skinModifier = skins[1]
        local referenceFrame = try (skinModifier.ref_frame) catch (0)
        local originalTime = currentTime
        local originalAlwaysDeform = try (skinModifier.always_deform) catch (true)
        local childWorldTMs = getDirectChildrenWorldTMs node
        local preMeshInfo = undefined
        local poseSamples = undefined
        local savedWeights = undefined
        local bindSummary = undefined
        local backupNode = undefined
        local resetModifier = undefined
        local flipModifier = undefined
        local renderedNormalSamples = undefined
        local resultReport = analysisResult[4]
        local succeeded = false
        local failureMessage = ""
        local currentStage = "准备处理"
        local positionError = 0.0
        local normalDot = -1.0
        local normalCenterError = 1e9

        sliderTime = referenceFrame
        preMeshInfo = getEvaluatedMeshInfo node
        poseSamples = capturePoseSamples node referenceFrame originalTime
        sliderTime = referenceFrame
        savedWeights = captureSkinWeights skinModifier
        bindSummary = captureBindSummary node skinModifier

        try
        (
            undo "Reset Skinned XForm" on
            (
                currentStage = "创建安全备份"
                if createBackup do backupNode = createBackupCopy node

                currentStage = "记录修改器堆栈"
                local oldModifiers = for modifierItem in node.modifiers collect modifierItem
                currentStage = "执行重置变换"
                resetXForm node
                currentStage = "定位重置变换修改器"
                for modifierItem in node.modifiers do
                (
                    if findItem oldModifiers modifierItem == 0 and resetModifier == undefined do resetModifier = modifierItem
                )
                if resetModifier == undefined do throw "重置变换没有创建 XForm 修改器。"

                currentStage = "将重置变换移动到 Skin 下方"
                local movedResetModifier = copy resetModifier
                deleteModifier node resetModifier
                skinModifier = (getSkinModifiers node)[1]
                local skinIndex = modPanel.getModifierIndex node skinModifier
                addModifier node movedResetModifier before:skinIndex
                resetModifier = movedResetModifier
                resetModifier.name = "RSXF - Reset XForm"
                skinModifier = (getSkinModifiers node)[1]
                skinIndex = modPanel.getModifierIndex node skinModifier
                local resetIndex = modPanel.getModifierIndex node resetModifier
                if resetIndex == undefined or resetIndex <= skinIndex do throw "无法将重置变换放到 Skin 下方。"

                currentStage = "将 Skin 重新绑定到重置后的网格"
                skinModifier.always_deform = false
                skinModifier.always_deform = true
                if not originalAlwaysDeform do skinModifier.always_deform = false

                currentStage = "恢复子节点变换"
                restoreDirectChildrenWorldTMs childWorldTMs

                currentStage = "验证参考姿势和动画姿势"
                completeRedraw()
                local poseValidation = validatePoseSamples node poseSamples
                positionError = poseValidation[2]
                if not poseValidation[1] do throw "验证姿势时顶点数或面数发生变化。"
                if positionError > positionTolerance do throw ("世界空间顶点验证失败，最大误差：" + positionError as string)

                sliderTime = referenceFrame
                currentStage = "添加翻面修改器"
                flipModifier = normalModifier flip:true unify:false
                flipModifier.name = "RSXF - Flip Faces"
                addModifier node flipModifier
                completeRedraw()

                currentStage = "验证翻面后的拓扑"
                local postMeshInfo = getEvaluatedMeshInfo node
                if preMeshInfo[1] != postMeshInfo[1] do throw "翻面后顶点数发生变化。"
                if preMeshInfo[2] != postMeshInfo[2] do throw "翻面后面数发生变化。"
                currentStage = "验证变换奇偶性"
                if getParity node.transform < 0 do throw "重置变换后节点的世界变换仍为负奇偶性。"

                sliderTime = referenceFrame
                renderedNormalSamples = captureRenderedNormalSamples node
                currentStage = "将修复结果烘焙为可编辑多边形"
                skinModifier = bakeRepairStack node
                completeRedraw()

                currentStage = "验证烘焙后的参考姿势和动画姿势"
                local bakedPoseValidation = validatePoseSamples node poseSamples
                positionError = amax positionError bakedPoseValidation[2]
                if not bakedPoseValidation[1] do throw "烘焙后顶点数或面数发生变化。"
                if positionError > positionTolerance do throw ("烘焙后的世界空间顶点验证失败，最大误差：" + positionError as string)

                sliderTime = referenceFrame
                currentStage = "验证烘焙后的面朝向"
                local normalValidation = validateRenderedNormalSamples node renderedNormalSamples
                normalDot = normalValidation[2]
                normalCenterError = normalValidation[3]
                if not normalValidation[1] do throw "烘焙时渲染面朝向发生变化。"
            )

            -- Run SkinOps validation after the undo transaction has closed. In Max 2020,
            -- SkinOps requires Skin to be the active Modify-panel item at this point.
            currentStage = "激活 Skin 修改器以进行验证"
            skinModifier = (getSkinModifiers node)[1]
            select node
            max modify mode
            modPanel.setCurrentObject skinModifier node:node ui:true
            try (windows.processPostedMessages()) catch ()
            currentStage = "验证 Skin 权重"
            if not skinWeightsMatch skinModifier savedWeights do throw "修复过程中 Skin 顶点权重或 DQ 权重发生变化。"

            resultReport = appendLine resultReport ""
            resultReport = appendLine resultReport "修复结果：成功"
            resultReport = appendLine resultReport ("已验证顶点数：" + preMeshInfo[1] as string)
            resultReport = appendLine resultReport ("已验证面数：" + preMeshInfo[2] as string)
            resultReport = appendLine resultReport ("已验证姿势数：" + poseSamples.count as string)
            resultReport = appendLine resultReport ("最大采样位置误差：" + positionError as string)
            resultReport = appendLine resultReport ("最小采样渲染法线点积：" + normalDot as string)
            resultReport = appendLine resultReport ("最大采样面中心误差：" + normalCenterError as string)
            resultReport = appendLine resultReport "Skin 权重：未改变"
            resultReport = appendLine resultReport "DQ 权重：在支持的情况下未改变"
            resultReport = appendLine resultReport ("已捕获网格绑定数据：" + (bindSummary[1] != undefined) as string)
            if backupNode != undefined do resultReport = appendLine resultReport ("隐藏备份：" + backupNode.name)
            resultReport = appendLine resultReport "最终堆栈：Skin + 可编辑多边形"
            resultReport = appendLine resultReport "临时 RSXF 修改器：已烘焙并移除"
            succeeded = true
        )
        catch
        (
            failureMessage = getCurrentException()
            try (max undo) catch ()
            resultReport = appendLine resultReport ""
            resultReport = appendLine resultReport "修复结果：失败，已回滚更改"
            resultReport = appendLine resultReport ("阶段：" + currentStage)
            resultReport = appendLine resultReport ("原因：" + failureMessage)
        )

        sliderTime = originalTime
        try (((getSkinModifiers node)[1]).always_deform = originalAlwaysDeform) catch ()
        completeRedraw()
        #(succeeded, resultReport)
    )
)

RSXF_Core = RSXF_CoreStruct()

try (destroyDialog RSXF_Rollout) catch ()

rollout RSXF_Rollout "蒙皮模型变换修复 1.2.1" width:500 height:626
(
    label lbl_title "蒙皮模型变换与面朝向修复" pos:[16,12] width:460 height:20
    label lbl_hint "修复为干净的 Skin + 可编辑多边形堆栈，也可烘焙已有的 v1.1 修复结果。" pos:[16,35] width:465 height:34

    checkbox chk_backup "创建隐藏的安全备份" checked:true pos:[16,72] width:220
    checkbox chk_force "正变换时仍强制翻面" checked:false pos:[250,72] width:235

    button btn_analyze "分析选中对象" pos:[16,104] width:225 height:34
    button btn_repair "修复 / 烘焙干净堆栈" pos:[257,104] width:225 height:34

    editText txt_report "" pos:[16,152] width:466 height:392 readOnly:true
    label lbl_usage "用法：选择一个带单个 Skin 的模型 → 分析选中对象 → 确认安全后执行修复。" pos:[16,550] width:466 height:22
    button btn_help "使用说明 / 限制" pos:[16,584] width:225 height:26
    button btn_close "关闭" pos:[257,584] width:225 height:26

    fn selectedNode =
    (
        if selection.count == 1 then selection[1] else undefined
    )

    on btn_analyze pressed do
    (
        local result = RSXF_Core.analyze (selectedNode()) forceFlip:chk_force.checked
        txt_report.text = result[4]
    )

    on btn_repair pressed do
    (
        local node = selectedNode()
        local preflight = RSXF_Core.analyze node forceFlip:chk_force.checked
        txt_report.text = preflight[4]
        if not preflight[1] then
        (
            messageBox "当前对象不能安全修复，请查看分析报告中的阻止原因。" title:"蒙皮模型变换修复"
        )
        else
        (
            local actionText = if RSXF_Core.hasExistingRepairStack node then "将已有修复结果烘焙为可编辑多边形" else "修复并烘焙为干净堆栈"
            local confirmation = queryBox (actionText + "：" + node.name + "？\n\n最终堆栈将只包含 Skin 和可编辑多边形；隐藏的原始备份会被保留。") title:"蒙皮模型变换修复"
            if confirmation do
            (
                local result = RSXF_Core.repair node createBackup:chk_backup.checked forceFlip:chk_force.checked
                txt_report.text = result[2]
                if result[1] then
                    messageBox "处理完成。最终堆栈：Skin + 可编辑多边形。" title:"蒙皮模型变换修复"
                else
                    messageBox "修复失败，所有更改已回滚，请查看报告。" title:"蒙皮模型变换修复"
            )
        )
    )

    on btn_help pressed do
    (
        messageBox "安全处理范围：\n- 只选择一个几何体，且必须只有一个 Skin 修改器\n- 初始堆栈只有 Skin，或存在完整的 RSXF v1.1 修复堆栈\n- 存在本地负变换，或已启用“强制翻面”\n- 网格节点变换没有动画\n- 不继承父级负变换\n- 对象不是实例\n- 没有“编辑法线”修改器\n\n工具会修复变换和面朝向，并把临时修改器安全烘焙到 Skin 下方。处理过程中会验证参考/动画姿势、渲染法线、拓扑、顶点权重和 DQ 权重。最终堆栈为：Skin + 可编辑多边形。" title:"蒙皮模型变换修复"
    )

    on btn_close pressed do destroyDialog RSXF_Rollout
)

macroScript ResetSkinnedXForm
category:"Rigging Tools"
toolTip:"蒙皮模型变换修复"
buttonText:"蒙皮变换修复"
(
    on execute do
    (
        try (destroyDialog RSXF_Rollout) catch ()
        createDialog RSXF_Rollout style:#(#style_titlebar, #style_sysmenu, #style_toolwindow)
    )
)
