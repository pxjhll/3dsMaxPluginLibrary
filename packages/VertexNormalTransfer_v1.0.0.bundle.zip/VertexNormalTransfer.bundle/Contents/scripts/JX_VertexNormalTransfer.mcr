-- Vertex Normal Transfer bundle entry
-- Package metadata author: 宝爷
--
-- Adapted from NoorsNormalThief 1.1.1 by JB "Noors" Sarrazin.
-- Original script notes:
--   Transfer normals from a source object to a target object's vertex normals.
--   Works with any type of geometry and adds an Edit Normals modifier.

global JX_VertexNormalTransfer_Rollout
global JX_VertexNormalTransfer_TransferNormals

fn JX_VertexNormalTransfer_TransferNormals sourceObject targetObject =
(
    startTime = timestamp()

    -- Read the target face selection from a temporary poly/mesh copy.
    selectedFaces = #{}
    disableRefMsgs()
    targetCopy = copy targetObject
    if (classof targetCopy != editable_poly) and (classof targetCopy != editable_mesh) do
        convertToPoly targetCopy
    selectedFaces = getFaceSelection targetCopy
    if selectedFaces.numberset == 0 do
        selectedFaces = #{1..targetCopy.numfaces}
    delete targetCopy
    enableRefMsgs()

    -- Snapshot the source so the original object and transforms remain untouched.
    sourceMesh = snapshotAsMesh sourceObject
    sourceSnapshot = editable_mesh()
    sourceSnapshot.mesh = sourceMesh

    targetNormalsModifier = Edit_Normals()
    targetNormalsModifier.displayLength = 1

    sourceNormalsModifier = Edit_Normals()
    sourceNormalsModifier.displayLength = 0

    addModifier targetObject targetNormalsModifier
    addModifier sourceSnapshot sourceNormalsModifier

    getSourceNormalID = sourceNormalsModifier.GetNormalID
    getSourceNormal = sourceNormalsModifier.GetNormal

    getTargetFaceDegree = targetNormalsModifier.GetFaceDegree
    getTargetVertexID = targetNormalsModifier.GetVertexID
    getTargetVertex = targetNormalsModifier.GetVertex
    getTargetNormalID = targetNormalsModifier.GetNormalID
    convertTargetVertexSelection = targetNormalsModifier.ConvertVertexSelection
    setTargetSelection = targetNormalsModifier.SetSelection
    makeTargetExplicit = targetNormalsModifier.MakeExplicit
    setTargetNormal = targetNormalsModifier.SetNormal

    normalIDs = #()
    normalValues = #()
    sourceFaceBarycentrics = #()
    completedVertices = #()

    projection = MeshProjIntersect()
    projection.setNode sourceSnapshot
    projection.build()

    -- Edit Normals must be current in the Modify panel.
    select targetObject
    targetTransform = targetObject.transform
    max modify mode

    for faceIndex in selectedFaces do
    (
        cornerCount = getTargetFaceDegree faceIndex
        for cornerIndex = 1 to cornerCount do
        (
            vertexIndex = getTargetVertexID faceIndex cornerIndex
            if findItem completedVertices vertexIndex == 0 do
            (
                try
                (
                    worldPosition = (getTargetVertex vertexIndex) * targetTransform
                    projection.closestFace worldPosition doubleSided:true
                    sourceFaceIndex = projection.GetHitFace() + 1
                    barycentric = projection.GetHitBary()
                    targetNormalID = getTargetNormalID faceIndex cornerIndex

                    append sourceFaceBarycentrics #(sourceFaceIndex, barycentric)
                    append normalIDs targetNormalID
                )
                catch
                (
                    format "Vertex Normal Transfer error on vertex: %\n" vertexIndex
                )

                sharedNormals = #{}
                convertTargetVertexSelection #{vertexIndex} sharedNormals
                if sharedNormals.numberset == 1 do
                    append completedVertices vertexIndex
            )
        )
    )

    -- Interpolate the source vertex normals at each closest surface point.
    select sourceSnapshot
    for faceBarycentric in sourceFaceBarycentrics do
    (
        sourceFaceIndex = faceBarycentric[1]
        barycentric = faceBarycentric[2]

        normal1 = getSourceNormal (getSourceNormalID sourceFaceIndex 1)
        normal2 = getSourceNormal (getSourceNormalID sourceFaceIndex 2)
        normal3 = getSourceNormal (getSourceNormalID sourceFaceIndex 3)
        interpolatedNormal =
            (barycentric.x * normal1) +
            (barycentric.y * normal2) +
            (barycentric.z * normal3)
        append normalValues interpolatedNormal
    )

    -- Write explicit normals to the target object's Edit Normals modifier.
    select targetObject
    subObjectLevel = 1
    disableRefMsgs()
    for index = 1 to normalIDs.count do
    (
        normalID = normalIDs[index]
        normalValue = normalValues[index]
        setTargetSelection #{normalID}
        makeTargetExplicit()
        setTargetNormal normalID normalValue
    )
    enableRefMsgs()

    projection.Free()
    delete sourceSnapshot
    gc light:true

    select targetObject
    format "Vertex Normal Transfer took % seconds\n" ((timestamp() - startTime) / 1000.0)
)

try (destroyDialog JX_VertexNormalTransfer_Rollout) catch ()
rollout JX_VertexNormalTransfer_Rollout "Vertex Normal Transfer 1.0.0" width:166
(
    group "1. Source"
    (
        pickButton sourcePicker "Pick Source Object" width:140 align:#left
    )

    group "2. Target"
    (
        label targetHint "Select target object/faces" width:140 align:#left
    )

    group "3. Transfer"
    (
        button transferButton "Transfer Normals" width:140 align:#left
    )

    on sourcePicker picked pickedObject do
    (
        if pickedObject != undefined do
            sourcePicker.text = pickedObject.name
    )

    on transferButton pressed do
    (
        sourceObject = sourcePicker.object
        targetObject = if selection.count > 0 then selection[1] else undefined

        if (sourceObject != undefined) and (targetObject != undefined) then
        (
            if (superClassOf sourceObject == geometryClass) and
               (superClassOf targetObject == geometryClass) then
            (
                format "Source: %\n" sourceObject
                format "Target: %\n" targetObject
                JX_VertexNormalTransfer_TransferNormals sourceObject targetObject
            )
            else
            (
                messageBox "Source or target is not a valid geometry object." title:"Vertex Normal Transfer"
            )
        )
        else
        (
            messageBox "Pick a source object and select a target object." title:"Vertex Normal Transfer"
        )
    )
)

macroScript JX_VertexNormalTransfer
category:"JXTools"
buttonText:"Vertex Normal Transfer"
toolTip:"Transfer vertex normals from a source surface to a target object"
(
    on execute do
    (
        try (destroyDialog JX_VertexNormalTransfer_Rollout) catch ()
        createDialog JX_VertexNormalTransfer_Rollout style:#(#style_toolwindow, #style_sysmenu)
    )
)
