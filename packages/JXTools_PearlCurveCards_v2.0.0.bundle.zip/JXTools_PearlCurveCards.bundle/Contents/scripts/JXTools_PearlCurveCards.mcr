﻿/* JXTools Pearl Curve Cards v2.0.0 MacroScript entries. */
global JXTools_OpenPearlCurveCards
global JXTools_PearlCurveCards_ScriptRoot

(
    local sourcePath = getSourceFileName()
    if sourcePath != undefined do JXTools_PearlCurveCards_ScriptRoot = getFilenamePath sourcePath
)

fn JXTools_OpenPearlCurveCards =
(
    global JXPearlCurveCards_Max
    global JXPearlCurveCards_NoAutoShow

    local mainScript = ""
    if JXTools_PearlCurveCards_ScriptRoot != undefined do
        mainScript = JXTools_PearlCurveCards_ScriptRoot + "JXTools_PearlCurveCards_Max2020_2027.ms"
    if mainScript == "" or not doesFileExist mainScript do
        mainScript = (getDir #userScripts) + "\\JXTools_PearlCurveCards\\JXTools_PearlCurveCards_Max2020_2027.ms"
    if not doesFileExist mainScript then
    (
        messageBox ("找不到珍珠曲线面片工具主脚本：\n" + mainScript + "\n\n请重新安装插件。") title:"珍珠曲线面片工具 v2.0.0"
        return false
    )

    try
    (
        JXPearlCurveCards_NoAutoShow = true
        fileIn mainScript quiet:true
        JXPearlCurveCards_NoAutoShow = false
        if JXPearlCurveCards_Max != undefined then
        (
            JXPearlCurveCards_Max.show()
            true
        )
        else
        (
            messageBox "主脚本已加载，但没有找到工具入口。" title:"珍珠曲线面片工具 v2.0.0"
            false
        )
    )
    catch
    (
        JXPearlCurveCards_NoAutoShow = false
        messageBox ("打开珍珠曲线面片工具失败：\n" + (getCurrentException())) title:"珍珠曲线面片工具 v2.0.0"
        false
    )
)

macroScript JXTools_PearlCurveCards
category:"JXTools"
buttonText:"Pearl v2.0"
toolTip:"珍珠曲线面片工具 v2.0.0"
(
    on execute do JXTools_OpenPearlCurveCards()
)

/* Compatibility aliases for toolbars created by the older drag installer. */
macroScript JXTools_PearlCurveCards_Max2020_2027_v1_0_0
category:"JXTools"
buttonText:"Pearl v2.0"
toolTip:"珍珠曲线面片工具 v2.0.0 兼容入口"
(
    on execute do JXTools_OpenPearlCurveCards()
)

macroScript JXTools_PearlCurveCards_Max2020_2027
category:"JXTools"
buttonText:"Pearl"
toolTip:"珍珠曲线面片工具 v2.0.0 旧版兼容入口"
(
    on execute do JXTools_OpenPearlCurveCards()
)
