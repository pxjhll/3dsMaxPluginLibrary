/*
    挂件匹配插槽坐标
    CompanyPluginManager Bundle entry point.
*/
global HAM_DragDrop_Rollout
global HAM_DD_GetTM
global HAM_DD_DetectBody
global HAM_DD_RotatePivotOnly
global HAM_DD_Apply

    fn HAM_DD_GetTM bodyType slotType =
    (
        case (bodyType + "_" + slotType) of
        (
            "F1_earL":       (matrix3 [1,0,0] [0,0,1] [0,-1,0] [-5.83556,-2.32326,110.676])
            "F1_earR":       (matrix3 [1,0,0] [0,0,1] [0,-1,0] [5.83474,-2.32325,110.676])
            "F1_MaskL_bone": (matrix3 [1,0,0] [0,0,1] [0,-1,0] [-0.0004071,-8.66582,106.725])
            "F1_MaskU_bone": (matrix3 [1,0,0] [0,0,1] [0,-1,0] [0.00000953674,-10.4345,127.067])
            "F1_neck":       (matrix3 [1,0,0] [0,0,1] [0,-1,0] [-0.00000965595,-1.02124,103.166])

            "F2_earL":       (matrix3 [1,0,0] [0,0,1] [0,-1,0] [-5.83501,-0.784576,156.004])
            "F2_earR":       (matrix3 [1,0,0] [0,0,1] [0,-1,0] [5.83529,-0.784574,156.004])
            "F2_MaskL_bone": (matrix3 [1,0,0] [0,0,1] [0,-1,0] [0.000135183,-8.63398,150.367])
            "F2_MaskU_bone": (matrix3 [1,0,0] [0,0,1] [0,-1,0] [0.150999,-8.88899,176.486])
            "F2_neck":       (matrix3 [1,0,0] [0,0,1] [0,-1,0] [-0.00000159605,1.01543,145.936])

            "M2_earL":       (matrix3 [1,0,0] [0,0,1] [0,-1,0] [-5.83555,-0.00457883,171.444])
            "M2_earR":       (matrix3 [1,0,0] [0,0,1] [0,-1,0] [5.83475,-0.00457597,171.444])
            "M2_MaskL_bone": (matrix3 [1,0,0] [0,0,1] [0,-1,0] [-0.000403106,-6.74653,166.034])
            "M2_MaskU_bone": (matrix3 [1,0,0] [0,0,1] [0,-1,0] [0.00000572205,-7.20999,192.151])
            "M2_neck":       (matrix3 [1,0,0] [0,0,1] [0,-1,0] [-0.000000539348,3.16376,161.489])
            "M2_behind":     (matrix3 [1,0,0] [0,0,1] [0,-1,0] [-0.0000400543,25.7361,148.282])
            default: undefined
        )
    )

    fn HAM_DD_DetectBody nodes fallback =
    (
        for n in nodes do
        (
            local upperName = toUpper n.name
            if (matchPattern upperName pattern:"*_F1*") or (matchPattern upperName pattern:"F1_*") do return "F1"
            if (matchPattern upperName pattern:"*_F2*") or (matchPattern upperName pattern:"F2_*") do return "F2"
            if (matchPattern upperName pattern:"*_M2*") or (matchPattern upperName pattern:"M2_*") do return "M2"
        )
        fallback
    )

    fn HAM_DD_RotatePivotOnly obj rotation =
    (
        local rotValInv = inverse (rotation as quat)
        animate off in coordsys local obj.rotation *= rotValInv
        obj.objectOffsetPos *= rotValInv
        obj.objectOffsetRot *= rotValInv
    )

    fn HAM_DD_Apply bodyType slotType =
    (
        local nodes = selection as array
        if nodes.count == 0 then
        (
            messageBox "请先选择需要匹配的挂件模型。" title:"插槽坐标匹配"
            return false
        )

        local targetTM = HAM_DD_GetTM bodyType slotType
        if targetTM == undefined then return false

        undo "挂件匹配插槽坐标" on
        (
            for n in nodes do
            (
                -- 等同于“层次 > 轴 > 仅影响轴”：只改变轴心坐标，模型几何保持原位。
                n.pivot = targetTM.translationPart
                WorldAlignPivot n
                HAM_DD_RotatePivotOnly n (EulerAngles 90 0 0)
            )
        )
        redrawViews()
        true
    )

    try(destroyDialog HAM_DragDrop_Rollout)catch()
    rollout HAM_DragDrop_Rollout "挂件匹配插槽坐标 v1.4.1" width:356 height:380
    (
        groupBox gbBody "1. 选择体型" pos:[10,10] width:336 height:62
        radioButtons rbBody labels:#("F1", "F2", "M2") default:1 columns:3 pos:[54,35]
        checkbox chkAuto "根据所选模型名称自动识别 F1/F2/M2" checked:false pos:[24,82]

        groupBox gbSlot "2. 一键匹配插槽" pos:[10,108] width:336 height:186
        button btnEarL "earL：耳饰（画面左）" pos:[22,132] width:154 height:32
        button btnEarR "earR：耳饰（画面右）" pos:[182,132] width:154 height:32
        button btnMaskL "MaskL：面具" pos:[22,170] width:154 height:32
        button btnMaskU "MaskU：头饰" pos:[182,170] width:154 height:32
        button btnNeck "neck：项链" pos:[22,208] width:154 height:32
        button btnBehind "behind：背挂M2" pos:[182,208] width:154 height:32
        label lblBehind "提示：behind 固定使用 M2 坐标" pos:[22,254] width:300 height:18

        label lblMode "仅修改轴心坐标，模型保持在原位不移动。" pos:[22,306] width:320 height:18
        label lblHint "选择模型后点击上方按钮；所有操作均可 Ctrl+Z 撤销。" pos:[22,334] width:320 height:18
        label lblStatus "就绪：已内置 16 个插槽坐标" pos:[22,356] width:320 height:18

        fn currentBody =
        (
            local body = #("F1","F2","M2")[rbBody.state]
            if chkAuto.checked and selection.count > 0 do body = HAM_DD_DetectBody (selection as array) body
            body
        )

        fn applySlot slotName displayName forceM2:false =
        (
            local body = if forceM2 then "M2" else currentBody()
            if HAM_DD_Apply body slotName do
                lblStatus.text = ("匹配完成：" + displayName + " / " + body)
        )

        on btnEarL pressed do applySlot "earL" "耳饰（画面左）"
        on btnEarR pressed do applySlot "earR" "耳饰（画面右）"
        on btnMaskL pressed do applySlot "MaskL_bone" "面具"
        on btnMaskU pressed do applySlot "MaskU_bone" "头饰"
        on btnNeck pressed do applySlot "neck" "项链"
        on btnBehind pressed do applySlot "behind" "背挂M2" forceM2:true
    )

macroScript AccessorySlotMatcher
category:"JXTools"
toolTip:"挂件匹配插槽坐标"
buttonText:"挂件匹配插槽坐标"
(
    on execute do
    (
        try(destroyDialog HAM_DragDrop_Rollout)catch()
        createDialog HAM_DragDrop_Rollout style:#(#style_titlebar, #style_sysmenu, #style_toolwindow)
    )
)
