global ITDL_PayloadPath

ITDL_PayloadPath = (getFilenamePath (getSourceFileName())) + "InstantTexelDensityLitePayload.ms"

macroScript InstantTexelDensityMax
category:"JXTools"
toolTip:"UV密度查看工具"
buttonText:"UV密度查看"
(
    on execute do
    (
        try
        (
            if doesFileExist ITDL_PayloadPath then
            (
                fileIn ITDL_PayloadPath
                true
            )
            else
            (
                messageBox (
                    "缺少插件运行文件：\n" + ITDL_PayloadPath
                ) title:"UV密度查看工具"
                false
            )
        )
        catch
        (
            messageBox (
                "UV密度查看工具启动失败：\n" + (getCurrentException() as string)
            ) title:"UV密度查看工具"
            false
        )
    )
)
