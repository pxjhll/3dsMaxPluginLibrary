/*
    JX QA Character Tool
    Version 2.1.3

    Lean character-model QA tool. Skin-specific repair belongs to the independent
    ResetSkinnedXForm tool; this plug-in only blocks unsafe edits on Skin objects.
*/

global JX_QACharVersion = "2.1.3"
global ModelCheckerTool
global JX_QAPearlCountDialog
global JX_QAPearlExpectedCount
global JX_QAChar_Show
global JX_QAChar_StringArrayToText
global JX_QAChar_AnalyzeAlphaObject
global JX_QAChar_AnalyzeUVChannels

global JX_QACharUVFirstForbiddenChannel = 3
global JX_QACharUVTargetMapCount = 3


fn JX_QAChar_ToLower value =
(
    local upper = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    local lower = "abcdefghijklmnopqrstuvwxyz"
    local result = copy (value as string)
    for characterIndex = 1 to result.count do
    (
        local upperIndex = findString upper result[characterIndex]
        if upperIndex != undefined do result[characterIndex] = lower[upperIndex]
    )
    result
)


fn JX_QAChar_EndsWith value suffix ignoreCase:true =
(
    local sourceText = value as string
    local suffixText = suffix as string
    if ignoreCase do
    (
        sourceText = JX_QAChar_ToLower sourceText
        suffixText = JX_QAChar_ToLower suffixText
    )
    if suffixText.count > sourceText.count then false
    else (substring sourceText (sourceText.count - suffixText.count + 1) suffixText.count) == suffixText
)


fn JX_QAChar_GetNamingSuffix objectName =
(
    local lowerName = JX_QAChar_ToLower objectName
    for suffixItem in #("_body", "_hair", "_head", "_skin") do
        if JX_QAChar_EndsWith lowerName suffixItem do return suffixItem
    ""
)


fn JX_QAChar_FormatNamingSuffix suffixValue =
(
    case suffixValue of
    (
        "_body": "_Body"
        "_hair": "_Hair"
        "_head": "_Head"
        "_skin": "_Skin"
        default: ""
    )
)


fn JX_QAChar_GetSceneBaseName =
(
    if maxFileName == undefined or maxFileName == "" then ""
    else getFilenameFile maxFileName
)


fn JX_QAChar_IsGeometryNode node =
(
    node != undefined and isValidNode node and superclassof node == GeometryClass
)


fn JX_QAChar_HasSkin node =
(
    if node == undefined or not isValidNode node then return false
    for modifierItem in node.modifiers do
        if classof modifierItem == Skin do return true
    false
)


fn JX_QAChar_GetInstanceCount node =
(
    local instanceNodes = #()
    try
    (
        InstanceMgr.GetInstances node &instanceNodes
        instanceNodes.count
    )
    catch (1)
)


fn JX_QAChar_GetRotationAngle rotationValue =
(
    local angleValue = try (abs ((rotationValue as angleaxis).angle)) catch (360.0)
    if angleValue > 180.0 do angleValue = 360.0 - angleValue
    abs angleValue
)


fn JX_QAChar_ControllerIsAnimated controllerValue =
(
    if controllerValue == undefined then false
    else
    (
        local animatedValue = try (isAnimated controllerValue) catch (false)
        if not animatedValue do animatedValue = try (controllerValue.keys.count > 0) catch (false)
        animatedValue
    )
)


fn JX_QAChar_NodeTransformIsAnimated node =
(
    local currentNode = node
    while currentNode != undefined do
    (
        local positionAnimated = try (isPropertyAnimated currentNode #position) catch (false)
        local rotationAnimated = try (isPropertyAnimated currentNode #rotation) catch (false)
        local scaleAnimated = try (isPropertyAnimated currentNode #scale) catch (false)
        if positionAnimated or rotationAnimated or scaleAnimated do return true
        if JX_QAChar_ControllerIsAnimated (try (currentNode.position.controller) catch (undefined)) do return true
        if JX_QAChar_ControllerIsAnimated (try (currentNode.rotation.controller) catch (undefined)) do return true
        if JX_QAChar_ControllerIsAnimated (try (currentNode.scale.controller) catch (undefined)) do return true
        currentNode = currentNode.parent
    )
    false
)


fn JX_QAChar_UnitsAreCentimeters =
(
    local metricTypeIsCentimeters = try (units.MetricType == #centimeters) catch (true)
    abs (units.SystemScale - 1.0) <= 0.00001 and
        units.SystemType == #centimeters and
        units.DisplayType == #Metric and
        metricTypeIsCentimeters
)


fn JX_QAChar_SetUnitsToCentimeters =
(
    units.SystemScale = 1.0
    units.SystemType = #centimeters
    units.DisplayType = #Metric
    try (units.MetricType = #centimeters) catch ()
    JX_QAChar_UnitsAreCentimeters()
)


fn JX_QAChar_GetCurrentUnitText =
(
    "SystemScale=" + units.SystemScale as string +
        "，SystemType=" + units.SystemType as string +
        "，DisplayType=" + units.DisplayType as string +
        "，MetricType=" + (try (units.MetricType as string) catch ("不可用"))
)


fn JX_QAChar_Point3IndicesToArray indices =
(
    #((indices.x as integer), (indices.y as integer), (indices.z as integer))
)


-- 返回 #(#poly|#mesh|#unsupported, baseObject, meshCopy)
fn JX_QAChar_GetEditableBaseData node =
(
    local baseObj = try (node.baseObject) catch (undefined)
    if baseObj == undefined then return #(#unsupported, undefined, undefined)
    if isKindOf baseObj Editable_Poly then
        #(#poly, baseObj, undefined)
    else if isKindOf baseObj Editable_mesh then
        #(#mesh, baseObj, baseObj.mesh)
    else
        #(#unsupported, baseObj, undefined)
)


fn JX_QAChar_GetPositiveMapCount node =
(
    local analysis = JX_QAChar_AnalyzeUVChannels node
    if analysis[1] == #unsupported then return 0
    local highestSupported = -1
    for channelIndex in analysis[6] where channelIndex > highestSupported do highestSupported = channelIndex
    highestSupported + 1
)


-- 返回 #(状态, baseKind, baseObject, target, 已分配数量, 已启用通道, 禁止通道, 说明)
fn JX_QAChar_AnalyzeUVChannels node =
(
    if not JX_QAChar_IsGeometryNode node then
        return #(#unsupported, #unsupported, undefined, undefined, 0, #(), #(), "不是有效几何体")
    local baseData = JX_QAChar_GetEditableBaseData node
    local baseKind = baseData[1]
    if baseKind == #unsupported then
        return #(#unsupported, baseKind, baseData[2], undefined, 0, #(), #(), "底层对象不是 Editable Poly/Mesh")
    local target = if baseKind == #poly then baseData[2] else baseData[3]
    local allocatedCount = try
    (
        if baseKind == #poly then polyop.getNumMaps target else meshop.getNumMaps target
    )
    catch (-1)
    if allocatedCount < 0 then
        return #(#unsupported, baseKind, baseData[2], target, 0, #(), #(), "无法读取 UV 通道分配数量")
    local supportedChannels = #()
    local hasValidAllowedChannel = false
    local forbiddenChannels = #()
    if allocatedCount > 0 do
    (
        for channelIndex = 0 to allocatedCount - 1 do
        (
            local isSupported = if baseKind == #poly then
                (try (polyop.getMapSupport target channelIndex) catch (false))
                else (try (meshop.getMapSupport target channelIndex) catch (false))
            if isSupported do append supportedChannels channelIndex
            if isSupported and channelIndex < JX_QACharUVFirstForbiddenChannel do
            (
                local allowedVertCount = if baseKind == #poly then
                    (try (polyop.getNumMapVerts target channelIndex) catch (0))
                    else (try (meshop.getNumMapVerts target channelIndex) catch (0))
                local allowedFaceCount = if baseKind == #poly then
                    (try (polyop.getNumMapFaces target channelIndex) catch (0))
                    else (try (meshop.getNumMapFaces target channelIndex) catch (0))
                if allowedVertCount == undefined do allowedVertCount = 0
                if allowedFaceCount == undefined do allowedFaceCount = 0
                if allowedVertCount > 0 and allowedFaceCount > 0 do hasValidAllowedChannel = true
            )
            if channelIndex >= JX_QACharUVFirstForbiddenChannel do
            (
                local mapVertCount = if baseKind == #poly then
                    (try (polyop.getNumMapVerts target channelIndex) catch (0))
                    else (try (meshop.getNumMapVerts target channelIndex) catch (0))
                local mapFaceCount = if baseKind == #poly then
                    (try (polyop.getNumMapFaces target channelIndex) catch (0))
                    else (try (meshop.getNumMapFaces target channelIndex) catch (0))
                if mapVertCount == undefined do mapVertCount = 0
                if mapFaceCount == undefined do mapFaceCount = 0
                if isSupported or mapVertCount > 0 or mapFaceCount > 0 do append forbiddenChannels channelIndex
            )
        )
    )
    if not hasValidAllowedChannel then
        return #(#missing, baseKind, baseData[2], target, allocatedCount, supportedChannels, forbiddenChannels,
            "通道 0–2 中没有可用的 Map 顶点和面；不会自动生成 UV")
    -- 与 v1.0.2 的严格规则保持一致：内部可用通道槽超过 0-2 时，
    -- 即使高通道没有 Support/Map 数据，也视为需要清理的残留分配。
    local needsRepair = allocatedCount > JX_QACharUVTargetMapCount or forbiddenChannels.count > 0
    #(
        if needsRepair then #wrong else #valid,
        baseKind, baseData[2], target, allocatedCount, supportedChannels, forbiddenChannels,
        if forbiddenChannels.count > 0 then "通道 3 及以上仍有 Support 或 Map 数据"
        else if allocatedCount > JX_QACharUVTargetMapCount then "通道 3 及以上只有空的内部残留槽"
        else "内部 Map 通道数量与有效数据均符合规范"
    )
)


-- 捕获一个通道的完整 Map 顶点和面索引；支持正数通道及隐藏 Alpha 通道。
fn JX_QAChar_CaptureMapChannel baseKind target channelIndex =
(
    local isSupported = if baseKind == #poly then
        (try (polyop.getMapSupport target channelIndex) catch (false))
        else (try (meshop.getMapSupport target channelIndex) catch (false))
    if not isSupported then return #(false, #(), #())
    local vertCount = if baseKind == #poly then polyop.getNumMapVerts target channelIndex
        else meshop.getNumMapVerts target channelIndex
    local faceCount = if baseKind == #poly then polyop.getNumMapFaces target channelIndex
        else meshop.getNumMapFaces target channelIndex
    -- Editable Mesh 可能报告“Support=true、0 个 Map 顶点、但仍有默认 Map 面”。
    -- 该状态包含悬空索引，不能安全重建，也不属于有效 UV 数据，统一按空通道处理。
    if vertCount == undefined or vertCount < 1 then return #(false, #(), #())
    local mapVerts = for vertIndex = 1 to vertCount collect
        (if baseKind == #poly then polyop.getMapVert target channelIndex vertIndex
        else meshop.getMapVert target channelIndex vertIndex)
    local mapFaces = #()
    for faceIndex = 1 to faceCount do
    (
        local rawFace = if baseKind == #poly then polyop.getMapFace target channelIndex faceIndex
            else JX_QAChar_Point3IndicesToArray (meshop.getMapFace target channelIndex faceIndex)
        local faceValues = for valueIndex = 1 to rawFace.count collect (rawFace[valueIndex] as integer)
        append mapFaces faceValues
    )
    #(true, mapVerts, mapFaces)
)


-- 回滚专用：即使 Support=false 也尽量保留已分配的 Map 数据。
fn JX_QAChar_CaptureRawMapChannel baseKind target channelIndex =
(
    local isSupported = if baseKind == #poly then
        (try (polyop.getMapSupport target channelIndex) catch (false))
        else (try (meshop.getMapSupport target channelIndex) catch (false))
    local vertCount = if baseKind == #poly then
        (try (polyop.getNumMapVerts target channelIndex) catch (0))
        else (try (meshop.getNumMapVerts target channelIndex) catch (0))
    local faceCount = if baseKind == #poly then
        (try (polyop.getNumMapFaces target channelIndex) catch (0))
        else (try (meshop.getNumMapFaces target channelIndex) catch (0))
    if vertCount == undefined do vertCount = 0
    if faceCount == undefined do faceCount = 0
    local mapVerts = #()
    local mapFaces = #()
    if vertCount > 0 do
    (
        for vertIndex = 1 to vertCount do
        (
            local mapVert = if baseKind == #poly then
                (try (polyop.getMapVert target channelIndex vertIndex) catch (undefined))
                else (try (meshop.getMapVert target channelIndex vertIndex) catch (undefined))
            if mapVert != undefined do append mapVerts mapVert
        )
        for faceIndex = 1 to faceCount do
        (
            local rawFace = if baseKind == #poly then
                (try (polyop.getMapFace target channelIndex faceIndex) catch (undefined))
                else (try (JX_QAChar_Point3IndicesToArray (meshop.getMapFace target channelIndex faceIndex)) catch (undefined))
            if rawFace != undefined do append mapFaces (for valueIndex = 1 to rawFace.count collect (rawFace[valueIndex] as integer))
        )
    )
    #(isSupported, mapVerts, mapFaces)
)


fn JX_QAChar_RestoreRawMapChannel baseKind target channelIndex savedData =
(
    local hasData = savedData[2].count > 0
    if baseKind == #poly then
    (
        polyop.setMapSupport target channelIndex (savedData[1] or hasData)
        if hasData do
        (
            polyop.setNumMapVerts target channelIndex savedData[2].count keep:false
            for vertIndex = 1 to savedData[2].count do
                polyop.setMapVert target channelIndex vertIndex savedData[2][vertIndex]
            for faceIndex = 1 to savedData[3].count do
                polyop.setMapFace target channelIndex faceIndex savedData[3][faceIndex]
        )
        if not savedData[1] do polyop.setMapSupport target channelIndex false
    )
    else
    (
        meshop.setMapSupport target channelIndex (savedData[1] or hasData)
        if hasData do
        (
            meshop.setNumMapVerts target channelIndex savedData[2].count keep:false
            for vertIndex = 1 to savedData[2].count do
                meshop.setMapVert target channelIndex vertIndex savedData[2][vertIndex]
            meshop.setNumMapFaces target channelIndex savedData[3].count keep:false
            for faceIndex = 1 to savedData[3].count do
            (
                local faceValues = savedData[3][faceIndex]
                meshop.setMapFace target channelIndex faceIndex [faceValues[1], faceValues[2], faceValues[3]]
            )
        )
        if not savedData[1] do meshop.setMapSupport target channelIndex false
    )
    true
)


fn JX_QAChar_CapturePreservedUVChannels baseKind target =
(
    for channelIndex = 0 to JX_QACharUVFirstForbiddenChannel - 1 collect
        #(channelIndex, JX_QAChar_CaptureMapChannel baseKind target channelIndex)
)


fn JX_QAChar_ValidateMapChannelCapture baseKind target savedChannels pointTolerance:0.000001 =
(
    for channelEntry in savedChannels do
    (
        local channelIndex = channelEntry[1]
        local savedData = channelEntry[2]
        local currentData = JX_QAChar_CaptureMapChannel baseKind target channelIndex
        if currentData[1] != savedData[1] then
            return #(false, "通道 " + channelIndex as string + " 的 Support 状态发生变化")
        if savedData[1] do
        (
            if currentData[2].count != savedData[2].count or currentData[3].count != savedData[3].count then
                return #(false, "通道 " + channelIndex as string + " 的 Map 顶点或面数量发生变化")
            for vertIndex = 1 to savedData[2].count do
                if distance savedData[2][vertIndex] currentData[2][vertIndex] > pointTolerance do
                    return #(false, "通道 " + channelIndex as string + " 的 Map 顶点发生变化")
            for faceIndex = 1 to savedData[3].count do
            (
                if savedData[3][faceIndex].count != currentData[3][faceIndex].count then
                    return #(false, "通道 " + channelIndex as string + " 的 Map 面角数发生变化")
                for cornerIndex = 1 to savedData[3][faceIndex].count do
                    if savedData[3][faceIndex][cornerIndex] != currentData[3][faceIndex][cornerIndex] do
                        return #(false, "通道 " + channelIndex as string + " 的 Map Face 索引发生变化")
            )
        )
    )
    #(true, "保留通道数据未变化")
)


fn JX_QAChar_RestoreMeshMapChannels target savedChannels =
(
    for channelEntry in savedChannels do
    (
        local channelIndex = channelEntry[1]
        local savedData = channelEntry[2]
        meshop.setMapSupport target channelIndex savedData[1]
        if savedData[1] do
        (
            meshop.setNumMapVerts target channelIndex savedData[2].count keep:false
            for vertIndex = 1 to savedData[2].count do
                meshop.setMapVert target channelIndex vertIndex savedData[2][vertIndex]
            meshop.setNumMapFaces target channelIndex savedData[3].count keep:false
            for faceIndex = 1 to savedData[3].count do
            (
                local faceValues = savedData[3][faceIndex]
                meshop.setMapFace target channelIndex faceIndex [faceValues[1], faceValues[2], faceValues[3]]
            )
        )
    )
    true
)


fn JX_QAChar_CreateHiddenBackup node =
(
    local clonedNodes = #()
    maxOps.cloneNodes #(node) cloneType:#copy newNodes:&clonedNodes
    if clonedNodes.count != 1 then throw "无法创建安全备份副本"
    local backupNode = clonedNodes[1]
    backupNode.name = uniqueName (node.name + "_JXQA_BACKUP")
    backupNode.renderable = false
    hide backupNode
    freeze backupNode
    backupNode
)


fn JX_QAChar_CaptureWorldMesh node =
(
    local meshValue = snapshotAsMesh node
    local points = for vertexIndex = 1 to meshValue.numverts collect (getVert meshValue vertexIndex)
    local faceCenters = #()
    local faceNormals = #()
    local faceVertexIDs = #()
    for faceIndex = 1 to meshValue.numfaces do
    (
        append faceCenters (meshop.getFaceCenter meshValue faceIndex)
        append faceVertexIDs (JX_QAChar_Point3IndicesToArray (getFace meshValue faceIndex))
        local renderNormals = meshop.getFaceRNormals meshValue faceIndex
        local normalValue = renderNormals[1] + renderNormals[2] + renderNormals[3]
        if (length normalValue) > 0.0000001 do normalValue = normalize normalValue
        append faceNormals normalValue
    )
    local result = #(meshValue.numverts, meshValue.numfaces, points, faceCenters, faceNormals, faceVertexIDs)
    meshValue = undefined
    result
)


fn JX_QAChar_ComparePointValues leftValue rightValue =
(
    if leftValue.x < rightValue.x then -1 else if leftValue.x > rightValue.x then 1
    else if leftValue.y < rightValue.y then -1 else if leftValue.y > rightValue.y then 1
    else if leftValue.z < rightValue.z then -1 else if leftValue.z > rightValue.z then 1
    else 0
)


fn JX_QAChar_BuildFacePositionSample points faceVertexIDs normalValue =
(
    local facePositions = for vertexID in faceVertexIDs collect points[vertexID]
    qsort facePositions JX_QAChar_ComparePointValues
    #(facePositions[1], facePositions[2], facePositions[3], normalValue)
)


fn JX_QAChar_CompareFaceSamples leftValue rightValue =
(
    for sampleIndex = 1 to 4 do
    (
        local sampleOrder = JX_QAChar_ComparePointValues leftValue[sampleIndex] rightValue[sampleIndex]
        if sampleOrder != 0 do return sampleOrder
    )
    0
)


fn JX_QAChar_ValidateWorldMesh node savedMesh positionTolerance:0.001 normalTolerance:0.999 =
(
    local currentMesh = JX_QAChar_CaptureWorldMesh node
    if currentMesh[1] != savedMesh[1] or currentMesh[2] != savedMesh[2] then
        return #(false, 1e9, -1.0, "顶点数或面数发生变化")
    -- 常规情况下编号不变，先做线性比较；只有检测到重排时才执行完整排序。
    local orderedMaximumPositionError = 0.0
    local orderedMinimumNormalDot = 1.0
    local orderedTopologySame = true
    for vertexIndex = 1 to savedMesh[3].count do
        orderedMaximumPositionError = amax #(orderedMaximumPositionError,
            (distance savedMesh[3][vertexIndex] currentMesh[3][vertexIndex]))
    for faceIndex = 1 to savedMesh[4].count do
    (
        orderedMaximumPositionError = amax #(orderedMaximumPositionError,
            (distance savedMesh[4][faceIndex] currentMesh[4][faceIndex]))
        orderedMinimumNormalDot = amin #(orderedMinimumNormalDot,
            (dot savedMesh[5][faceIndex] currentMesh[5][faceIndex]))
        local savedFaceIDs = savedMesh[6][faceIndex]
        local currentFaceIDs = currentMesh[6][faceIndex]
        if savedFaceIDs.count != currentFaceIDs.count then orderedTopologySame = false
        else for cornerIndex = 1 to savedFaceIDs.count where savedFaceIDs[cornerIndex] != currentFaceIDs[cornerIndex] do
            orderedTopologySame = false
    )
    if orderedTopologySame and orderedMaximumPositionError <= positionTolerance and orderedMinimumNormalDot >= normalTolerance then
        return #(true, orderedMaximumPositionError, orderedMinimumNormalDot, "世界空间几何、拓扑和面朝向保持不变")
    -- 转换可能重排顶点编号；按每个三角面的三个世界坐标建立签名，避免遗漏拓扑变化。
    local savedPositions = for pointValue in savedMesh[3] collect pointValue
    local currentPositions = for pointValue in currentMesh[3] collect pointValue
    qsort savedPositions JX_QAChar_ComparePointValues
    qsort currentPositions JX_QAChar_ComparePointValues
    local savedFaces = for faceIndex = 1 to savedMesh[4].count collect
        (JX_QAChar_BuildFacePositionSample savedMesh[3] savedMesh[6][faceIndex] savedMesh[5][faceIndex])
    local currentFaces = for faceIndex = 1 to currentMesh[4].count collect
        (JX_QAChar_BuildFacePositionSample currentMesh[3] currentMesh[6][faceIndex] currentMesh[5][faceIndex])
    qsort savedFaces JX_QAChar_CompareFaceSamples
    qsort currentFaces JX_QAChar_CompareFaceSamples
    local maximumPositionError = 0.0
    local minimumNormalDot = 1.0
    for vertexIndex = 1 to savedPositions.count do
        maximumPositionError = amax #(maximumPositionError, (distance savedPositions[vertexIndex] currentPositions[vertexIndex]))
    for faceIndex = 1 to savedFaces.count do
    (
        for cornerIndex = 1 to 3 do
            maximumPositionError = amax #(maximumPositionError,
                (distance savedFaces[faceIndex][cornerIndex] currentFaces[faceIndex][cornerIndex]))
        minimumNormalDot = amin #(minimumNormalDot, (dot savedFaces[faceIndex][4] currentFaces[faceIndex][4]))
    )
    local valid = maximumPositionError <= positionTolerance and minimumNormalDot >= normalTolerance
    #(valid, maximumPositionError, minimumNormalDot,
        if valid then "世界空间几何、拓扑和面朝向保持不变" else
            ("最大位置误差=" + maximumPositionError as string + "，最小法线点积=" + minimumNormalDot as string))
)


-- #(状态, 需缩放, 需旋转, 需轴心, 需翻面, 阻止原因)
fn JX_QAChar_InspectTransform node =
(
    if not JX_QAChar_IsGeometryNode node then return #(#blocked, false, false, false, false, #("不是有效几何体"))
    local needsScale = distance node.scale [1,1,1] > 0.00001
    local needsRotation = JX_QAChar_GetRotationAngle node.rotation > 0.00001
    local needsPivot = distance node.pivot [0,0,0] > 0.001
    local parity = try (node.transform.determinantsign) catch (0)
    local needsFlip = parity < 0
    local needsRepair = needsScale or needsRotation or needsPivot or needsFlip
    local blockers = #()
    if needsRepair do
    (
        local baseData = JX_QAChar_GetEditableBaseData node
        if baseData[1] == #unsupported do append blockers "底层对象不是 Editable Poly/Mesh"
        if JX_QAChar_HasSkin node do append blockers "检测到 Skin；请使用独立的 ResetSkinnedXForm"
        if node.modifiers.count > 0 and not (JX_QAChar_HasSkin node) do append blockers "存在业务修改器；精简版不会自动塌陷堆栈"
        if JX_QAChar_NodeTransformIsAnimated node do append blockers "节点或父级变换带动画"
        if JX_QAChar_GetInstanceCount node > 1 do append blockers "对象存在实例"
        if node.parent != undefined do append blockers "对象存在父级层级"
        if node.children.count > 0 do append blockers "对象存在子节点"
        if parity == 0 do append blockers "变换矩阵为奇异矩阵"
    )
    local status = if blockers.count > 0 then #blocked else if needsRepair then #needsRepair else #clean
    #(status, needsScale, needsRotation, needsPivot, needsFlip, blockers)
)


-- 返回 #(成功, 是否修改, 说明, 备份名称)
fn JX_QAChar_RepairTransform node createBackup:true =
(
    local inspection = JX_QAChar_InspectTransform node
    if inspection[1] == #clean then return #(true, false, "变换已经规范", "")
    if inspection[1] == #blocked then
        return #(false, false, "已阻止：" + JX_QAChar_StringArrayToText inspection[6] separator:"；", "")
    local savedMesh = JX_QAChar_CaptureWorldMesh node
    local baseData = JX_QAChar_GetEditableBaseData node
    local originalBaseKind = baseData[1]
    local originalMaterial = node.material
    local backupNode = undefined
    local succeeded = false
    local failureMessage = ""
    local holdStarted = false
    try
    (
        theHold.Begin()
        holdStarted = true
        if createBackup do backupNode = JX_QAChar_CreateHiddenBackup node
        resetXForm node
        -- 原生 Reset XForm + 类型对应的塌陷会把负奇偶性烘焙进面绕序；不再额外翻面。
        resetPivot node
        node.pivot = [0,0,0]
        node.rotation = (quat 0 0 0 1)
        if originalBaseKind == #poly then convertToPoly node else convertToMesh node
        if originalBaseKind == #poly and classof node.baseObject != Editable_Poly do throw "修复结果不是 Editable Poly"
        if originalBaseKind == #mesh and classof node.baseObject != Editable_mesh do throw "修复结果不是 Editable Mesh"
        if node.modifiers.count != 0 do throw "修复后仍残留修改器"
        local validation = JX_QAChar_ValidateWorldMesh node savedMesh
        if not validation[1] do throw ("修复后验证失败：" + validation[4])
        if node.material != originalMaterial do throw "对象材质引用发生变化"
        if distance node.scale [1,1,1] > 0.00001 do throw "缩放未归一"
        if JX_QAChar_GetRotationAngle node.rotation > 0.00001 do throw "旋转未归零"
        if distance node.pivot [0,0,0] > 0.001 do throw "轴心未归零"
        theHold.Accept "JX QA 安全变换修复"
        holdStarted = false
        succeeded = true
    )
    catch
    (
        failureMessage = try (getCurrentException() as string) catch ("未知错误")
        if holdStarted do try (theHold.Cancel()) catch ()
        holdStarted = false
        succeeded = false
    )
    if succeeded then
        #(true, true, "已安全烘焙并通过完整几何验证", if backupNode != undefined then backupNode.name else "")
    else
        #(false, false, failureMessage, "")
)


-- 返回 #(成功, 是否修改, 说明)
fn JX_QAChar_RepairUVChannels node =
(
    local analysis = JX_QAChar_AnalyzeUVChannels node
    if analysis[1] == #unsupported then return #(false, false, analysis[8])
    if analysis[1] == #missing then return #(false, false, analysis[8])
    if analysis[1] == #valid then return #(true, false, analysis[8])
    if JX_QAChar_HasSkin node then return #(false, false, "检测到 Skin；不会自动修改 UV，请先使用专用流程处理")
    if node.modifiers.count > 0 then return #(false, false, "存在修改器；不会自动塌陷堆栈")
    if JX_QAChar_GetInstanceCount node > 1 then return #(false, false, "对象存在实例")
    local baseKind = analysis[2]
    local baseObj = analysis[3]
    local target = analysis[4]
    local allocatedCount = analysis[5]
    local originalMaterial = node.material
    local originalPolyTopology = if baseKind == #poly then
        #((polyop.getNumVerts target), (polyop.getNumEdges target), (polyop.getNumFaces target)) else undefined
    local originalMeshValue = if baseKind == #mesh then copy target else undefined
    local originalRawMapChannels = #()
    if baseKind == #poly and allocatedCount > 0 do
        originalRawMapChannels = for channelIndex = 0 to allocatedCount - 1 collect
            #(channelIndex, JX_QAChar_CaptureRawMapChannel baseKind target channelIndex)
    local originalRawAlpha = if baseKind == #poly then
        JX_QAChar_CaptureRawMapChannel baseKind target -2 else undefined
    local beforeMesh = JX_QAChar_CaptureWorldMesh node
    local preservedUVBefore = JX_QAChar_CapturePreservedUVChannels baseKind target
    local alphaBefore = #(-2, JX_QAChar_CaptureMapChannel baseKind target -2)
    local succeeded = false
    local failureMessage = ""
    local holdStarted = false
    try
    (
        theHold.Begin()
        holdStarted = true
        if allocatedCount > JX_QACharUVFirstForbiddenChannel do
        (
            for channelIndex = allocatedCount - 1 to JX_QACharUVFirstForbiddenChannel by -1 do
            (
                if baseKind == #poly then
                (
                    polyop.setMapSupport target channelIndex false
                    -- Max 2020 的 PolyOp 只能释放数据，不能降低空高通道的内部槽位上限。
                    -- ChannelInfo 会添加只清理指定 Map 通道的临时修改器，稍后统一受控塌陷。
                    local clearSucceeded = try (channelInfo.ClearChannel node channelIndex; true) catch (false)
                    if not clearSucceeded do throw ("无法创建通道 " + channelIndex as string + " 的清理操作")
                )
                else
                (
                    meshop.setMapSupport target channelIndex false
                    try (meshop.freeMapChannel target channelIndex) catch ()
                )
            )
        )
        if baseKind == #poly then
        (
            collapseStack node
            if classof node.baseObject != Editable_Poly do throw "Poly 通道清理后底层类型发生变化"
            if node.modifiers.count != 0 do throw "Poly 通道清理后仍残留临时修改器"
            baseObj = node.baseObject
            target = baseObj
            local currentPolyTopology = #(
                (polyop.getNumVerts target), (polyop.getNumEdges target), (polyop.getNumFaces target))
            if currentPolyTopology[1] != originalPolyTopology[1] or
                currentPolyTopology[2] != originalPolyTopology[2] or
                currentPolyTopology[3] != originalPolyTopology[3] do
                throw ("Poly 顶点/边/面数量发生变化：" + originalPolyTopology as string +
                    " → " + currentPolyTopology as string)
        )
        else
        (
            meshop.setNumMaps target JX_QACharUVTargetMapCount keep:false
            JX_QAChar_RestoreMeshMapChannels target preservedUVBefore
            baseObj.mesh = target
        )
        update node
        local afterAnalysis = JX_QAChar_AnalyzeUVChannels node
        if afterAnalysis[1] != #valid do throw ("多余 UV 通道仍然存在：" + afterAnalysis[8])
        local currentTarget = afterAnalysis[4]
        local uvValidation = JX_QAChar_ValidateMapChannelCapture baseKind currentTarget preservedUVBefore
        if not uvValidation[1] do throw ("保留 UV 验证失败：" + uvValidation[2])
        local alphaValidation = JX_QAChar_ValidateMapChannelCapture baseKind currentTarget #(alphaBefore)
        if not alphaValidation[1] do throw ("Alpha 验证失败：" + alphaValidation[2])
        local meshValidation = JX_QAChar_ValidateWorldMesh node beforeMesh
        if not meshValidation[1] do throw ("几何验证失败：" + meshValidation[4])
        if node.material != originalMaterial do throw "对象材质引用发生变化"
        theHold.Accept "JX QA 安全删除多余 UV 通道"
        holdStarted = false
        succeeded = true
    )
    catch
    (
        failureMessage = try (getCurrentException() as string) catch ("未知错误")
        if holdStarted do try (theHold.Cancel()) catch ()
        holdStarted = false
        if baseKind == #mesh and originalMeshValue != undefined do
        (
            try (baseObj.mesh = originalMeshValue) catch ()
            try (update node) catch ()
        )
        if baseKind == #poly do try
        (
            local rollbackTarget = node.baseObject
            polyop.setNumMaps rollbackTarget allocatedCount keep:false
            for channelEntry in originalRawMapChannels do
                JX_QAChar_RestoreRawMapChannel baseKind rollbackTarget channelEntry[1] channelEntry[2]
            JX_QAChar_RestoreRawMapChannel baseKind rollbackTarget -2 originalRawAlpha
            update node
        )
        catch (failureMessage += "；UV 显式回滚失败")
        succeeded = false
    )
    if succeeded then #(true, true, if baseKind == #poly then
        "已清理通道 3 及以上；Poly 临时清理操作已受控塌陷并通过完整验证"
        else "已释放通道 3 及以上并缩减内部 Map 通道，未塌陷修改器")
    else #(false, false, failureMessage)
)


-- 分析结果：#(状态, Alpha顶点数, 跨点共享数, 受影响几何点数, 说明)
fn JX_QAChar_AnalyzeAlphaObject node =
(
    local baseData = JX_QAChar_GetEditableBaseData node
    local baseKind = baseData[1]
    if baseKind == #unsupported then
        return #(#unsupported, 0, 0, 0, "底层对象不是 Editable Poly/Mesh")
    local target = if baseKind == #poly then baseData[2] else baseData[3]
    local hasAlpha = try
    (
        if baseKind == #poly then polyop.getMapSupport target -2
        else meshop.getMapSupport target -2
    )
    catch (false)
    if not hasAlpha then return #(#none, 0, 0, 0, "未使用 -2:Alpha 通道")
    local geomFaceCount = if baseKind == #poly then polyop.getNumFaces target else target.numfaces
    local alphaVertCount = if baseKind == #poly then polyop.getNumMapVerts target -2 else meshop.getNumMapVerts target -2
    local alphaFaceCount = if baseKind == #poly then polyop.getNumMapFaces target -2 else meshop.getNumMapFaces target -2
    if alphaVertCount == 0 then return #(#none, 0, 0, 0, "-2:Alpha 通道为空")
    if alphaFaceCount != geomFaceCount then
        return #(#invalid, alphaVertCount, 0, 0,
            "Alpha面数 " + alphaFaceCount as string + " 与几何面数 " + geomFaceCount as string + " 不一致")
    local ownerByAlpha = for alphaIndex = 1 to alphaVertCount collect 0
    local sharedAlpha = #{}
    local affectedGeomVerts = #{}
    for faceIndex = 1 to geomFaceCount do
    (
        local geomFace = try
        (
            if baseKind == #poly then polyop.getFaceVerts target faceIndex
            else JX_QAChar_Point3IndicesToArray (getFace target faceIndex)
        )
        catch (undefined)
        local alphaFace = try
        (
            if baseKind == #poly then polyop.getMapFace target -2 faceIndex
            else JX_QAChar_Point3IndicesToArray (meshop.getMapFace target -2 faceIndex)
        )
        catch (undefined)
        if geomFace == undefined or alphaFace == undefined then
            return #(#invalid, alphaVertCount, 0, 0, "无法读取第 " + faceIndex as string + " 个面的 Alpha 数据")
        if geomFace.count != alphaFace.count then
            return #(#invalid, alphaVertCount, 0, 0, "第 " + faceIndex as string + " 个面的 Alpha 面角数不一致")
        for cornerIndex = 1 to geomFace.count do
        (
            local geomVertID = geomFace[cornerIndex] as integer
            local alphaVertID = alphaFace[cornerIndex] as integer
            if alphaVertID < 1 or alphaVertID > alphaVertCount then
                return #(#invalid, alphaVertCount, 0, 0,
                    "第 " + faceIndex as string + " 个面包含越界 Alpha 索引 " + alphaVertID as string)
            if ownerByAlpha[alphaVertID] == 0 then
                ownerByAlpha[alphaVertID] = geomVertID
            else if ownerByAlpha[alphaVertID] != geomVertID then
            (
                sharedAlpha[alphaVertID] = true
                affectedGeomVerts[ownerByAlpha[alphaVertID]] = true
                affectedGeomVerts[geomVertID] = true
            )
        )
    )
    if sharedAlpha.numberSet > 0 then
        #(#shared, alphaVertCount, sharedAlpha.numberSet, affectedGeomVerts.numberSet, "存在跨几何顶点共享")
    else
        #(#valid, alphaVertCount, 0, 0, "Alpha 索引关系正常")
)


fn JX_QAChar_WriteAlphaChannelData baseKind target alphaValues alphaFaces =
(
    if baseKind == #poly then
    (
        polyop.setNumMapVerts target -2 alphaValues.count keep:false
        for alphaIndex = 1 to alphaValues.count do polyop.setMapVert target -2 alphaIndex alphaValues[alphaIndex]
        for faceIndex = 1 to alphaFaces.count do polyop.setMapFace target -2 faceIndex alphaFaces[faceIndex]
    )
    else
    (
        meshop.setNumMapVerts target -2 alphaValues.count keep:false
        for alphaIndex = 1 to alphaValues.count do meshop.setMapVert target -2 alphaIndex alphaValues[alphaIndex]
        for faceIndex = 1 to alphaFaces.count do
        (
            local alphaFace = alphaFaces[faceIndex]
            meshop.setMapFace target -2 faceIndex [alphaFace[1], alphaFace[2], alphaFace[3]]
        )
        update target
    )
)


-- 返回 #(成功, 是否修改, 旧Alpha顶点数, 新Alpha顶点数, 说明)
fn JX_QAChar_RepairAlphaObject node =
(
    local analysis = JX_QAChar_AnalyzeAlphaObject node
    if analysis[1] == #unsupported then return #(false, false, 0, 0, analysis[5])
    if analysis[1] == #none then return #(true, false, 0, 0, "未使用 Alpha，无需修复")
    if analysis[1] == #valid then return #(true, false, analysis[2], analysis[2], "索引关系正常，无需修复")
    if analysis[1] == #invalid then return #(false, false, analysis[2], analysis[2], "结构损坏，未自动处理：" + analysis[5])
    if JX_QAChar_GetInstanceCount node > 1 then
        return #(false, false, analysis[2], analysis[2], "对象存在实例；不会修改共享 Alpha 数据")
    local baseData = JX_QAChar_GetEditableBaseData node
    local baseKind = baseData[1]
    local baseObj = baseData[2]
    local target = if baseKind == #poly then baseObj else baseData[3]
    local originalMeshValue = if baseKind == #mesh then copy target else undefined
    local originalAlphaData = JX_QAChar_CaptureRawMapChannel baseKind target -2
    local faceCount = if baseKind == #poly then polyop.getNumFaces target else target.numfaces
    local oldAlphaVertCount = analysis[2]
    local ownerLists = for alphaIndex = 1 to oldAlphaVertCount collect #()
    local ownerNewIDs = for alphaIndex = 1 to oldAlphaVertCount collect #()
    local oldAlphaValues = for alphaIndex = 1 to oldAlphaVertCount collect
        (if baseKind == #poly then polyop.getMapVert target -2 alphaIndex else meshop.getMapVert target -2 alphaIndex)
    local newAlphaValues = #()
    local newAlphaFaces = #()
    for faceIndex = 1 to faceCount do
    (
        local geomFace = if baseKind == #poly then polyop.getFaceVerts target faceIndex
            else JX_QAChar_Point3IndicesToArray (getFace target faceIndex)
        local oldAlphaFace = if baseKind == #poly then polyop.getMapFace target -2 faceIndex
            else JX_QAChar_Point3IndicesToArray (meshop.getMapFace target -2 faceIndex)
        local newAlphaFace = #()
        for cornerIndex = 1 to geomFace.count do
        (
            local geomVertID = geomFace[cornerIndex] as integer
            local oldAlphaVertID = oldAlphaFace[cornerIndex] as integer
            local ownerPosition = findItem ownerLists[oldAlphaVertID] geomVertID
            local newAlphaVertID = 0
            if ownerPosition == 0 then
            (
                append ownerLists[oldAlphaVertID] geomVertID
                newAlphaVertID = newAlphaValues.count + 1
                append ownerNewIDs[oldAlphaVertID] newAlphaVertID
                append newAlphaValues oldAlphaValues[oldAlphaVertID]
            )
            else newAlphaVertID = ownerNewIDs[oldAlphaVertID][ownerPosition]
            append newAlphaFace newAlphaVertID
        )
        append newAlphaFaces newAlphaFace
    )
    local succeeded = false
    local failureMessage = ""
    local originalModifierHandles = for modifierItem in node.modifiers collect (getHandleByAnim modifierItem)
    local holdStarted = false
    try
    (
        theHold.Begin()
        holdStarted = true
        JX_QAChar_WriteAlphaChannelData baseKind target newAlphaValues newAlphaFaces
        if baseKind == #mesh do baseObj.mesh = target
        update node
        local verifyResult = JX_QAChar_AnalyzeAlphaObject node
        if verifyResult[1] != #valid do throw ("修复后验证失败：" + verifyResult[5])
        local currentModifierHandles = for modifierItem in node.modifiers collect (getHandleByAnim modifierItem)
        if currentModifierHandles.count != originalModifierHandles.count do throw "修改器堆栈数量发生变化"
        for handleIndex = 1 to originalModifierHandles.count do
            if currentModifierHandles[handleIndex] != originalModifierHandles[handleIndex] do throw "修改器堆栈发生变化"
        theHold.Accept "JX QA 安全修复顶点 Alpha"
        holdStarted = false
        succeeded = true
    )
    catch
    (
        failureMessage = try (getCurrentException() as string) catch ("未知错误")
        if holdStarted do try (theHold.Cancel()) catch ()
        holdStarted = false
        if baseKind == #mesh and originalMeshValue != undefined do
        (
            try (baseObj.mesh = originalMeshValue) catch ()
            try (update node) catch ()
        )
        if baseKind == #poly do try
        (
            JX_QAChar_RestoreRawMapChannel baseKind target -2 originalAlphaData
            update node
        )
        catch (failureMessage += "；Alpha 显式回滚失败")
        succeeded = false
    )
    if succeeded then #(true, true, oldAlphaVertCount, newAlphaValues.count, "跨点共享已解除")
    else #(false, false, oldAlphaVertCount, oldAlphaVertCount, failureMessage)
)


fn JX_QAChar_GetMaterialNamesBySuffix materialValue suffix:"_MBB" =
(
    local result = #()
    if materialValue == undefined do return result
    local materialName = try (materialValue.name as string) catch ("")
    if materialName != "" and matchPattern materialName pattern:("*" + suffix) ignoreCase:true do append result materialName
    result
)


-- 只用于识别“容器内部命中但直接材质未命中”的歧义情况，不参与自动槽位映射。
fn JX_QAChar_MaterialHasNestedSuffix materialValue suffix:"_MBB" visitedHandles:#() =
(
    if materialValue == undefined then return false
    local materialHandle = try (getHandleByAnim materialValue) catch (0)
    if materialHandle != 0 do
    (
        if findItem visitedHandles materialHandle > 0 then return false
        append visitedHandles materialHandle
    )
    local subMaterialCount = try (getNumSubMtls materialValue) catch (0)
    if subMaterialCount <= 0 then return false
    for subMaterialIndex = 1 to subMaterialCount do
    (
        local subMaterial = try (getSubMtl materialValue subMaterialIndex) catch (undefined)
        if subMaterial != undefined do
        (
            if (JX_QAChar_GetMaterialNamesBySuffix subMaterial suffix:suffix).count > 0 then return true
            if JX_QAChar_MaterialHasNestedSuffix subMaterial suffix:suffix visitedHandles:visitedHandles then return true
        )
    )
    false
)


fn JX_QAChar_StringArrayToText values separator:"," =
(
    local result = ""
    if values == undefined do return result
    for value in values do
    (
        if result != "" do result += separator
        result += value as string
    )
    result
)


-- 返回 #(#poly|#mesh|#unsupported, baseObject, faceTarget, faceMaterialIDs)
fn JX_QAChar_GetFaceMaterialData node =
(
    local baseData = JX_QAChar_GetEditableBaseData node
    local baseKind = baseData[1]
    local baseObj = baseData[2]
    local target = baseData[3]
    if baseKind == #unsupported do return #(#unsupported, baseObj, undefined, #())
    if baseKind == #poly do target = baseObj
    local faceCount = if baseKind == #poly then try (polyop.getNumFaces target) catch (0)
        else try (target.numfaces) catch (0)
    if faceCount <= 0 do return #(#unsupported, baseObj, target, #())
    local faceIDs = #()
    for faceIndex = 1 to faceCount do
    (
        local faceID = if baseKind == #poly then try (polyop.getFaceMatID target faceIndex) catch (undefined)
            else try (getFaceMatID target faceIndex) catch (undefined)
        if faceID == undefined do return #(#unsupported, baseObj, target, #())
        append faceIDs (faceID as integer)
    )
    #(baseKind, baseObj, target, faceIDs)
)


fn JX_QAChar_WriteFaceMaterialIDs baseKind baseObj target faceIDs =
(
    try
    (
        if baseKind == #poly then
        (
            if polyop.getNumFaces baseObj != faceIDs.count do throw "面数量发生变化"
            for faceIndex = 1 to faceIDs.count do polyop.setFaceMatID baseObj faceIndex faceIDs[faceIndex]
        )
        else if baseKind == #mesh then
        (
            if target == undefined do target = baseObj.mesh
            if target.numfaces != faceIDs.count do throw "面数量发生变化"
            for faceIndex = 1 to faceIDs.count do setFaceMatID target faceIndex faceIDs[faceIndex]
            update target
            baseObj.mesh = target
        )
        else throw "不支持的底层对象类型"
        try (notifyDependents baseObj partID:#display) catch ()
        true
    )
    catch (false)
)


-- #(状态, 说明, 类型, baseObj, target, faceIDs, material, 是否Multi,
--   珍珠槽位, 珍珠ID, 珍珠名称, 珍珠面数, 另一槽位, 修复模式)
fn JX_QAChar_AnalyzePearlMaterialID node suffix:"_MBB" =
(
    local faceData = JX_QAChar_GetFaceMaterialData node
    local baseKind = faceData[1]
    if baseKind == #unsupported then
        return #(#unsupported, "底层对象不是 Editable Poly/Mesh，或没有可检查面", baseKind,
            faceData[2], faceData[3], faceData[4], undefined, false, 0, 0, #(), 0, 0, #none)

    local faceIDs = faceData[4]
    local nodeMaterial = try (node.material) catch (undefined)
    if nodeMaterial == undefined then
        return #(#none, "没有材质", baseKind, faceData[2], faceData[3], faceIDs,
            nodeMaterial, false, 0, 0, #(), 0, 0, #none)

    local isMulti = (isProperty nodeMaterial #materialList) and (isProperty nodeMaterial #materialIDList)
    if not isMulti then
    (
        local matchedNames = JX_QAChar_GetMaterialNamesBySuffix nodeMaterial suffix:suffix
        if matchedNames.count == 0 then
        (
            if JX_QAChar_MaterialHasNestedSuffix nodeMaterial suffix:suffix then
                return #(#ambiguous, "仅嵌套子材质命中 _MBB，无法按面 Material ID 无损处理", baseKind,
                    faceData[2], faceData[3], faceIDs, nodeMaterial, false, 0, 0, #(), 0, 0, #none)
            return #(#none, "未匹配 _MBB 材质", baseKind, faceData[2], faceData[3], faceIDs,
                nodeMaterial, false, 0, 0, matchedNames, 0, 0, #none)
        )
        local wrongFaceCount = 0
        for faceID in faceIDs where faceID != 1 do wrongFaceCount += 1
        if wrongFaceCount == 0 then
            return #(#valid, "单材质珍珠面的 Material ID 均为 1", baseKind, faceData[2], faceData[3],
                faceIDs, nodeMaterial, false, 0, 1, matchedNames, faceIDs.count, 0, #none)
        return #(#wrong, "单材质珍珠面存在非 1 的 Material ID", baseKind, faceData[2], faceData[3],
            faceIDs, nodeMaterial, false, 0, 0, matchedNames, faceIDs.count, 0, #single)
    )

    local subMaterials = try (nodeMaterial.materialList) catch (#())
    local materialIDs = try (nodeMaterial.materialIDList) catch (#())
    local slotIDs = #()
    local pearlSlots = #()
    local pearlNamesBySlot = #()
    local nestedMatchFound = false
    for slotIndex = 1 to subMaterials.count do
    (
        local slotID = if slotIndex <= materialIDs.count then
            (try (materialIDs[slotIndex] as integer) catch (0)) else slotIndex
        append slotIDs slotID
        local slotNames = JX_QAChar_GetMaterialNamesBySuffix subMaterials[slotIndex] suffix:suffix
        if slotNames.count > 0 do
        (
            append pearlSlots slotIndex
            append pearlNamesBySlot slotNames
        )
        if slotNames.count == 0 and JX_QAChar_MaterialHasNestedSuffix subMaterials[slotIndex] suffix:suffix do
            nestedMatchFound = true
    )

    if nestedMatchFound then
        return #(#ambiguous, "Multi/Sub 槽位内仅嵌套子材质命中 _MBB，无法按槽位无损处理", baseKind,
            faceData[2], faceData[3], faceIDs, nodeMaterial, true, 0, 0, #(), 0, 0, #none)

    if pearlSlots.count == 0 then
        return #(#none, "未匹配 _MBB 材质", baseKind, faceData[2], faceData[3], faceIDs,
            nodeMaterial, true, 0, 0, #(), 0, 0, #none)
    if pearlSlots.count > 1 then
        return #(#ambiguous, "存在多个 _MBB 材质槽位，无法无损合并为 ID 1", baseKind,
            faceData[2], faceData[3], faceIDs, nodeMaterial, true, 0, 0, #(), 0, 0, #none)

    local pearlSlot = pearlSlots[1]
    local pearlNames = pearlNamesBySlot[1]
    local pearlID = slotIDs[pearlSlot]
    if pearlID <= 0 then
        return #(#ambiguous, "_MBB 材质槽位的 Material ID 无效", baseKind, faceData[2],
            faceData[3], faceIDs, nodeMaterial, true, pearlSlot, pearlID, pearlNames, 0, 0, #none)

    local samePearlIDSlotCount = 0
    local targetOneSlots = #()
    for slotIndex = 1 to slotIDs.count do
    (
        if slotIDs[slotIndex] == pearlID do samePearlIDSlotCount += 1
        if slotIDs[slotIndex] == 1 do append targetOneSlots slotIndex
    )
    if samePearlIDSlotCount > 1 then
        return #(#ambiguous, "_MBB 当前 ID 同时映射到多个材质槽位", baseKind, faceData[2],
            faceData[3], faceIDs, nodeMaterial, true, pearlSlot, pearlID, pearlNames, 0, 0, #none)

    local pearlFaceCount = 0
    local targetOneFaceCount = 0
    for faceID in faceIDs do
    (
        if faceID == pearlID do pearlFaceCount += 1
        if faceID == 1 do targetOneFaceCount += 1
    )
    if pearlFaceCount == 0 then
        return #(#unused, "_MBB 材质存在，但没有面使用其 Material ID", baseKind, faceData[2],
            faceData[3], faceIDs, nodeMaterial, true, pearlSlot, pearlID, pearlNames, 0, 0, #none)

    if pearlID == 1 then
    (
        if targetOneSlots.count > 1 then
            return #(#ambiguous, "Material ID 1 同时映射到多个材质槽位", baseKind, faceData[2],
                faceData[3], faceIDs, nodeMaterial, true, pearlSlot, pearlID, pearlNames, pearlFaceCount, 0, #none)
        return #(#valid, "_MBB 材质及对应面均使用 Material ID 1", baseKind, faceData[2],
            faceData[3], faceIDs, nodeMaterial, true, pearlSlot, pearlID, pearlNames, pearlFaceCount, 0, #none)
    )

    if targetOneSlots.count == 0 then
    (
        if targetOneFaceCount > 0 then
            return #(#ambiguous, "存在 ID 1 的面，但 Multi/Sub 中没有对应材质，无法保证外观不变",
                baseKind, faceData[2], faceData[3], faceIDs, nodeMaterial, true, pearlSlot, pearlID,
                pearlNames, pearlFaceCount, 0, #none)
        return #(#wrong, "_MBB 材质及对应面需要重映射为 Material ID 1", baseKind, faceData[2],
            faceData[3], faceIDs, nodeMaterial, true, pearlSlot, pearlID, pearlNames, pearlFaceCount, 0, #move)
    )
    if targetOneSlots.count > 1 then
        return #(#ambiguous, "Material ID 1 同时映射到多个材质槽位", baseKind, faceData[2],
            faceData[3], faceIDs, nodeMaterial, true, pearlSlot, pearlID, pearlNames, pearlFaceCount, 0, #none)

    #(#wrong, "_MBB 材质与 ID 1 材质需要无损交换", baseKind, faceData[2], faceData[3],
        faceIDs, nodeMaterial, true, pearlSlot, pearlID, pearlNames, pearlFaceCount, targetOneSlots[1], #swap)
)


-- #(成功, 是否修改, 说明, 修改面数)
fn JX_QAChar_RepairPearlMaterialID node =
(
    local analysis = JX_QAChar_AnalyzePearlMaterialID node
    local status = analysis[1]
    if status == #valid or status == #none or status == #unused then return #(true, false, analysis[2], 0)
    if status != #wrong then return #(false, false, analysis[2], 0)
    if JX_QAChar_GetInstanceCount node > 1 then
        return #(false, false, "对象存在实例；不会修改共享面 Material ID", 0)

    local baseKind = analysis[3]
    local baseObj = analysis[4]
    local faceTarget = analysis[5]
    local originalMeshValue = if baseKind == #mesh then copy faceTarget else undefined
    local originalFaceIDs = for faceID in analysis[6] collect faceID
    local originalMaterial = analysis[7]
    local isMulti = analysis[8]
    local pearlSlot = analysis[9]
    local pearlID = analysis[10]
    local otherSlot = analysis[13]
    local repairMode = analysis[14]
    local newFaceIDs = for faceID in originalFaceIDs collect faceID
    local changedFaceCount = 0
    local succeeded = false
    local failureMessage = ""
    local holdStarted = false
    try
    (
        theHold.Begin()
        holdStarted = true
        if repairMode == #single then
        (
            for faceIndex = 1 to newFaceIDs.count where newFaceIDs[faceIndex] != 1 do
            (
                newFaceIDs[faceIndex] = 1
                changedFaceCount += 1
            )
        )
        else
        (
            local newMaterial = copy originalMaterial
            local newIDs = for materialID in newMaterial.materialIDList collect (materialID as integer)
            while newIDs.count < newMaterial.materialList.count do append newIDs (newIDs.count + 1)
            newIDs[pearlSlot] = 1
            if repairMode == #swap do newIDs[otherSlot] = pearlID
            newMaterial.materialIDList = newIDs
            node.material = newMaterial
            for faceIndex = 1 to newFaceIDs.count do
            (
                local oldID = newFaceIDs[faceIndex]
                if oldID == pearlID then
                (
                    newFaceIDs[faceIndex] = 1
                    changedFaceCount += 1
                )
                else if repairMode == #swap and oldID == 1 then
                (
                    newFaceIDs[faceIndex] = pearlID
                    changedFaceCount += 1
                )
            )
        )
        if not (JX_QAChar_WriteFaceMaterialIDs baseKind baseObj faceTarget newFaceIDs) do throw "写入面 Material ID 失败"
        local verifyResult = JX_QAChar_AnalyzePearlMaterialID node
        if verifyResult[1] != #valid do throw ("修复后验证失败：" + verifyResult[2])
        theHold.Accept "JX QA 安全修复珍珠 Material ID"
        holdStarted = false
        succeeded = true
    )
    catch
    (
        failureMessage = try (getCurrentException() as string) catch ("未知错误")
        if holdStarted do try (theHold.Cancel()) catch ()
        holdStarted = false
        if baseKind == #mesh and originalMeshValue != undefined do
        (
            try (baseObj.mesh = originalMeshValue) catch ()
            try (update node) catch ()
        )
        try (node.material = originalMaterial) catch (failureMessage += "；材质引用回滚失败")
        if baseKind == #poly do try
        (
            for faceIndex = 1 to originalFaceIDs.count do
                polyop.setFaceMatID baseObj faceIndex originalFaceIDs[faceIndex]
            update node
        )
        catch (failureMessage += "；面 Material ID 回滚失败")
        succeeded = false
    )
    if succeeded then
        #(true, true,
            if isMulti then (if repairMode == #swap then "已无损交换珍珠材质与原 ID 1 材质" else "已将珍珠材质及对应面重映射为 ID 1")
            else "已将单材质珍珠面的 Material ID 统一为 1",
            changedFaceCount)
    else #(false, false, failureMessage, 0)
)


try (destroyDialog JX_QAPearlCountDialog) catch ()
rollout JX_QAPearlCountDialog "珍珠数量确认" width:330 height:132
(
    label lbl_prompt "当前选择中应该有几个使用 _MBB 材质的模型？" pos:[16,14] width:298 height:18
    spinner spn_expected "预期数量：" range:[0,999,0] type:#integer fieldwidth:72 pos:[88,44] width:154
    button btn_confirm "确认" pos:[76,86] width:80 height:28
    button btn_cancel "取消" pos:[174,86] width:80 height:28
    on btn_confirm pressed do
    (
        JX_QAPearlExpectedCount = spn_expected.value as integer
        destroyDialog JX_QAPearlCountDialog
    )
    on btn_cancel pressed do
    (
        JX_QAPearlExpectedCount = undefined
        destroyDialog JX_QAPearlCountDialog
    )
)


fn JX_QAChar_RequestExpectedPearlCount =
(
    JX_QAPearlExpectedCount = undefined
    try (destroyDialog JX_QAPearlCountDialog) catch ()
    createDialog JX_QAPearlCountDialog 330 132 modal:true
    JX_QAPearlExpectedCount
)


try (destroyDialog ModelCheckerTool) catch ()
rollout ModelCheckerTool "角色模型规范检查 v2.1.3" width:540 height:900
(
    local logNormalColor = undefined
    local logProblemColor = undefined
    local logSuccessColor = undefined
    local logLineCount = 0
    local logBatchDepth = 0
    local logMaxLines = 2000
    local logTrimLines = 500

    group "1. 命名规范"
    (
        checkbox chk_naming "名称=场景文件名 + _Body/_Hair/_Head/_Skin" checked:true
        button btn_fix_naming "修复" width:56 height:22 align:#right offset:[0,-25]
        progressbar pb_naming width:488 height:4 color:(color 70 130 180) value:0
    )
    group "2. 模型单位设置"
    (
        checkbox chk_units "系统和显示单位均为厘米" checked:true
        button btn_fix_units "修复" width:56 height:22 align:#right offset:[0,-25]
        progressbar pb_units width:488 height:4 color:(color 70 130 180) value:0
        label lbl_unit_caption "当前单位：" across:2
        label lbl_unit_value "" width:360 style_sunkenedge:true
    )
    group "3. 模型变换与面朝向"
    (
        checkbox chk_transform "检查轴心、旋转、缩放和负变换" checked:true
        button btn_fix_transform "安全修复" width:76 height:22 align:#right offset:[0,-25]
        progressbar pb_transform width:488 height:4 color:(color 70 130 180) value:0
        checkbox chk_backup "修复前创建隐藏备份" checked:true
        label lbl_skin_hint "Skin 对象只检查，不在本插件内修复；请使用独立 ResetSkinnedXForm。" width:488
    )
    group "4. UV 通道检查"
    (
        checkbox chk_uv "仅允许 Map 通道 0–2 含有效数据" checked:true
        button btn_fix_uv "修复" width:56 height:22 align:#right offset:[0,-25]
        progressbar pb_uv width:488 height:4 color:(color 70 130 180) value:0
    )
    group "5. 顶点 Alpha 通道"
    (
        checkbox chk_alpha "检查 -2:Alpha 是否跨几何顶点共享" checked:true
        button btn_fix_alpha "修复" width:56 height:22 align:#right offset:[0,-25]
        progressbar pb_alpha width:488 height:4 color:(color 70 130 180) value:0
    )
    group "6. 珍珠 Material ID / 数量"
    (
        checkbox chk_pearl_id "_MBB 材质及对应面 Material ID 必须为 1" checked:true
        button btn_fix_pearl "修复" width:56 height:22 align:#right offset:[0,-25]
        progressbar pb_pearl width:488 height:4 color:(color 70 130 180) value:0
        checkbox chk_pearl_count "全部检查前确认 _MBB 模型数量" checked:false
    )
    group "操作"
    (
        button btn_check_all "全部检查" width:116 height:30 color:(color 70 130 180) across:4
        button btn_fix_all "全部修复" width:116 height:30 color:(color 60 179 113)
        button btn_clear_log "清除日志" width:116 height:30
        button btn_refresh "刷新 / 复检" width:116 height:30
    )

    label lbl_log "检查日志" pos:[16,568] width:508 height:18
    dotNetControl log_display "System.Windows.Forms.RichTextBox" pos:[16,588] width:508 height:296

    fn resolveLogLevel message requestedLevel =
    (
        if requestedLevel != #auto then requestedLevel
        else if matchPattern message pattern:"✗*" or matchPattern message pattern:"*已阻止*" or
            matchPattern message pattern:"*错误*" or matchPattern message pattern:"*失败*" then #problem
        else if matchPattern message pattern:"✓*" then #success
        else #info
    )

    fn resolveLogColor levelValue =
    (
        case levelValue of
        (
            #problem: logProblemColor
            #blocked: logProblemColor
            #success: logSuccessColor
            default: logNormalColor
        )
    )

    fn trimLogIfNeeded =
    (
        if logLineCount <= logMaxLines then return false
        try
        (
            local cutIndex = log_display.GetFirstCharIndexFromLine logTrimLines
            if cutIndex > 0 do
            (
                local wasReadOnly = log_display.ReadOnly
                local trimSucceeded = false
                try
                (
                    log_display.ReadOnly = false
                    log_display.Select 0 cutIndex
                    log_display.SelectedText = ""
                    trimSucceeded = true
                )
                catch ()
                try (log_display.ReadOnly = wasReadOnly) catch ()
                if trimSucceeded do logLineCount -= logTrimLines
            )
        )
        catch ()
        true
    )

    fn beginLogBatch =
    (
        logBatchDepth += 1
        if logBatchDepth == 1 do try (log_display.SuspendLayout()) catch ()
    )

    fn endLogBatch =
    (
        logBatchDepth = amax #(0, logBatchDepth - 1)
        if logBatchDepth == 0 do
        (
            try (log_display.ResumeLayout()) catch ()
            try
            (
                log_display.Select log_display.TextLength 0
                log_display.ScrollToCaret()
            )
            catch ()
        )
    )

    fn addLog message level:#auto =
    (
        local resolvedLevel = resolveLogLevel message level
        try
        (
            log_display.Select log_display.TextLength 0
            log_display.SelectionColor = resolveLogColor resolvedLevel
            log_display.AppendText ((message as string) + "\r\n")
            logLineCount += 1
            trimLogIfNeeded()
            if logBatchDepth == 0 do
            (
                log_display.Select log_display.TextLength 0
                log_display.ScrollToCaret()
            )
        )
        catch ()
    )

    fn clearLog =
    (
        try (log_display.Clear()) catch ()
        logLineCount = 0
    )

    fn resetProgress =
    (
        pb_naming.value = 0
        pb_units.value = 0
        pb_transform.value = 0
        pb_uv.value = 0
        pb_alpha.value = 0
        pb_pearl.value = 0
    )

    fn selectedNodes = for node in selection collect node

    fn checkNaming =
    (
        local nodes = selectedNodes()
        local sceneBase = JX_QAChar_GetSceneBaseName()
        local problemCount = 0
        if nodes.count == 0 then
        (
            addLog "✗ 命名检查：请先选择对象" level:#problem
            pb_naming.value = 100
            return false
        )
        if sceneBase == "" then
        (
            addLog "✗ 命名检查：场景尚未保存，无法确定文件名前缀" level:#problem
            pb_naming.value = 100
            return false
        )
        for node in nodes do
        (
            local suffixValue = JX_QAChar_GetNamingSuffix node.name
            local expectedName = sceneBase + JX_QAChar_FormatNamingSuffix suffixValue
            if suffixValue == "" then
            (
                problemCount += 1
                addLog ("✗ 命名：" + node.name + " 没有合法部件后缀") level:#problem
            )
            else if node.name != expectedName then
            (
                problemCount += 1
                addLog ("✗ 命名：" + node.name + "，应为 " + expectedName) level:#problem
            )
            else addLog ("✓ 命名：" + node.name) level:#success
        )
        pb_naming.value = 100
        problemCount == 0
    )

    fn fixNaming =
    (
        local nodes = selectedNodes()
        local sceneBase = JX_QAChar_GetSceneBaseName()
        if nodes.count == 0 or sceneBase == "" then return checkNaming()
        for node in nodes do
        (
            local suffixValue = JX_QAChar_GetNamingSuffix node.name
            if suffixValue == "" then addLog ("✗ 跳过未知命名：" + node.name) level:#problem
            else
            (
                local desiredName = sceneBase + JX_QAChar_FormatNamingSuffix suffixValue
                local occupiedNode = getNodeByName desiredName exact:true
                if occupiedNode != undefined and occupiedNode != node then
                    addLog ("✗ 名称冲突，未修改：" + node.name + "；目标名已被 " + occupiedNode.name + " 占用") level:#blocked
                else
                (
                    node.name = desiredName
                    addLog ("✓ 已命名：" + desiredName) level:#success
                )
            )
        )
        checkNaming()
    )

    fn checkUnits =
    (
        local isCorrect = JX_QAChar_UnitsAreCentimeters()
        lbl_unit_value.text = JX_QAChar_GetCurrentUnitText()
        pb_units.value = 100
        if isCorrect then addLog "✓ 单位设置正确：系统单位与显示单位均为厘米" level:#success
        else addLog ("✗ 单位设置错误：" + lbl_unit_value.text) level:#problem
        isCorrect
    )

    fn fixUnits =
    (
        local succeeded = JX_QAChar_SetUnitsToCentimeters()
        if not succeeded do addLog "✗ 单位修复失败" level:#problem
        checkUnits()
    )

    fn checkTransforms =
    (
        local nodes = selectedNodes()
        local problemCount = 0
        if nodes.count == 0 then
        (
            addLog "✗ 变换检查：请先选择对象" level:#problem
            pb_transform.value = 100
            return false
        )
        for node in nodes do
        (
            local result = JX_QAChar_InspectTransform node
            case result[1] of
            (
                #clean: addLog ("✓ 变换：" + node.name) level:#success
                #needsRepair:
                (
                    problemCount += 1
                    addLog ("✗ 变换需修复：" + node.name) level:#problem
                )
                default:
                (
                    problemCount += 1
                    addLog ("✗ 变换已阻止：" + node.name + " - " +
                        JX_QAChar_StringArrayToText result[6] separator:"；") level:#blocked
                )
            )
        )
        pb_transform.value = 100
        problemCount == 0
    )

    fn fixTransforms =
    (
        local nodes = selectedNodes()
        local failureCount = 0
        if nodes.count == 0 then return checkTransforms()
        for node in nodes do
        (
            local result = JX_QAChar_RepairTransform node createBackup:chk_backup.checked
            if result[1] then
            (
                if result[2] then addLog ("✓ 变换修复：" + node.name + " - " + result[3]) level:#success
                else addLog ("✓ 变换无需修复：" + node.name) level:#success
            )
            else
            (
                failureCount += 1
                addLog ("✗ 变换修复未执行：" + node.name + " - " + result[3]) level:#blocked
            )
        )
        pb_transform.value = 100
        failureCount == 0
    )

    fn checkUV =
    (
        local nodes = selectedNodes()
        local checkedCount = 0
        local problemCount = 0
        if nodes.count == 0 then
        (
            addLog "✗ UV 检查：请先选择对象" level:#problem
            pb_uv.value = 100
            return false
        )
        for node in nodes do
        (
            local analysis = JX_QAChar_AnalyzeUVChannels node
            case analysis[1] of
            (
                #unsupported:
                (
                    problemCount += 1
                    addLog ("✗ UV 无法检查：" + node.name + " - " + analysis[8]) level:#problem
                )
                #wrong:
                (
                    checkedCount += 1
                    problemCount += 1
                    addLog ("✗ UV：" + node.name + "，内部通道数=" + analysis[5] as string +
                        "，启用=" + JX_QAChar_StringArrayToText analysis[6]) level:#problem
                )
                #missing:
                (
                    checkedCount += 1
                    problemCount += 1
                    addLog ("✗ UV：" + node.name + " - " + analysis[8]) level:#problem
                )
                default:
                (
                    checkedCount += 1
                    addLog ("✓ UV：" + node.name + "，内部通道数=" + analysis[5] as string +
                        "，启用=" + JX_QAChar_StringArrayToText analysis[6]) level:#success
                )
            )
        )
        pb_uv.value = 100
        nodes.count > 0 and checkedCount > 0 and problemCount == 0
    )

    fn fixUV =
    (
        local nodes = selectedNodes()
        local failureCount = 0
        if nodes.count == 0 then
        (
            addLog "✗ UV 修复：请先选择对象" level:#problem
            pb_uv.value = 100
            return false
        )
        for node in nodes do
        (
            local result = JX_QAChar_RepairUVChannels node
            if result[1] then
            (
                if result[2] then addLog ("✓ UV 修复：" + node.name + " - " + result[3]) level:#success
                else addLog ("· UV 无需修复：" + node.name + " - " + result[3]) level:#info
            )
            else
            (
                failureCount += 1
                addLog ("✗ UV 修复未执行：" + node.name + " - " + result[3]) level:#blocked
            )
        )
        pb_uv.value = 100
        failureCount == 0
    )

    fn checkAlpha =
    (
        local nodes = selectedNodes()
        local checkedCount = 0
        local problemCount = 0
        for node in nodes do
        (
            local result = JX_QAChar_AnalyzeAlphaObject node
            case result[1] of
            (
                #unsupported:
                (
                    problemCount += 1
                    addLog ("✗ Alpha 无法检查：" + node.name + " - " + result[5]) level:#problem
                )
                #none:
                (
                    checkedCount += 1
                    addLog ("✓ Alpha：" + node.name + " - " + result[5]) level:#success
                )
                #valid:
                (
                    checkedCount += 1
                    addLog ("✓ Alpha：" + node.name + " 索引正常") level:#success
                )
                default:
                (
                    checkedCount += 1
                    problemCount += 1
                    addLog ("✗ Alpha：" + node.name + " - " + result[5]) level:#problem
                )
            )
        )
        pb_alpha.value = 100
        if checkedCount == 0 do addLog "✗ Alpha 检查：请选择 Editable Poly/Mesh" level:#problem
        checkedCount > 0 and problemCount == 0
    )

    fn fixAlpha =
    (
        local nodes = selectedNodes()
        local failureCount = 0
        if nodes.count == 0 then
        (
            addLog "✗ Alpha 修复：请先选择对象" level:#problem
            pb_alpha.value = 100
            return false
        )
        for node in nodes do
        (
            local result = JX_QAChar_RepairAlphaObject node
            if result[1] then
            (
                if result[2] then addLog ("✓ Alpha 修复：" + node.name + "，数据顶点 " +
                    result[3] as string + " → " + result[4] as string) level:#success
                else addLog ("· Alpha 无需修复：" + node.name + " - " + result[5]) level:#info
            )
            else
            (
                failureCount += 1
                addLog ("✗ Alpha 修复失败：" + node.name + " - " + result[5]) level:#problem
            )
        )
        pb_alpha.value = 100
        failureCount == 0
    )

    fn checkPearl expectedCount:undefined =
    (
        local nodes = selectedNodes()
        local pearlCount = 0
        local problemCount = 0
        local supportedCount = 0
        if nodes.count == 0 then
        (
            addLog "✗ 珍珠检查：请先选择对象" level:#problem
            pb_pearl.value = 100
            return false
        )
        for node in nodes do
        (
            local result = JX_QAChar_AnalyzePearlMaterialID node
            case result[1] of
            (
                #valid:
                (
                    supportedCount += 1
                    pearlCount += 1
                    addLog ("✓ 珍珠 ID：" + node.name + "，命中 " + result[12] as string + " 个面") level:#success
                )
                #wrong:
                (
                    supportedCount += 1
                    pearlCount += 1
                    problemCount += 1
                    addLog ("✗ 珍珠 ID：" + node.name + " - " + result[2]) level:#problem
                )
                #ambiguous:
                (
                    supportedCount += 1
                    pearlCount += 1
                    problemCount += 1
                    addLog ("✗ 珍珠 ID 无法无损处理：" + node.name + " - " + result[2]) level:#problem
                )
                #unused:
                (
                    supportedCount += 1
                    pearlCount += 1
                    problemCount += 1
                    addLog ("✗ 珍珠 ID：" + node.name + " - " + result[2]) level:#problem
                )
                #none:
                (
                    supportedCount += 1
                    addLog ("· 珍珠：" + node.name + " - " + result[2]) level:#info
                )
                default:
                (
                    problemCount += 1
                    addLog ("✗ 珍珠无法检查：" + node.name + " - " + result[2]) level:#problem
                )
            )
        )
        if expectedCount != undefined then
        (
            if pearlCount == expectedCount then addLog ("✓ 珍珠数量：" + pearlCount as string) level:#success
            else
            (
                problemCount += 1
                addLog ("✗ 珍珠数量：预期 " + expectedCount as string + "，实际 " + pearlCount as string) level:#problem
            )
        )
        if pearlCount == 0 and expectedCount == undefined and supportedCount > 0 do
            addLog "✓ 当前选择未发现直接命名为 _MBB 的珍珠材质" level:#success
        pb_pearl.value = 100
        supportedCount > 0 and problemCount == 0
    )

    fn fixPearl =
    (
        local nodes = selectedNodes()
        local failureCount = 0
        if nodes.count == 0 then
        (
            addLog "✗ 珍珠修复：请先选择对象" level:#problem
            pb_pearl.value = 100
            return false
        )
        for node in nodes do
        (
            local beforeResult = JX_QAChar_AnalyzePearlMaterialID node
            if beforeResult[1] == #wrong then
            (
                local result = JX_QAChar_RepairPearlMaterialID node
                if result[1] then addLog ("✓ 珍珠 ID 修复：" + node.name + " - " + result[3]) level:#success
                else
                (
                    failureCount += 1
                    addLog ("✗ 珍珠 ID 修复失败：" + node.name + " - " + result[3]) level:#problem
                )
            )
            else if beforeResult[1] == #ambiguous or beforeResult[1] == #unused then
            (
                failureCount += 1
                addLog ("✗ 珍珠 ID 未处理：" + node.name + " - " + beforeResult[2]) level:#problem
            )
            else if beforeResult[1] == #unsupported then
            (
                failureCount += 1
                addLog ("✗ 珍珠 ID 无法检查：" + node.name + " - " + beforeResult[2]) level:#problem
            )
            else addLog ("· 珍珠 ID 无需修复：" + node.name + " - " + beforeResult[2]) level:#info
        )
        pb_pearl.value = 100
        failureCount == 0
    )

    fn runAllChecks askPearlCount:false =
    (
        local expectedPearlCount = undefined
        if askPearlCount and chk_pearl_id.checked and chk_pearl_count.checked do
        (
            expectedPearlCount = JX_QAChar_RequestExpectedPearlCount()
            if expectedPearlCount == undefined do return false
        )
        local allPassed = true
        local failureMessage = ""
        beginLogBatch()
        try
        (
            resetProgress()
            addLog "=== 开始检查 ==="
            if chk_naming.checked do if not checkNaming() do allPassed = false
            if chk_units.checked do if not checkUnits() do allPassed = false
            if chk_transform.checked do if not checkTransforms() do allPassed = false
            if chk_uv.checked do if not checkUV() do allPassed = false
            if chk_alpha.checked do if not checkAlpha() do allPassed = false
            if chk_pearl_id.checked do if not (checkPearl expectedCount:expectedPearlCount) do allPassed = false
            if allPassed then addLog "=== 检查完成：全部通过 ===" level:#success
            else addLog "=== 检查完成：存在问题 ===" level:#problem
        )
        catch
        (
            failureMessage = try (getCurrentException() as string) catch ("未知错误")
            allPassed = false
        )
        endLogBatch()
        if failureMessage != "" do addLog ("✗ 批量检查异常：" + failureMessage) level:#problem
        allPassed
    )

    fn runAllFixes =
    (
        local allSucceeded = true
        local failureMessage = ""
        beginLogBatch()
        try
        (
            addLog "=== 开始修复 ==="
            if chk_naming.checked do if not fixNaming() do allSucceeded = false
            if chk_units.checked do if not fixUnits() do allSucceeded = false
            if chk_transform.checked do if not fixTransforms() do allSucceeded = false
            if chk_uv.checked do if not fixUV() do allSucceeded = false
            if chk_alpha.checked do if not fixAlpha() do allSucceeded = false
            if chk_pearl_id.checked do if not fixPearl() do allSucceeded = false
            addLog "=== 修复结束，自动复检 ==="
        )
        catch
        (
            failureMessage = try (getCurrentException() as string) catch ("未知错误")
            allSucceeded = false
        )
        endLogBatch()
        if failureMessage != "" do addLog ("✗ 批量修复异常：" + failureMessage) level:#problem
        local postCheckPassed = runAllChecks askPearlCount:false
        allSucceeded and failureMessage == "" and postCheckPassed
    )

    on ModelCheckerTool open do
    (
        local colorClass = dotNetClass "System.Drawing.Color"
        local borderStyleClass = dotNetClass "System.Windows.Forms.BorderStyle"
        local scrollBarsClass = dotNetClass "System.Windows.Forms.RichTextBoxScrollBars"
        logNormalColor = colorClass.Gainsboro
        logProblemColor = colorClass.FromArgb 255 96 96
        logSuccessColor = colorClass.FromArgb 120 220 150
        log_display.ReadOnly = true
        log_display.BackColor = colorClass.FromArgb 64 64 64
        log_display.ForeColor = logNormalColor
        log_display.BorderStyle = borderStyleClass.FixedSingle
        log_display.ScrollBars = scrollBarsClass.Both
        log_display.WordWrap = false
        log_display.DetectUrls = false
        lbl_unit_value.text = JX_QAChar_GetCurrentUnitText()
        addLog ("=== 角色模型规范检查 v" + JX_QACharVersion + " ===")
        addLog "Skin 修复已拆分；本工具只阻止可能破坏蒙皮的操作。"
    )

    on btn_check_all pressed do
    (
        clearLog()
        runAllChecks askPearlCount:true
    )
    on btn_fix_all pressed do
    (
        runAllFixes()
    )
    on btn_fix_naming pressed do fixNaming()
    on btn_fix_units pressed do fixUnits()
    on btn_fix_transform pressed do fixTransforms()
    on btn_fix_uv pressed do fixUV()
    on btn_fix_alpha pressed do fixAlpha()
    on btn_fix_pearl pressed do fixPearl()
    on btn_clear_log pressed do clearLog()
    on btn_refresh pressed do
    (
        lbl_unit_value.text = JX_QAChar_GetCurrentUnitText()
        runAllChecks askPearlCount:false
    )
)


fn JX_QAChar_Show =
(
    if ModelCheckerTool != undefined and ModelCheckerTool.open then
    (
        try (setFocus ModelCheckerTool) catch ()
        true
    )
    else
    (
        try (destroyDialog ModelCheckerTool) catch ()
        createDialog ModelCheckerTool 540 900 style:#(#style_titlebar, #style_sysmenu, #style_minimizebox)
        true
    )
)


macroScript JX_QAChar
category:"JXTools"
toolTip:"角色模型规范检查"
buttonText:"角色模型规范检查"
(
    on execute do JX_QAChar_Show()
)
