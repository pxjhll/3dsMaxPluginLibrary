/*
	JX QA Character Tool
	Version 2.1.6

	Version 1.0.2 behavior with the v2.1.5 pearl Material ID and count module only.
*/

global JX_QACharVersion = "2.1.6"
global JXCharQATool
global JX_QAPearlCountDialog
global JX_QAPearlExpectedCount

struct JXCharQA
(
	-- 首字母大写函数
	fn capitalizeFirstLetter str =
	(
		if str.count > 0 then
		(
			local firstChar = toUpper str[1]
			local restChars = if str.count > 1 then substring str 2 -1 else ""
			return firstChar + restChars
		)
		else
		(
			return str
		)
	),
	-- 处理下划线后的大写转换
	fn formatUnderscoreString str =
	(
		local parts = filterString str "_"
		local result = ""
		
		for i = 1 to parts.count do
		(
			if i == 1 then
			(
				result += parts[i]
			)
			else
			(
				result += "_" + capitalizeFirstLetter parts[i]
			)
		)
		return result
	),
	fn uppercase instring = (
		local upper, lower, outstring
		upper = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
		lower = "abcdefghijklmnopqrstuvwxyz"
		outstring = copy instring
		for i = 1 to outstring.count do 
		(
			j = findString lower outstring[i]
			if (j != undefined) do outstring[i] = upper[j]
		)
		return 	outstring
	),	
	fn lowercase instring = (
		local upper, lower, outstring
		upper = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
		lower = "abcdefghijklmnopqrstuvwxyz"
		outstring = copy instring
		for i = 1 to outstring.count do 
		(
			j = findString upper outstring[i]
			if (j != undefined) do outstring[i] = lower[j]
		)
		return outstring
	),
	fn startsWith str prefix = (
		if str.count < prefix.count then return false
		local subStr = substring str 1 prefix.count
		return subStr == prefix
	),

	namingBacks = #("_body", "_hair", "_head", "_skin")
)

JXCharQATool = JXCharQA()

-- 将三角面索引转换为普通数组
fn JX_QAChar_Point3IndicesToArray indices =
(
	#((indices.x as integer), (indices.y as integer), (indices.z as integer))
)

-- 返回 #(#poly|#mesh|#unsupported, baseObject, meshCopy)
fn JX_QAChar_GetAlphaBaseData obj =
(
	local baseObj = try (obj.baseObject) catch (undefined)
	if baseObj == undefined then return #(#unsupported, undefined, undefined)

	if isKindOf baseObj Editable_Poly then
		#(#poly, baseObj, undefined)
	else if isKindOf baseObj Editable_mesh then
		#(#mesh, baseObj, baseObj.mesh)
	else
		#(#unsupported, baseObj, undefined)
)

-- 分析结果：
-- #(#unsupported|#none|#valid|#shared|#invalid,
--   Alpha顶点数, 跨点共享Alpha数, 受影响几何点数, 说明)
fn JX_QAChar_AnalyzeAlphaObject obj =
(
	local baseData = JX_QAChar_GetAlphaBaseData obj
	local baseKind = baseData[1]
	if baseKind == #unsupported then
		return #(#unsupported, 0, 0, 0, "底层对象不是可编辑多边形或可编辑网格")

	local target = if baseKind == #poly then baseData[2] else baseData[3]
	local hasAlpha = try
	(
		if baseKind == #poly then
			polyop.getMapSupport target -2
		else
			meshop.getMapSupport target -2
	)
	catch (false)

	if not hasAlpha then return #(#none, 0, 0, 0, "未使用 -2:Alpha 通道")

	local geomFaceCount = if baseKind == #poly then
		polyop.getNumFaces target
	else
		target.numfaces
	local alphaVertCount = if baseKind == #poly then
		polyop.getNumMapVerts target -2
	else
		meshop.getNumMapVerts target -2
	local alphaFaceCount = if baseKind == #poly then
		polyop.getNumMapFaces target -2
	else
		meshop.getNumMapFaces target -2

	if alphaVertCount == 0 then return #(#none, 0, 0, 0, "-2:Alpha 通道为空")
	if alphaFaceCount != geomFaceCount then
		return #(#invalid, alphaVertCount, 0, 0,
			("Alpha面数 " + alphaFaceCount as string + " 与几何面数 " + geomFaceCount as string + " 不一致"))

	local ownerByAlpha = for i = 1 to alphaVertCount collect 0
	local sharedAlpha = #{}
	local affectedGeomVerts = #{}

	for faceIndex = 1 to geomFaceCount do
	(
		local geomFace = try
		(
			if baseKind == #poly then
				polyop.getFaceVerts target faceIndex
			else
				JX_QAChar_Point3IndicesToArray (getFace target faceIndex)
		)
		catch (undefined)
		local alphaFace = try
		(
			if baseKind == #poly then
				polyop.getMapFace target -2 faceIndex
			else
				JX_QAChar_Point3IndicesToArray (meshop.getMapFace target -2 faceIndex)
		)
		catch (undefined)

		if geomFace == undefined or alphaFace == undefined then
			return #(#invalid, alphaVertCount, 0, 0, ("无法读取第 " + faceIndex as string + " 个面的Alpha数据"))
		if geomFace.count != alphaFace.count then
			return #(#invalid, alphaVertCount, 0, 0, ("第 " + faceIndex as string + " 个面的Alpha面角数不一致"))

		for cornerIndex = 1 to geomFace.count do
		(
			local geomVertID = geomFace[cornerIndex] as integer
			local alphaVertID = alphaFace[cornerIndex] as integer

			if alphaVertID < 1 or alphaVertID > alphaVertCount then
				return #(#invalid, alphaVertCount, 0, 0,
					("第 " + faceIndex as string + " 个面包含越界Alpha索引 " + alphaVertID as string))

			if ownerByAlpha[alphaVertID] == 0 then
				ownerByAlpha[alphaVertID] = geomVertID
			else if ownerByAlpha[alphaVertID] != geomVertID then
			(
				sharedAlpha[alphaVertID] = true
				affectedGeomVerts[ownerByAlpha[alphaVertID]] = true
				affectedGeomVerts[geomVertID] = true
			)
		)
	)

	if sharedAlpha.numberSet > 0 then
		#(#shared, alphaVertCount, sharedAlpha.numberSet, affectedGeomVerts.numberSet, "存在跨几何顶点共享")
	else
		#(#valid, alphaVertCount, 0, 0, "Alpha索引关系正常")
)

fn JX_QAChar_WriteAlphaChannelData baseKind target alphaValues alphaFaces =
(
	if baseKind == #poly then
	(
		polyop.setNumMapVerts target -2 alphaValues.count keep:false
		for alphaIndex = 1 to alphaValues.count do
			polyop.setMapVert target -2 alphaIndex alphaValues[alphaIndex]
		for faceIndex = 1 to alphaFaces.count do
			polyop.setMapFace target -2 faceIndex alphaFaces[faceIndex]
	)
	else
	(
		meshop.setNumMapVerts target -2 alphaValues.count keep:false
		for alphaIndex = 1 to alphaValues.count do
			meshop.setMapVert target -2 alphaIndex alphaValues[alphaIndex]
		for faceIndex = 1 to alphaFaces.count do
		(
			local alphaFace = alphaFaces[faceIndex]
			meshop.setMapFace target -2 faceIndex [alphaFace[1], alphaFace[2], alphaFace[3]]
		)
		update target
	)
)

-- 将指定对象的 -2:Alpha 按“旧Alpha索引 + 几何顶点索引”最小拆分。
-- 返回 #(成功, 旧Alpha顶点数, 新Alpha顶点数, 说明)
fn JX_QAChar_RepairAlphaObject obj =
(
	local analysis = JX_QAChar_AnalyzeAlphaObject obj
	if analysis[1] == #unsupported then return #(false, 0, 0, analysis[5])
	if analysis[1] == #none then return #(true, 0, 0, "未使用Alpha通道，无需修复")
	if analysis[1] == #valid then return #(true, analysis[2], analysis[2], "索引关系正常，无需修复")
	if analysis[1] == #invalid then return #(false, analysis[2], analysis[2], ("结构损坏，未自动处理: " + analysis[5]))

	local baseData = JX_QAChar_GetAlphaBaseData obj
	local baseKind = baseData[1]
	local baseObj = baseData[2]
	local target = if baseKind == #poly then baseObj else baseData[3]
	local faceCount = if baseKind == #poly then polyop.getNumFaces target else target.numfaces
	local oldAlphaVertCount = analysis[2]
	local ownerLists = for i = 1 to oldAlphaVertCount collect #()
	local ownerNewIDs = for i = 1 to oldAlphaVertCount collect #()
	local oldAlphaValues = for i = 1 to oldAlphaVertCount collect
		(if baseKind == #poly then polyop.getMapVert target -2 i else meshop.getMapVert target -2 i)
	local oldAlphaFaces = #()
	local newAlphaValues = #()
	local newAlphaFaces = #()
	local originalMesh = if baseKind == #mesh then copy target else undefined

	for faceIndex = 1 to faceCount do
	(
		local geomFace = if baseKind == #poly then
			polyop.getFaceVerts target faceIndex
		else
			JX_QAChar_Point3IndicesToArray (getFace target faceIndex)
		local oldAlphaFace = if baseKind == #poly then
			polyop.getMapFace target -2 faceIndex
		else
			JX_QAChar_Point3IndicesToArray (meshop.getMapFace target -2 faceIndex)
		local newAlphaFace = #()
		append oldAlphaFaces oldAlphaFace

		for cornerIndex = 1 to geomFace.count do
		(
			local geomVertID = geomFace[cornerIndex] as integer
			local oldAlphaVertID = oldAlphaFace[cornerIndex] as integer
			local ownerPos = findItem ownerLists[oldAlphaVertID] geomVertID
			local newAlphaVertID = 0

			if ownerPos == 0 then
			(
				append ownerLists[oldAlphaVertID] geomVertID
				newAlphaVertID = newAlphaValues.count + 1
				append ownerNewIDs[oldAlphaVertID] newAlphaVertID
				append newAlphaValues oldAlphaValues[oldAlphaVertID]
			)
			else
				newAlphaVertID = ownerNewIDs[oldAlphaVertID][ownerPos]

			append newAlphaFace newAlphaVertID
		)

		append newAlphaFaces newAlphaFace
	)

	local repairSucceeded = false
	local repairMessage = ""

	try
	(
		undo "安全修复顶点Alpha" on
		(
			JX_QAChar_WriteAlphaChannelData baseKind target newAlphaValues newAlphaFaces
			if baseKind == #mesh then baseObj.mesh = target
			update obj
		)

		local verifyResult = JX_QAChar_AnalyzeAlphaObject obj
		if verifyResult[1] == #valid then
		(
			repairSucceeded = true
			repairMessage = "跨点共享已解除"
		)
		else
		(
			repairMessage = ("修复后复查未通过: " + verifyResult[5])
			if baseKind == #poly then
				JX_QAChar_WriteAlphaChannelData baseKind target oldAlphaValues oldAlphaFaces
			else
				baseObj.mesh = originalMesh
			update obj
		)
	)
	catch
	(
		try
		(
			if baseKind == #poly then
				JX_QAChar_WriteAlphaChannelData baseKind target oldAlphaValues oldAlphaFaces
			else
				baseObj.mesh = originalMesh
			update obj
		)
		catch ()
		repairMessage = ("修复异常，已尝试恢复原通道: " + ((getCurrentException()) as string))
	)

	#(repairSucceeded, oldAlphaVertCount, newAlphaValues.count, repairMessage)
)


-- BEGIN v2.1.5 PEARL MODULE
fn JX_QAChar_GetInstanceCount node =
(
	local instanceNodes = #()
	try
	(
		InstanceMgr.GetInstances node &instanceNodes
		instanceNodes.count
	)
	catch (1)
)


fn JX_QAChar_GetMaterialNamesBySuffix materialValue suffix:"_MBB" =
(
	local result = #()
	if materialValue == undefined do return result
	local materialName = try (materialValue.name as string) catch ("")
	if materialName != "" and matchPattern materialName pattern:("*" + suffix) ignoreCase:true do append result materialName
	result
)


-- 只用于识别“容器内部命中但直接材质未命中”的歧义情况，不参与自动槽位映射。
fn JX_QAChar_MaterialHasNestedSuffix materialValue suffix:"_MBB" visitedHandles:#() =
(
	if materialValue == undefined then return false
	local materialHandle = try (getHandleByAnim materialValue) catch (0)
	if materialHandle != 0 do
	(
		if findItem visitedHandles materialHandle > 0 then return false
		append visitedHandles materialHandle
	)
	local subMaterialCount = try (getNumSubMtls materialValue) catch (0)
	if subMaterialCount <= 0 then return false
	for subMaterialIndex = 1 to subMaterialCount do
	(
		local subMaterial = try (getSubMtl materialValue subMaterialIndex) catch (undefined)
		if subMaterial != undefined do
		(
			if (JX_QAChar_GetMaterialNamesBySuffix subMaterial suffix:suffix).count > 0 then return true
			if JX_QAChar_MaterialHasNestedSuffix subMaterial suffix:suffix visitedHandles:visitedHandles then return true
		)
	)
	false
)


-- 返回 #(#poly|#mesh|#unsupported, baseObject, faceTarget, faceMaterialIDs)
fn JX_QAChar_GetFaceMaterialData node =
(
	local baseData = JX_QAChar_GetAlphaBaseData node
	local baseKind = baseData[1]
	local baseObj = baseData[2]
	local target = baseData[3]
	if baseKind == #unsupported do return #(#unsupported, baseObj, undefined, #())
	if baseKind == #poly do target = baseObj
	local faceCount = if baseKind == #poly then try (polyop.getNumFaces target) catch (0)
		else try (target.numfaces) catch (0)
	if faceCount <= 0 do return #(#unsupported, baseObj, target, #())
	local faceIDs = #()
	for faceIndex = 1 to faceCount do
	(
		local faceID = if baseKind == #poly then try (polyop.getFaceMatID target faceIndex) catch (undefined)
			else try (getFaceMatID target faceIndex) catch (undefined)
		if faceID == undefined do return #(#unsupported, baseObj, target, #())
		append faceIDs (faceID as integer)
	)
	#(baseKind, baseObj, target, faceIDs)
)


fn JX_QAChar_WriteFaceMaterialIDs baseKind baseObj target faceIDs =
(
	try
	(
		if baseKind == #poly then
		(
			if polyop.getNumFaces baseObj != faceIDs.count do throw "面数量发生变化"
			for faceIndex = 1 to faceIDs.count do polyop.setFaceMatID baseObj faceIndex faceIDs[faceIndex]
		)
		else if baseKind == #mesh then
		(
			if target == undefined do target = baseObj.mesh
			if target.numfaces != faceIDs.count do throw "面数量发生变化"
			for faceIndex = 1 to faceIDs.count do setFaceMatID target faceIndex faceIDs[faceIndex]
			update target
			baseObj.mesh = target
		)
		else throw "不支持的底层对象类型"
		try (notifyDependents baseObj partID:#display) catch ()
		true
	)
	catch (false)
)


-- #(状态, 说明, 类型, baseObj, target, faceIDs, material, 是否Multi,
--   珍珠槽位, 珍珠ID, 珍珠名称, 珍珠面数, 另一槽位, 修复模式)
fn JX_QAChar_AnalyzePearlMaterialID node suffix:"_MBB" =
(
	local faceData = JX_QAChar_GetFaceMaterialData node
	local baseKind = faceData[1]
	if baseKind == #unsupported then
		return #(#unsupported, "底层对象不是 Editable Poly/Mesh，或没有可检查面", baseKind,
			faceData[2], faceData[3], faceData[4], undefined, false, 0, 0, #(), 0, 0, #none)

	local faceIDs = faceData[4]
	local nodeMaterial = try (node.material) catch (undefined)
	if nodeMaterial == undefined then
		return #(#none, "没有材质", baseKind, faceData[2], faceData[3], faceIDs,
			nodeMaterial, false, 0, 0, #(), 0, 0, #none)

	local isMulti = (isProperty nodeMaterial #materialList) and (isProperty nodeMaterial #materialIDList)
	if not isMulti then
	(
		local matchedNames = JX_QAChar_GetMaterialNamesBySuffix nodeMaterial suffix:suffix
		if matchedNames.count == 0 then
		(
			if JX_QAChar_MaterialHasNestedSuffix nodeMaterial suffix:suffix then
				return #(#ambiguous, "仅嵌套子材质命中 _MBB，无法按面 Material ID 无损处理", baseKind,
					faceData[2], faceData[3], faceIDs, nodeMaterial, false, 0, 0, #(), 0, 0, #none)
			return #(#none, "未匹配 _MBB 材质", baseKind, faceData[2], faceData[3], faceIDs,
				nodeMaterial, false, 0, 0, matchedNames, 0, 0, #none)
		)
		local wrongFaceCount = 0
		for faceID in faceIDs where faceID != 1 do wrongFaceCount += 1
		if wrongFaceCount == 0 then
			return #(#valid, "单材质珍珠面的 Material ID 均为 1", baseKind, faceData[2], faceData[3],
				faceIDs, nodeMaterial, false, 0, 1, matchedNames, faceIDs.count, 0, #none)
		return #(#wrong, "单材质珍珠面存在非 1 的 Material ID", baseKind, faceData[2], faceData[3],
			faceIDs, nodeMaterial, false, 0, 0, matchedNames, faceIDs.count, 0, #single)
	)

	local subMaterials = try (nodeMaterial.materialList) catch (#())
	local materialIDs = try (nodeMaterial.materialIDList) catch (#())
	local slotIDs = #()
	local pearlSlots = #()
	local pearlNamesBySlot = #()
	local nestedMatchFound = false
	for slotIndex = 1 to subMaterials.count do
	(
		local slotID = if slotIndex <= materialIDs.count then
			(try (materialIDs[slotIndex] as integer) catch (0)) else slotIndex
		append slotIDs slotID
		local slotNames = JX_QAChar_GetMaterialNamesBySuffix subMaterials[slotIndex] suffix:suffix
		if slotNames.count > 0 do
		(
			append pearlSlots slotIndex
			append pearlNamesBySlot slotNames
		)
		if slotNames.count == 0 and JX_QAChar_MaterialHasNestedSuffix subMaterials[slotIndex] suffix:suffix do
			nestedMatchFound = true
	)

	if nestedMatchFound then
		return #(#ambiguous, "Multi/Sub 槽位内仅嵌套子材质命中 _MBB，无法按槽位无损处理", baseKind,
			faceData[2], faceData[3], faceIDs, nodeMaterial, true, 0, 0, #(), 0, 0, #none)

	if pearlSlots.count == 0 then
		return #(#none, "未匹配 _MBB 材质", baseKind, faceData[2], faceData[3], faceIDs,
			nodeMaterial, true, 0, 0, #(), 0, 0, #none)
	if pearlSlots.count > 1 then
		return #(#ambiguous, "存在多个 _MBB 材质槽位，无法无损合并为 ID 1", baseKind,
			faceData[2], faceData[3], faceIDs, nodeMaterial, true, 0, 0, #(), 0, 0, #none)

	local pearlSlot = pearlSlots[1]
	local pearlNames = pearlNamesBySlot[1]
	local pearlID = slotIDs[pearlSlot]
	if pearlID <= 0 then
		return #(#ambiguous, "_MBB 材质槽位的 Material ID 无效", baseKind, faceData[2],
			faceData[3], faceIDs, nodeMaterial, true, pearlSlot, pearlID, pearlNames, 0, 0, #none)

	local samePearlIDSlotCount = 0
	local targetOneSlots = #()
	for slotIndex = 1 to slotIDs.count do
	(
		if slotIDs[slotIndex] == pearlID do samePearlIDSlotCount += 1
		if slotIDs[slotIndex] == 1 do append targetOneSlots slotIndex
	)
	if samePearlIDSlotCount > 1 then
		return #(#ambiguous, "_MBB 当前 ID 同时映射到多个材质槽位", baseKind, faceData[2],
			faceData[3], faceIDs, nodeMaterial, true, pearlSlot, pearlID, pearlNames, 0, 0, #none)

	local pearlFaceCount = 0
	local targetOneFaceCount = 0
	for faceID in faceIDs do
	(
		if faceID == pearlID do pearlFaceCount += 1
		if faceID == 1 do targetOneFaceCount += 1
	)
	if pearlFaceCount == 0 then
		return #(#unused, "_MBB 材质存在，但没有面使用其 Material ID", baseKind, faceData[2],
			faceData[3], faceIDs, nodeMaterial, true, pearlSlot, pearlID, pearlNames, 0, 0, #none)

	if pearlID == 1 then
	(
		if targetOneSlots.count > 1 then
			return #(#ambiguous, "Material ID 1 同时映射到多个材质槽位", baseKind, faceData[2],
				faceData[3], faceIDs, nodeMaterial, true, pearlSlot, pearlID, pearlNames, pearlFaceCount, 0, #none)
		return #(#valid, "_MBB 材质及对应面均使用 Material ID 1", baseKind, faceData[2],
			faceData[3], faceIDs, nodeMaterial, true, pearlSlot, pearlID, pearlNames, pearlFaceCount, 0, #none)
	)

	if targetOneSlots.count == 0 then
	(
		if targetOneFaceCount > 0 then
			return #(#ambiguous, "存在 ID 1 的面，但 Multi/Sub 中没有对应材质，无法保证外观不变",
				baseKind, faceData[2], faceData[3], faceIDs, nodeMaterial, true, pearlSlot, pearlID,
				pearlNames, pearlFaceCount, 0, #none)
		return #(#wrong, "_MBB 材质及对应面需要重映射为 Material ID 1", baseKind, faceData[2],
			faceData[3], faceIDs, nodeMaterial, true, pearlSlot, pearlID, pearlNames, pearlFaceCount, 0, #move)
	)
	if targetOneSlots.count > 1 then
		return #(#ambiguous, "Material ID 1 同时映射到多个材质槽位", baseKind, faceData[2],
			faceData[3], faceIDs, nodeMaterial, true, pearlSlot, pearlID, pearlNames, pearlFaceCount, 0, #none)

	#(#wrong, "_MBB 材质与 ID 1 材质需要无损交换", baseKind, faceData[2], faceData[3],
		faceIDs, nodeMaterial, true, pearlSlot, pearlID, pearlNames, pearlFaceCount, targetOneSlots[1], #swap)
)


-- #(成功, 是否修改, 说明, 修改面数)
fn JX_QAChar_RepairPearlMaterialID node =
(
	local analysis = JX_QAChar_AnalyzePearlMaterialID node
	local status = analysis[1]
	if status == #valid or status == #none or status == #unused then return #(true, false, analysis[2], 0)
	if status != #wrong then return #(false, false, analysis[2], 0)
	if JX_QAChar_GetInstanceCount node > 1 then
		return #(false, false, "对象存在实例；不会修改共享面 Material ID", 0)

	local baseKind = analysis[3]
	local baseObj = analysis[4]
	local faceTarget = analysis[5]
	local originalMeshValue = if baseKind == #mesh then copy faceTarget else undefined
	local originalFaceIDs = for faceID in analysis[6] collect faceID
	local originalMaterial = analysis[7]
	local isMulti = analysis[8]
	local pearlSlot = analysis[9]
	local pearlID = analysis[10]
	local otherSlot = analysis[13]
	local repairMode = analysis[14]
	local newFaceIDs = for faceID in originalFaceIDs collect faceID
	local changedFaceCount = 0
	local succeeded = false
	local failureMessage = ""
	local holdStarted = false
	try
	(
		theHold.Begin()
		holdStarted = true
		if repairMode == #single then
		(
			for faceIndex = 1 to newFaceIDs.count where newFaceIDs[faceIndex] != 1 do
			(
				newFaceIDs[faceIndex] = 1
				changedFaceCount += 1
			)
		)
		else
		(
			local newMaterial = copy originalMaterial
			local newIDs = for materialID in newMaterial.materialIDList collect (materialID as integer)
			while newIDs.count < newMaterial.materialList.count do append newIDs (newIDs.count + 1)
			newIDs[pearlSlot] = 1
			if repairMode == #swap do newIDs[otherSlot] = pearlID
			newMaterial.materialIDList = newIDs
			node.material = newMaterial
			for faceIndex = 1 to newFaceIDs.count do
			(
				local oldID = newFaceIDs[faceIndex]
				if oldID == pearlID then
				(
					newFaceIDs[faceIndex] = 1
					changedFaceCount += 1
				)
				else if repairMode == #swap and oldID == 1 then
				(
					newFaceIDs[faceIndex] = pearlID
					changedFaceCount += 1
				)
			)
		)
		if not (JX_QAChar_WriteFaceMaterialIDs baseKind baseObj faceTarget newFaceIDs) do throw "写入面 Material ID 失败"
		local verifyResult = JX_QAChar_AnalyzePearlMaterialID node
		if verifyResult[1] != #valid do throw ("修复后验证失败：" + verifyResult[2])
		theHold.Accept "JX QA 安全修复珍珠 Material ID"
		holdStarted = false
		succeeded = true
	)
	catch
	(
		failureMessage = try (getCurrentException() as string) catch ("未知错误")
		if holdStarted do try (theHold.Cancel()) catch ()
		holdStarted = false
		if baseKind == #mesh and originalMeshValue != undefined do
		(
			try (baseObj.mesh = originalMeshValue) catch ()
			try (update node) catch ()
		)
		try (node.material = originalMaterial) catch (failureMessage += "；材质引用回滚失败")
		if baseKind == #poly do try
		(
			for faceIndex = 1 to originalFaceIDs.count do
				polyop.setFaceMatID baseObj faceIndex originalFaceIDs[faceIndex]
			update node
		)
		catch (failureMessage += "；面 Material ID 回滚失败")
		succeeded = false
	)
	if succeeded then
		#(true, true,
			if isMulti then (if repairMode == #swap then "已无损交换珍珠材质与原 ID 1 材质" else "已将珍珠材质及对应面重映射为 ID 1")
			else "已将单材质珍珠面的 Material ID 统一为 1",
			changedFaceCount)
	else #(false, false, failureMessage, 0)
)


try (destroyDialog JX_QAPearlCountDialog) catch ()
rollout JX_QAPearlCountDialog "珍珠数量确认" width:330 height:132
(
	label lbl_prompt "当前选择中应该有几个使用 _MBB 材质的模型？" pos:[16,14] width:298 height:18
	spinner spn_expected "预期数量：" range:[0,999,0] type:#integer fieldwidth:72 pos:[88,44] width:154
	button btn_confirm "确认" pos:[76,86] width:80 height:28
	button btn_cancel "取消" pos:[174,86] width:80 height:28
	on btn_confirm pressed do
	(
		JX_QAPearlExpectedCount = spn_expected.value as integer
		destroyDialog JX_QAPearlCountDialog
	)
	on btn_cancel pressed do
	(
		JX_QAPearlExpectedCount = undefined
		destroyDialog JX_QAPearlCountDialog
	)
)


fn JX_QAChar_RequestExpectedPearlCount =
(
	JX_QAPearlExpectedCount = undefined
	try (destroyDialog JX_QAPearlCountDialog) catch ()
	createDialog JX_QAPearlCountDialog 330 132 modal:true
	JX_QAPearlExpectedCount
)
-- END v2.1.5 PEARL MODULE


rollout ModelCheckerTool "MAX 模型检查工具 v2.1.6" width:500 height:890
(
	local logText = ""
	
	-- 全局变量
	local selectedObjects = #()
	local errorObjects = #()

	
	-- UI 控件
	group "1. 命名规范"
	(
		button btn_fix_naming "修复命名" width:70 height:30 align:#trimRight
	)
	
	group "2. 模型单位设置"
	(
		checkbox chk_units "检查单位设置(厘米)" checked:true
		button btn_fix_units "修复" width:50 height:20 align:#right offset:[0,-25]
		progressbar pb_units width:400 height:4 color:blue value:0
		
		label lbl_current_unit "当前单位: " offset:[0,5]
		label lbl_unit_value "" offset:[80,-17] style_sunkenedge:true
	)
	
	group "3. 模型坐标"
	(
		checkbox chk_pivot "检查轴心坐标、旋转为0,0,0" checked:true
		button btn_fix_pivot "修复" width:50 height:20 align:#right offset:[0,-25]
		progressbar pb_pivot width:400 height:4 color:blue value:0
		
		checkbox chk_scale "检查缩放为1" checked:true offset:[0,5]
		button btn_fix_scale "修复" width:50 height:20 align:#right offset:[0,-25]
		progressbar pb_scale width:400 height:4 color:blue value:0
		
		
	)
	
	group "4. Reset XForm"
	(
		button btn_fix_normals "Reset XForm" width:70 height:30
	)
	
	group "5. UV 通道检查"
	(
		checkbox chk_uv "UV通道不多于3个" checked:true
		button btn_fix_uv "修复" width:50 height:20 align:#right offset:[0,-25]
		progressbar pb_uv width:400 height:4 color:blue value:0
	)

	group "6. 顶点 Alpha 通道"
	(
		checkbox chk_alpha "检查 -2:Alpha 跨几何顶点共享" checked:true
		button btn_fix_alpha "安全修复" width:60 height:20 align:#right offset:[0,-25]
		progressbar pb_alpha width:400 height:4 color:blue value:0
	)

	group "7. 珍珠 Material ID / 数量"
	(
		checkbox chk_pearl_id "_MBB 材质及对应面 Material ID 必须为 1" checked:true
		button btn_fix_pearl "修复" width:50 height:20 align:#right offset:[0,-25]
		progressbar pb_pearl width:400 height:4 color:blue value:0
		checkbox chk_pearl_count "全部检查前确认 _MBB 模型数量" checked:false
	)
	
	-- 主要操作按钮
	group "操作"
	(
		button btn_check_all "全部检查" width:120 height:30 color:(color 70 130 180)
		button btn_fix_all "全部修复" width:120 height:30 color:(color 60 179 113)
		
		button btn_clear_log "清除日志" width:80 height:25 
		button btn_refresh "刷新" width:80 height:25
	)
	
	-- 日志显示区域
	group "检查日志"
	(
		edittext log_display "" height:150 width:460 readonly:true
	)
	
	-- 获取当前单位设置
	fn getCurrentUnit =
	(
		case units.SystemType of
		(
			#kilometers: "千米"
			#meters: "米"
			#centimeters: "厘米"
			#millimeters: "毫米"
			#inches: "英寸"
			#feet: "英尺"
			default: "未知"
		)
	)
	
	-- 添加日志
	fn addLog msg =
	(
		logText += (msg + "\n")
		log_display.text = logText
	)
	
	-- 清除日志
	fn clearLog =
	(
		logText = ""
		log_display.text = ""
	)
	
	-- 重置进度条
	fn resetProgressBars =
	(
		pb_units.value = 0
		pb_pivot.value = 0
		pb_scale.value = 0
		pb_uv.value = 0
		pb_alpha.value = 0
		pb_pearl.value = 0
	)
	
	
	-- 检查单位设置
	fn checkUnits =
	(
		local isMetric = units.DisplayType == #Metric
		local isCorrect = (units.SystemType == #centimeters)
		pb_units.value = 100
		local result = isCorrect and isMetric
		if result then
			addLog "✓ 单位设置正确 (厘米)"
		else
		(
			addLog ("✗ 单位设置错误，当前: " + getCurrentUnit())
			addLog "应该设置为: 厘米"
		)
		
		return result
	)
	
	-- 检查轴心
	fn checkPivot =
	(
		local errorCount = 0
		local checkedCount = 0
		
		for obj in selection do
		(
			checkedCount += 1
			if ((obj.pivot != [0,0,0]) or 
				(obj.rotation != (quat 0 0 0 1))
				) then
			(
				errorCount += 1
				addLog ("轴心错误: " + obj.name + " - 轴心坐标或旋转未归零")
			)
		)
		
		pb_pivot.value = 100
		
		if checkedCount == 0 then
		(
			addLog "请先选择要检查的对象"
			return false
		)
		
		if errorCount == 0 then
			addLog "✓ 轴心位置检查通过"
		else
			addLog ("✗ 发现 " + errorCount as string + " 个轴心问题")
			
		return (errorCount == 0)
	)
	
	-- 检查缩放
	fn checkScale =
	(
		local errorCount = 0
		local checkedCount = 0
		
		for obj in selection do
		(
			checkedCount += 1
			if (obj.scale != [1,1,1]) then
			(
				errorCount += 1
				addLog ("缩放错误: " + obj.name + " - 缩放值: " + obj.scale as string)
			)
		)
		
		pb_scale.value = 100
		
		if checkedCount == 0 then
		(
			addLog "请先选择要检查的对象"
			return false
		)
		
		if errorCount == 0 then
			addLog "✓ 缩放检查通过"
		else
			addLog ("✗ 发现 " + errorCount as string + " 个缩放问题")
			
		return (errorCount == 0)
	)
	
	
	-- 检查UV通道
	fn checkUV =
	(
		local errorCount = 0
		local checkedCount = 0
		
		for obj in selection do
		(
			if isKindOf obj Editable_mesh or isKindOf obj Editable_Poly then
			(
				checkedCount += 1
				-- 检查UV通道数量
				local uvChannels = meshop.getNumMaps obj.mesh
				if uvChannels > 3 then
				(
					errorCount += 1
					addLog ("UV错误: " + obj.name + " - UV通道数: " + uvChannels as string)
				)
			)
		)
		
		pb_uv.value = 100
		
		if checkedCount == 0 then
		(
			addLog "请先选择网格对象进行检查"
			return false
		)
		
		if errorCount == 0 then
			addLog "✓ UV通道检查通过"
		else
			addLog ("✗ 发现 " + errorCount as string + " 个UV问题")
			
		return (errorCount == 0)
	)

	fn checkAlpha =
	(
		local errorCount = 0
		local checkedCount = 0

		for obj in selection do
		(
			local result = JX_QAChar_AnalyzeAlphaObject obj
			case result[1] of
			(
				#unsupported:
				addLog ("跳过Alpha检查: " + obj.name + " - " + result[5])
				#none:
				(
					checkedCount += 1
					addLog ("✓ Alpha检查: " + obj.name + " - " + result[5])
				)
				#valid:
				(
					checkedCount += 1
					addLog ("✓ Alpha检查: " + obj.name + " - 数据顶点 " + result[2] as string + "，索引关系正常")
				)
				#shared:
				(
					checkedCount += 1
					errorCount += 1
					addLog ("✗ Alpha错误: " + obj.name + " - 数据顶点 " + result[2] as string +
						"，跨点共享索引 " + result[3] as string + " 个，影响几何点 " + result[4] as string + " 个")
				)
				#invalid:
				(
					checkedCount += 1
					errorCount += 1
					addLog ("✗ Alpha结构错误: " + obj.name + " - " + result[5])
				)
			)
		)

		pb_alpha.value = 100

		if checkedCount == 0 then
		(
			addLog "请先选择底层为可编辑多边形或可编辑网格的对象"
			return false
		)

		if errorCount == 0 then
			addLog "✓ 顶点 Alpha 通道检查通过"
		else
			addLog ("✗ 发现 " + errorCount as string + " 个顶点 Alpha 通道问题")

		return (errorCount == 0)
	)

	fn fixAlpha =
	(
		local repairedCount = 0
		local skippedCount = 0
		local failedCount = 0

		for obj in selection do
		(
			local beforeResult = JX_QAChar_AnalyzeAlphaObject obj
			if beforeResult[1] == #unsupported then
			(
				skippedCount += 1
				addLog ("跳过Alpha修复: " + obj.name + " - " + beforeResult[5])
			)
			else
			(
				local result = JX_QAChar_RepairAlphaObject obj
				if result[1] then
				(
					if beforeResult[1] == #shared then
					(
						repairedCount += 1
						addLog ("✓ Alpha修复: " + obj.name + " - 数据顶点 " +
							result[2] as string + " → " + result[3] as string)
					)
					else
					(
						skippedCount += 1
						addLog ("✓ Alpha修复: " + obj.name + " - " + result[4])
					)
				)
				else
				(
					failedCount += 1
					addLog ("✗ Alpha修复失败: " + obj.name + " - " + result[4])
				)
			)
		)

		pb_alpha.value = 100
		addLog ("Alpha修复汇总: 已修复 " + repairedCount as string +
			"，无需处理/跳过 " + skippedCount as string + "，失败 " + failedCount as string)
		return (failedCount == 0)
	)

	-- BEGIN v2.1.5 PEARL UI MODULE
	fn checkPearl expectedCount:undefined =
	(
		local nodes = for obj in selection collect obj
		local pearlCount = 0
		local problemCount = 0
		local supportedCount = 0
		if nodes.count == 0 then
		(
			addLog "✗ 珍珠检查：请先选择对象"
			pb_pearl.value = 100
			return false
		)
		for node in nodes do
		(
			local result = JX_QAChar_AnalyzePearlMaterialID node
			case result[1] of
			(
				#valid:
				(
					supportedCount += 1
					pearlCount += 1
					addLog ("✓ 珍珠 ID：" + node.name + "，命中 " + result[12] as string + " 个面")
				)
				#wrong:
				(
					supportedCount += 1
					pearlCount += 1
					problemCount += 1
					addLog ("✗ 珍珠 ID：" + node.name + " - " + result[2])
				)
				#ambiguous:
				(
					supportedCount += 1
					pearlCount += 1
					problemCount += 1
					addLog ("✗ 珍珠 ID 无法无损处理：" + node.name + " - " + result[2])
				)
				#unused:
				(
					supportedCount += 1
					pearlCount += 1
					problemCount += 1
					addLog ("✗ 珍珠 ID：" + node.name + " - " + result[2])
				)
				#none:
				(
					supportedCount += 1
					addLog ("· 珍珠：" + node.name + " - " + result[2])
				)
				default:
				(
					problemCount += 1
					addLog ("✗ 珍珠无法检查：" + node.name + " - " + result[2])
				)
			)
		)
		if expectedCount != undefined then
		(
			if pearlCount == expectedCount then addLog ("✓ 珍珠数量：" + pearlCount as string)
			else
			(
				problemCount += 1
				addLog ("✗ 珍珠数量：预期 " + expectedCount as string + "，实际 " + pearlCount as string)
			)
		)
		if pearlCount == 0 and expectedCount == undefined and supportedCount > 0 do
			addLog "✓ 当前选择未发现直接命名为 _MBB 的珍珠材质"
		pb_pearl.value = 100
		supportedCount > 0 and problemCount == 0
	)

	fn fixPearl =
	(
		local nodes = for obj in selection collect obj
		local failureCount = 0
		if nodes.count == 0 then
		(
			addLog "✗ 珍珠修复：请先选择对象"
			pb_pearl.value = 100
			return false
		)
		for node in nodes do
		(
			local beforeResult = JX_QAChar_AnalyzePearlMaterialID node
			if beforeResult[1] == #wrong then
			(
				local result = JX_QAChar_RepairPearlMaterialID node
				if result[1] then addLog ("✓ 珍珠 ID 修复：" + node.name + " - " + result[3])
				else
				(
					failureCount += 1
					addLog ("✗ 珍珠 ID 修复失败：" + node.name + " - " + result[3])
				)
			)
			else if beforeResult[1] == #ambiguous or beforeResult[1] == #unused then
			(
				failureCount += 1
				addLog ("✗ 珍珠 ID 未处理：" + node.name + " - " + beforeResult[2])
			)
			else if beforeResult[1] == #unsupported then
			(
				failureCount += 1
				addLog ("✗ 珍珠 ID 无法检查：" + node.name + " - " + beforeResult[2])
			)
			else addLog ("· 珍珠 ID 无需修复：" + node.name + " - " + beforeResult[2])
		)
		pb_pearl.value = 100
		failureCount == 0
	)
	-- END v2.1.5 PEARL UI MODULE
	
	-- 修复函数
	fn fixNormals = 
	(
		for obj in selection do
		(
			if isKindOf obj Editable_mesh or isKindOf obj Editable_Poly then
			(
				-- 翻转法线
				-- obj.flip = not obj.flip
				addLog ("处理法线: " + obj.name)
			)
		)
		addLog "✓ 法线修复完成"
	)

	fn fixNames = 
	(
		for obj in selection do
		(
			local objName = JXCharQATool.lowercase obj.name
			local checkResult = false
			local fileNameStr = substring maxfilename 1 (maxfilename.count - 4)

			for namingBack in JXCharQATool.namingBacks do 
			(
				local patt = "*" + namingBack + "*"
				local backPos = findString objName namingBack
				if (backPos != undefined) then 
				(
					checkResult = true
					obj.name = JXCharQATool.formatUnderscoreString objName
					obj.name = fileNameStr + (substring obj.name backPos objName.count)
					exit
				)
				
			)
			if(checkResult == false) then 
			(
				addLog ("✗命名规范： " + obj.name + " 为未知 命名 物体，注意筛查")
			)
		)
	)

	fn fixUnits =
	(
		units.DisplayType = #Metric
		units.SystemType = #centimeters
		addLog "✓ 单位已设置为厘米"
		lbl_unit_value.text = getCurrentUnit()
	)
	
	fn fixPivot =
	(
		undo on (
		for obj in selection do
		(
			resetPivot obj
			obj.pivot = [0,0,0]
			obj.rotation = (quat 0 0 0 1)
		)
		)
		addLog "✓ 已重置坐标轴的坐标、旋转为0"
	)
	
	fn fixScale =
	(
		undo on (
		for obj in selection do
		(
			obj.scale = [1,1,1]
		)
		)
		addLog "✓ 已重置缩放为100"
	)

	fn fixUvs = 
	(
		local objs = for obj in selection collect obj
		for obj in objs do
		(
			
			local uvChannels = meshop.getNumMaps obj.mesh
			if (uvChannels <= 3) then continue
			max modify mode
			undo on (
				for i = uvChannels to 3 by -1 do 
				(
					channelInfo.ClearChannel obj i
					modPanel.setCurrentObject obj.baseObject
					modPanel.addModToSelection(UVW_Mapping_Clear())
					deleteModifier obj 1
					if(obj.modifiers[#Skin] != undefined) then 
					(
						maxOps.CollapseNodeTo obj 2 true
					)else(
						maxOps.CollapseNodeTo obj 1 true
					)
					
				)
			)
			addLog ("✓ 已删除 " + obj.name + "的多余通道")
		)

	)
	
	-- 界面初始化
	on ModelCheckerTool open do
	(
		lbl_unit_value.text = getCurrentUnit()
		addLog "=== MAX 模型检查工具已启动 ==="
		addLog "请选择要检查的对象，然后点击相应的检查按钮"
	)
	
	-- 事件处理
	on btn_check_all pressed do
	(
		clearLog()
		resetProgressBars()
		addLog "=== 开始全部检查 ==="
		
		if chk_units.checked then checkUnits()
		if chk_pivot.checked then checkPivot()
		if chk_scale.checked then checkScale()
		if chk_uv.checked then checkUV()
		if chk_alpha.checked then checkAlpha()
		if chk_pearl_id.checked then
		(
			local expectedPearlCount = undefined
			local runPearlCheck = true
			if chk_pearl_count.checked do
			(
				expectedPearlCount = JX_QAChar_RequestExpectedPearlCount()
				if expectedPearlCount == undefined do
				(
					runPearlCheck = false
					addLog "珍珠数量确认已取消，本次跳过珍珠检查"
				)
			)
			if runPearlCheck do checkPearl expectedCount:expectedPearlCount
		)
		
		addLog "=== 检查完成 ==="
	)
	
	on btn_fix_all pressed do
	(
		addLog "=== 开始全部修复 ==="

		fixNames()
		if chk_units.checked then fixUnits()
		if chk_pivot.checked then fixPivot()
		if chk_scale.checked then fixScale()
		fixNormals()
		if chk_uv.checked then fixUvs()
		if chk_alpha.checked then fixAlpha()
		if chk_pearl_id.checked then fixPearl()
		addLog "=== 修复完成 ==="
	)
	

	on btn_fix_naming pressed do fixNames()
	on btn_fix_units pressed do fixUnits()
	on btn_fix_pivot pressed do fixPivot()
	on btn_fix_scale pressed do fixScale()
	on btn_fix_normals pressed do fixNormals()
	on btn_fix_uv pressed do fixUvs()
	on btn_fix_alpha pressed do fixAlpha()
	on btn_fix_pearl pressed do fixPearl()

	on btn_clear_log pressed do clearLog()

	on btn_refresh pressed do
	(
		lbl_unit_value.text = getCurrentUnit()
		resetProgressBars()
		addLog "界面已刷新"
	)
)

global JX_QAChar_Show

function JX_QAChar_Show =
(
	try (destroyDialog ModelCheckerTool) catch ()
	createDialog ModelCheckerTool 500 890
)


macroScript JX_QAChar
category:"JXTools"
toolTip:"角色模型规范检查 v2.1.6"
buttonText:"角色模型规范检查"
(
	on execute do JX_QAChar_Show()
)
